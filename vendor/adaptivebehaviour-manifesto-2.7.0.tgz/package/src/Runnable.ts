import { Root, Instance } from './Root';

/**
 * Declarative description of one operation argument — the JS analogue of
 * AB/projects/operations/args.py's ArgSpec, minus the argparse-specific
 * `nargs` field (Python's Operation.buildParser() equivalent doesn't exist
 * on the JS side, since JS operations have no CLI entry point).
 */
export interface ArgSpec {
  id: string;
  type: 'string' | 'boolean' | 'json' | 'int' | 'float';
  help?: string;
  default?: unknown;
  required?: boolean;
}

/**
 * The contract every runnable object must satisfy, on top of {@link Instance}:
 * a callable `run()` that performs a task and returns a result (including
 * `undefined`/`null`). {@link Operation} implements this; a custom Runnable
 * registered into `instanceRegistry` (see `create.ts`) must too.
 *
 * `run()` may return a `Promise` — this is what lets a Runnable be awaited
 * directly from a Next.js Server Action (see `js/workshop/nextjs/src/app/actions.ts`),
 * without every Runnable being forced to declare itself `async`.
 */
export interface Runnable extends Instance {
  run(args?: unknown): unknown | Promise<unknown>;
}

const coerceValue = (spec: ArgSpec, value: unknown): unknown => {
  switch (spec.type) {
    case 'boolean':
      return Boolean(value);
    case 'json':
      if (typeof value === 'string') return value ? JSON.parse(value) : {};
      return value ?? {};
    case 'int':
      return typeof value === 'number' ? Math.trunc(value) : parseInt(String(value), 10);
    case 'float':
      return typeof value === 'number' ? value : parseFloat(String(value));
    default:
      return value === undefined || value === null ? value : String(value);
  }
};

/**
 * Normalise and coerce a raw args value against an operation's `ArgSpec[]` —
 * the JS analogue of `operations/args.py`'s `coerce_args()`. Unrecognised
 * keys pass through unchanged; a spec's `default` fills in when its key is
 * absent from `raw` (booleans are never defaulted here, matching the Python
 * original — an absent boolean flag coerces to `false` via `coerceValue`
 * only when the key is present).
 *
 * @param specs - The operation's declared arguments.
 * @param raw - The raw args value passed to `run()` — anything other than a
 *   plain object is treated as `{}`.
 */
export function coerceArgs(specs: ArgSpec[], raw: unknown): Record<string, unknown> {
  const source = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const byId = new Map(specs.map((spec) => [spec.id, spec]));
  const coerced: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(source)) {
    const spec = byId.get(key);
    coerced[key] = spec ? coerceValue(spec, value) : value;
  }
  for (const spec of specs) {
    if (!(spec.id in coerced) && spec.default !== undefined) {
      coerced[spec.id] = coerceValue(spec, spec.default);
    }
  }
  return coerced;
}

/** Plain-data form of {@link OperationResult} — see {@link OperationResult.asDict}. */
export interface OperationResultDict {
  text: string;
  payload: Record<string, unknown> | null;
  exitCode: number;
}

/**
 * The outcome of an `Operation.execute()` call — the JS port of
 * `AB/projects/operations/result.py`'s `OperationResult`.
 *
 * - `text` — primary string output; what `Operation.run()` returns.
 * - `payload` — optional structured data for programmatic callers (e.g. a
 *   Next.js Server Action returning JSON to a client component).
 * - `exitCode` — process exit code (CLI convention; `0` = success). JS
 *   Operations have no CLI entry point of their own, but `exitCode` is kept
 *   for parity with the Python port and for any caller that wants an
 *   explicit success/failure signal without inspecting `text`.
 */
export class OperationResult {
  text: string;
  payload: Record<string, unknown> | null;
  exitCode: number;

  constructor(text: string, payload: Record<string, unknown> | null = null, exitCode = 0) {
    this.text = text;
    this.payload = payload;
    this.exitCode = exitCode;
  }

  asDict(): OperationResultDict {
    return { text: this.text, payload: this.payload, exitCode: this.exitCode };
  }

  serialize(asJson = false): string {
    return asJson ? JSON.stringify(this.asDict(), null, 2) : this.text;
  }

  static ok(text: string, payload: Record<string, unknown> | null = null): OperationResult {
    return new OperationResult(text, payload, 0);
  }

  static error(text: string, exitCode = 1, payload: Record<string, unknown> | null = null): OperationResult {
    return new OperationResult(text, payload, exitCode);
  }
}

/**
 * Concrete base for Runnable objects. Extends {@link Root} — so an Operation
 * is a normal object in the `kind`/`factory` hierarchy (registers into
 * `instanceRegistry` exactly like `Root` itself, inherits
 * `id`/`kind`/`factory`/`props`/`items`/`refs`/`record()`) — and adds the
 * `run()` contract on top.
 *
 * `Operation` is a sibling of `Factory` (`Factory.ts`), not a base or
 * subclass of it — both extend {@link Root} independently and add their own
 * orthogonal capability (Runnable vs. Factory-capable). `Operation` does not
 * need `Factory`'s two-phase `produce()`: an Operation's own configuration
 * (e.g. `SanityFetch`'s `projectId`/`dataset`) is intrinsic to every use of
 * that operation, unlike a declarative factory (`Image`) which legitimately
 * wants both its own visual defaults *and* an unrelated structural parent's
 * cascading props at once. See `Factory.ts`'s own module comment for the
 * full rationale. Do not give `Operation`/`execute()` a second, incompatible
 * meaning by also implementing `FactoryCapability` on the same class unless
 * a concrete need actually arises — `execute()`'s contract (an
 * {@link OperationResult}) and `produce()`'s contract (a plain
 * {@link RootRecord}) are deliberately kept as two distinctly-named methods
 * for exactly this reason.
 *
 * Subclasses declare `static argSpecs` and implement `execute()`, returning
 * an {@link OperationResult}; all business logic belongs in `execute()`,
 * `run()` is just the thin adapter that coerces `args` against `argSpecs`
 * first and unwraps the result's `.text`. `execute()` is public (not
 * `protected`) precisely so a caller that needs the full result (e.g.
 * `payload`) can call it directly instead of `run()`. Never store a `run()`
 * result on the record — a record describes how to run something, not what
 * happened when it ran.
 *
 * @example
 * ```ts
 * class HelloWorld extends Operation {
 *   static argSpecs: ArgSpec[] = [{ id: 'name', type: 'string', default: 'world' }];
 *   execute(args: Record<string, unknown>) {
 *     return OperationResult.ok(`Hello, ${args.name}!`);
 *   }
 * }
 * ```
 */
export class Operation extends Root implements Runnable {
  static argSpecs: ArgSpec[] = [];

  /**
   * Run operation logic. All business logic belongs here. Subclasses
   * override this; the base implementation always throws, since there is
   * no default behaviour to fall back to. Public (not `protected`) so a
   * caller can call it directly for the full {@link OperationResult} (e.g.
   * `payload`) instead of going through {@link run}, which only returns
   * `.text`.
   *
   * @param _args - Coerced arguments, per `argSpecs` — the output of
   *   {@link coerceArgs}, never a raw/unvalidated value.
   * @throws Always, unless overridden by a subclass.
   */
  execute(_args: Record<string, unknown>): OperationResult | Promise<OperationResult> {
    throw new Error(`'${this.factory}' has no execute() implementation.`);
  }

  /**
   * Entry point for import and instance-method use; returns the primary
   * text response. Coerces `args` against `argSpecs` (via {@link coerceArgs})
   * and calls {@link execute}, unwrapping the result's `.text`. A caller
   * that needs the full {@link OperationResult} should call `execute()`
   * directly instead.
   *
   * @param args - Raw args; coerced against `argSpecs` before reaching
   *   `execute()`. `undefined` applies `argSpecs` defaults.
   */
  run(args?: unknown): string | Promise<string> {
    const specs = (this.constructor as typeof Operation).argSpecs;
    const result = this.execute(coerceArgs(specs, args));
    return result instanceof Promise ? result.then((r) => r.text) : result.text;
  }
}

/**
 * Import entry point for the base {@link Operation} — the JS analogue of
 * `AB/projects/operations/base.py`'s module-level `run()`. Always throws,
 * since the base `Operation` has no `execute()` implementation of its own;
 * kept for parity with the Python port and as a template for a concrete
 * Operation's own module-level `run()` export (see `manifesto/HelloWorld.ts`).
 */
export function run(args?: unknown): string | Promise<string> {
  return new Operation().run(args);
}
