import { Root, RootConfig, RootRecord, Instance, generateId, recordRegistry, resolveAncestorRecord, parseRefsIntoProps } from './Root';
import { validateProduct } from './schema';

/**
 * Options accepted by {@link FactoryCapability.produce} — an alias of
 * {@link RootConfig}, since a produce() call's overrides and a collection's
 * `records.json` entry are the same "partially complete record" concept
 * `create.ts`'s `CreateOptions` already uses. `kind`, here, always describes
 * the *product's* real structural position (see this file's own module
 * comment below) — never the factory's own record, which was already
 * resolved before the factory instance was constructed.
 */
export type ProduceOptions = RootConfig;

/**
 * The contract every factory-capable object must satisfy, on top of
 * {@link Instance}: a callable `produce()` that builds a {@link RootRecord}
 * "product" from caller-supplied options. {@link Factory} implements this as
 * the generic default; a custom factory class registered into
 * `instanceRegistry` (see `create.ts`) may implement it directly instead —
 * see this file's module comment for when that's actually necessary.
 *
 * `Factory` is a capability, not a mandatory base class — the same
 * relationship {@link Runnable} (`Runnable.ts`) already has to
 * {@link Instance}: orthogonal to the Instance/Record form axis, and
 * orthogonal to `Runnable` itself. An `Operation` (`Fetch`, `SanityFetch`,
 * `HelloWorld`) is Runnable but not Factory-capable, and doesn't need to be
 * — see this file's module comment for why.
 *
 * `produce()` may return a `Promise<RootRecord>` — every *generic-default*
 * `Factory` product (the only kind that existed before) stays synchronous,
 * but a custom `instanceRegistry`-registered class may legitimately need I/O
 * to build its product (e.g. fetching a document to resolve an image's
 * `url`). `create()` rejects an async product at runtime (it has no way to
 * await one) — call `createAsync()` (`create.ts`) instead for a factory that
 * may return a Promise here.
 */
export interface FactoryCapability extends Instance {
  produce(
    options?: ProduceOptions,
    cache?: Map<string, RootRecord>,
    records?: Map<string, RootConfig>
  ): RootRecord | Promise<RootRecord>;
}

/**
 * Generic default {@link FactoryCapability} implementation. `create()` (in
 * `create.ts`) constructs this automatically for any factory key with no
 * custom class registered in `instanceRegistry` — which covers every
 * currently-existing purely-declarative factory (`root`, `component`,
 * `text`, `image`). A custom class is only needed for a factory with real,
 * non-generic production logic; none exist yet, but the door stays open by
 * registering a `FactoryCapability`-implementing constructor into
 * `instanceRegistry` under that factory's key, exactly like a custom
 * `Instance` constructor is registered today.
 *
 * ## Why this exists — the two-phase resolution model
 *
 * Object creation splits into two independent passes, so a single record's
 * `kind` is never asked to mean two different things at once (see
 * the `manifesto-concepts` skill's Nomenclature section, "Factory objects",
 * for the full rationale and worked example):
 *
 * 1. **Resolve the factory's own identity** — `create()` resolves the
 *    factory key (e.g. `'image'`) against `recordRegistry` (`Root.ts`) via
 *    inheritance, exactly as any other record resolves its own ancestry,
 *    and constructs a `Factory` instance from the result. This instance's
 *    own `this.props` now holds the factory's resolved defaults (e.g.
 *    `image`'s default `url`/`width`/`height`/`alt`).
 * 2. **The factory instance builds the product** — `produce(options)`
 *    builds the actual output record. `options.kind`, if given, is resolved
 *    against `records` (defaults to `recordRegistry` — see the `records`
 *    parameter below) — real structural ancestry, e.g. a `profile-card`
 *    record and everything *it* inherits — and the factory's own resolved
 *    defaults (`this.props`) are merged in separately, never via `kind`.
 *    Merge precedence (lowest to highest): factory's own generic defaults <
 *    product's real inherited ancestor props < the caller's own explicit
 *    `options.props` overrides — a deliberate placement under a specific
 *    `kind` is more specific than a generic factory fallback, so it wins on
 *    overlapping keys.
 *
 * Both steps resolve against `recordRegistry` — there is no longer a
 * separate registry for a factory's own configuration. `recordRegistry` is
 * shared globally across every collection (see `getCollection.ts`'s
 * registry's collection list), and a later-registered collection's entry silently
 * overwrites an earlier one's under the same id, by design (see
 * `getCollection.ts`'s own comment) — `getCollection(collectionId)` is the
 * way to deliberately resolve a factory's identity (or any record's
 * ancestry) against one specific collection's own scope, bypassing
 * whatever currently shadows it globally. Passing that collection's own
 * `recordRegistry` snapshot as this method's `records` parameter is what
 * makes that scoping apply to `produce()` too, not just record resolution.
 *
 * This is why `Operation` (`Fetch`/`SanityFetch`/`HelloWorld`) doesn't need
 * to be Factory-capable: an Operation's own configuration (e.g.
 * `sanity-fetch`'s `projectId`/`dataset`) is intrinsic to every use of that
 * operation — there's no legitimate case for wanting a `sanity-fetch`
 * instance *without* its configured project, the way an `Image` legitimately
 * wants both its visual defaults *and* an unrelated structural parent's
 * cascading props at once. Operations aren't positioned in a rendered
 * hierarchy the way UI components are, so the two-phase split this class
 * exists for isn't needed there; their existing construction path (`create.ts`'s
 * pre-existing `buildRecord()` + `instanceRegistry` dispatch) is unchanged
 * by this class's existence.
 *
 * @example
 * ```ts
 * // 'image' has no custom instanceRegistry entry, so create() builds a
 * // generic Factory instance from image's own recordRegistry entry (default
 * // url/width/height/alt), then calls produce() with the caller's options —
 * // here, positioning the product under 'profile-card' so it also inherits
 * // that record's real ancestry (e.g. `theme`), while still getting Image's
 * // own visual defaults through this class's produce():
 * create('image', { kind: 'profile-card', props: { url: 'avatar.jpg' } });
 * ```
 */
export class Factory extends Root implements FactoryCapability {
  /**
   * Build a product record from this factory instance's own resolved
   * defaults (`this.props`) plus the caller's `options`.
   *
   * @param options - `kind` positions the product in the real hierarchy
   *   (defaults to `'root'` — a real, resolvable position, not an
   *   inheritance opt-out); `props`/`items`/`refs`/`id`/`factory` override
   *   the product's own fields, per this class's own doc comment for merge
   *   precedence.
   * @param cache - Optional, keyed by id — forwarded to
   *   {@link resolveAncestorRecord}; `getCollection()` supplies each
   *   `Collection` its own cache the same way it does for `create()`'s own
   *   record cache. Omit it for a fresh resolution every call.
   * @param records - Which registry to resolve `options.kind`'s ancestry
   *   against — defaults to the global {@link recordRegistry}. Pass a
   *   specific collection's own scoped registry (as `getCollection(collectionId)`
   *   does internally) to resolve `kind` against that collection's
   *   un-overridden view rather than the globally merged one.
   * @returns The new product {@link RootRecord}, already registered in
   *   `records` (and, if `records` is a collection-scoped registry distinct
   *   from the global one, in {@link recordRegistry} too, so it stays
   *   generally discoverable).
   * @throws If `options.kind` is given but no record with that id exists in
   *   `records`, or if the resolved product id equals its `kind` ancestor's
   *   id.
   */
  produce(
    options: ProduceOptions = {},
    cache?: Map<string, RootRecord>,
    records: Map<string, RootConfig> = recordRegistry
  ): RootRecord {
    // `kind` is the product's structural parent only. Its defaults come from
    // `extends` (an optional record id), resolved transitively.
    const kind = options.kind ?? 'root';
    const ancestor = options.extends !== undefined
      ? resolveAncestorRecord(options.extends, records, cache, new Set())
      : undefined;

    const factory = options.factory !== undefined ? options.factory : this.factory;
    const id = options.id ?? generateId(factory);
    if (ancestor && id === ancestor.id) {
      throw new Error(`Product id '${id}' must differ from the id of the record it extends ('${ancestor.id}').`);
    }

    // Merge precedence, lowest to highest: this factory's own generic
    // defaults < the `extends` chain's props < the caller's own explicit
    // overrides. `kind` takes no part in it.
    const refs = options.refs !== undefined ? [...options.refs] : [...(ancestor?.refs ?? [])];
    const props = parseRefsIntoProps({ ...this.props, ...ancestor?.props, ...options.props }, refs);

    const record: RootRecord = {
      id,
      kind,
      factory,
      props,
      items: options.items !== undefined ? [...options.items] : [],
      refs,
    };
    validateProduct(record);
    records.set(record.id, record);
    if (records !== recordRegistry) recordRegistry.set(record.id, record);
    return record;
  }
}
