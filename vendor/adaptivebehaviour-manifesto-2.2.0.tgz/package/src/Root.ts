/**
 * A partially complete {@link RootRecord} — every field optional. This is
 * the one "partial record" shape used everywhere a record may not yet have
 * every field filled in: as the argument type for `buildRecord()` /
 * `buildInstance()` / `build()` (re-exported there as `CreateOptions` —
 * see `create.ts`), for `Factory.produce()`'s own options (see `Factory.ts`),
 * and for a collection's `records.json` entries, which only need to declare
 * fields unique to that record — anything else is resolved from the record it
 * `extends` the first time something needs it as a parent (see this file's
 * own `resolveAncestorRecord()`).
 */
export interface RootConfig {
  id?: string;
  /**
   * The object's structural parent: the id of the object it sits under in the
   * hierarchy. Defaults to `'root'`. **Only ever structural** — it never
   * supplies default props.
   */
  kind?: string;
  /**
   * The id of a registered record this one takes its defaults from: its `props`
   * (and `refs`, `factory`) are merged under this record's own, transitively
   * through that record's own `extends`. A cycle, or an unregistered id, is an
   * error. Not retained on the resolved record — the defaults are merged in.
   */
  extends?: string;
  factory?: string;
  props?: Record<string, unknown>;
  items?: unknown[];
  refs?: string[];
}

/**
 * The contract every object built via `instanceRegistry` must satisfy: the
 * same field set as a {@link RootRecord}, plus a `record()` method returning
 * that plain-data form. {@link Root} implements this; a custom instance type
 * registered into `instanceRegistry` (see `create.ts`) must too.
 */
export interface Instance {
  id: string;
  kind: string;
  factory: string;
  props: Record<string, unknown>;
  items: unknown[];
  refs: string[];
  record(): RootRecord;
}

export class Root implements Instance {
  id: string;
  kind: string;
  factory: string;
  props: Record<string, unknown>;
  items: unknown[];
  refs: string[];

  /**
   * `kind` defaults to `'root'` — every object is a direct child of root
   * unless a caller positions it elsewhere in the hierarchy. `'root'` is
   * always a resolvable ancestor (pre-registered in
   * `instancesById`/`recordRegistry`), unlike the old `'object'` default
   * this replaced, which was never itself a registered id. `'object'` is
   * reserved for {@link rootRecord}/{@link rootInstance} themselves — the
   * only object allowed to have it.
   *
   * `kind` is never set by which factory built an object, and never carries
   * "where do my default props come from" information — that's a separate
   * concern, resolved by {@link Factory.produce} (see `Factory.ts`) by
   * merging a factory's own resolved `props` directly, without ever touching
   * `kind`. A record's `kind` always means, and only ever means, "who is my
   * real structural parent" — do not reintroduce an id-matches-factory
   * shortcut that sets `kind` as a side effect of resolving defaults.
   */
  constructor({
    id = '',
    kind = 'root',
    factory = 'object',
    props = {},
    items = [],
    refs = []
  }: RootConfig = {}) {
    this.id = id;
    this.kind = kind;
    this.factory = factory;
    this.props = { ...props };
    this.items = [...items];
    this.refs = [...refs];
  }

  /**
   * Returns this instance's plain-data record form — the same field set,
   * copied rather than referenced so mutating the result never affects the
   * instance.
   */
  record(): RootRecord {
    return {
      id: this.id,
      kind: this.kind,
      factory: this.factory,
      props: { ...this.props },
      items: [...this.items],
      refs: [...this.refs],
    };
  }
}

// Explicit kind: 'object' — root is the one record allowed to have it; every
// other object's kind defaults to 'root' (see the constructor above), since
// 'root' is always resolvable as an ancestor and 'object' never is.
export const rootInstance = new Root({ id: 'root', kind: 'object' });

// Plain data form — a simple object literal with no class methods or prototype chain.
// Use this when a lightweight structure is needed, e.g. for JSON serialisation,
// inter-process messaging, or initialising state in a store.
export type RootRecord = {
  id: string;
  kind: string;
  factory: string;
  props: Record<string, unknown>;
  items: unknown[];
  refs: string[];
};

export const rootRecord: RootRecord = {
  id: 'root',
  kind: 'object',
  factory: 'object',
  props: {},
  items: [],
  refs: [],
};

// ── Id generation ─────────────────────────────────────────────────────────────
//
// Every auto-generated id is prefixed with the object's own `factory` —
// `${factory}-${uuid}` — rather than a bare uuid, so an id is self-describing
// about what built it (e.g. `image-3f2b...`). The hyphen delimiter matches
// this repo's Slug convention and keeps the prefix unambiguous to split back
// out, unlike a bare concatenation.

/** Build an auto-generated id for a new object of the given `factory`. */
export function generateId(factory: string): string {
  return `${factory}-${crypto.randomUUID()}`;
}

// ── Child creation ────────────────────────────────────────────────────────────
//
// Rules applied by both functions:
//   • kind     — always set to parent.id (records the parent; caller cannot override)
//   • id       — auto-generated (prefixed with the resolved factory) when not supplied; must differ from parent.id
//   • factory  — inherited from parent when the caller omits it
//   • props    — merged with parent's props; child's own fields take precedence
//   • items    — never inherited from parent; defaults to an empty array when omitted
//   • refs     — inherited from parent when the caller omits them
//
// Deliberately single-level: these take an already-resolved parent object
// directly rather than looking one up by id, so there is no registry here to
// walk further ancestors through. Contrast create.ts's buildInstance() /
// buildRecord(), which resolve `kind` against instancesById / recordRegistry
// and merge props all the way up to 'root', not just the immediate parent —
// use those when full multi-level inheritance matters.

// 'kind' is excluded from ChildInstanceConfig because it is always derived from the parent.
export type ChildInstanceConfig = Omit<RootConfig, 'kind'>;

export function createChildInstance(parent: Root, config: ChildInstanceConfig = {}): Root {
  const factory = config.factory !== undefined ? config.factory : parent.factory;
  const id = config.id ?? generateId(factory);
  if (id === parent.id) {
    throw new Error(`Child id '${id}' must differ from parent id '${parent.id}'.`);
  }
  return new Root({
    id,
    kind: parent.id,
    factory,
    props: { ...parent.props, ...config.props },
    items: config.items !== undefined ? config.items : [],
    refs:  config.refs  !== undefined ? config.refs  : [...parent.refs],
  });
}

// 'kind' is excluded from ChildRecordOverrides for the same reason as above.
export type ChildRecordOverrides = Partial<Omit<RootRecord, 'kind'>>;


export function createChildRecord(
  parent: RootRecord,
  data: ChildRecordOverrides = {}
): RootRecord {
  const factory = data.factory !== undefined ? data.factory : parent.factory;
  const id = data.id ?? generateId(factory);
  if (id === parent.id) {
    throw new Error(`Child id '${id}' must differ from parent id '${parent.id}'.`);
  }
  return {
    id,
    kind: parent.id,
    factory,
    props: { ...parent.props, ...data.props },
    items: data.items !== undefined ? [...data.items] : [],
    refs:  data.refs  !== undefined ? [...data.refs]  : [...parent.refs],
  };
}

// ── Ref parsing ───────────────────────────────────────────────────────────────
//
// parseRef converts a single ref string into a key-value object.
//
// A ref string starts with a key: one or more lowercase alphabetical
// characters. What follows the key determines the value:
//   • Number  (e.g. 'size12', 'ratio1.5')  →  { size: 12 } / { ratio: 1.5 }
//   • Capital (e.g. 'colorRed')            →  { color: 'red' }
//   • Other patterns — add a handler to refHandlers to support them.
//
// refHandlers is the extension point: push a RefHandler onto it to support
// additional patterns without modifying this file.

/** The result of a successful ref parse: a single key mapped to its value. */
export type ParsedRef = Record<string, unknown>;

/**
 * A handler receives the extracted key and the remainder of the ref string
 * (everything after the key). It returns a ParsedRef if it recognises the
 * pattern, or null to pass control to the next handler.
 */
export type RefHandler = (key: string, remainder: string) => ParsedRef | null;

/** Handle key followed by an integer or decimal number (e.g. 'foo12', 'foo1.5'). */
const numberHandler: RefHandler = (key, remainder) => {
  if (!/^\d+(\.\d+)?$/.test(remainder)) return null;
  const value = remainder.includes('.') ? parseFloat(remainder) : parseInt(remainder, 10);
  return { [key]: value };
};

/** Handle key followed by a capital letter — camelCase split (e.g. 'fooBar' → { foo: 'bar' }). */
const capitalHandler: RefHandler = (key, remainder) => {
  if (!/^[A-Z]/.test(remainder)) return null;
  return { [key]: remainder[0].toLowerCase() + remainder.slice(1) };
};

/**
 * Ordered list of handlers applied by parseRef. Push additional handlers here
 * to support new ref string patterns.
 */
export const refHandlers: RefHandler[] = [numberHandler, capitalHandler];

/**
 * Parse a single ref string into a key-value object.
 *
 * The key is the leading run of lowercase alphabetical characters. Handlers
 * in refHandlers are tried in order; the first match wins. Returns null if
 * the string has no valid key or no handler recognises the remainder.
 *
 * @param ref - A ref string from a Root object's refs array.
 */
export function parseRef(ref: string): ParsedRef | null {
  const match = ref.match(/^([a-z]+)(.*)/);
  if (!match) return null;
  const [, key, remainder] = match;
  for (const handler of refHandlers) {
    const result = handler(key, remainder);
    if (result !== null) return result;
  }
  return null;
}

/** Fold every ref string in `refs` into `props`, via {@link parseRef} — a parsed value wins over an existing prop of the same key. */
export function parseRefsIntoProps(props: Record<string, unknown>, refs: string[]): Record<string, unknown> {
  return refs.reduce<Record<string, unknown>>((acc, ref) => {
    const parsed = parseRef(ref);
    return parsed ? { ...acc, ...parsed } : acc;
  }, props);
}

// ── Record registry & ancestor resolution ─────────────────────────────────────
//
// A single registry, keyed by id, holding RootConfig (not RootRecord — a
// value here is not guaranteed complete; see resolveAncestorRecord()'s own
// comment below) — every named record any collection declares, factory
// configuration (e.g. `image`'s default url/width/height) included. This is
// what a product's requested `kind` (see Factory.ts) resolves against, and
// what `create()`'s "resolve the factory's own identity" step (create.ts)
// also resolves against.
//
// Shared globally across every collection (see getCollection.ts's
// registry's collection list): if two collections declare a record under the same
// id, whichever collection is registered later overwrites the earlier one's
// entry here — this is deliberate, not a bug (see getCollection.ts's own
// comment on registration order). The earlier, shadowed entry is never
// lost — it remains retrievable via `getCollection(collectionId)`, which
// resolves against that specific collection's own scoped registry instead
// of this shared, merged one. See getCollection.ts's module comment for the
// full mechanism.
//
// Pre-registered with root's own entry so 'root' is always a resolvable
// ancestor with no setup call required.

/** Every named record any collection declares, keyed by id — resolved against when a product requests a `kind`, and when `create()` resolves a factory's own identity. */
export const recordRegistry = new Map<string, RootConfig>([
  [rootRecord.id, rootRecord],
]);

// completeRecord() is the shared "turn a partial declaration plus its
// (already-complete) parent into a complete RootRecord" step — used both for
// completing an ancestor found via a registry lookup (resolveAncestorRecord)
// and for a caller's own new record (buildRecord() in create.ts, and
// Factory.produce() in Factory.ts), since all three are the same operation:
// merge inherited fields, then parse.
//
// Parsing is the second step, per parent.props/parent.refs and the record's
// own props/refs having been merged: each of the merged `refs` strings is run
// through parseRef() and folded into `props`, with a parsed value winning
// over an inherited/explicit one of the same key, since parsing is the last
// step applied.

// `parent` is undefined when `partial.kind` doesn't resolve to a real
// registry entry — every record buildRecord() itself produces has a
// resolvable `kind` (Direct mode defaults to 'root', which is always
// registered), so this only happens for a genuinely dangling reference:
// e.g. a records.json entry whose declared `kind` points at an id that was
// never registered. That isn't an error: it just means there's nothing
// further to inherit from, so `partial`'s own declared kind/factory/refs
// stand as given (with the same object/[] fallbacks Direct mode already uses).
export function completeRecord(id: string, partial: RootConfig, parent: RootRecord | undefined): RootRecord {
  const refs = partial.refs !== undefined ? [...partial.refs] : (parent ? [...parent.refs] : []);
  return {
    id,
    kind:    partial.kind ?? 'root',
    factory: partial.factory !== undefined ? partial.factory : (parent?.factory ?? 'object'),
    props:   parseRefsIntoProps({ ...parent?.props, ...partial.props }, refs),
    items:   partial.items !== undefined ? [...partial.items] : [],
    refs,
  };
}

// Resolves `id` to a complete RootRecord, recursively completing its `kind`
// chain as needed. A record with no declared `kind` is treated as a direct
// child of 'root' — 'root' is the technically correct default parent for
// anything not otherwise positioned in the hierarchy (see the Nomenclature
// convention: any child of Root has kind 'root').
//
// `cache`, when supplied, is keyed by id and stores complete records (not
// just props) — a cache hit returns the already-resolved ancestor
// immediately, with no further walking. `visiting` guards against a `kind`
// cycle: if resolving `id`'s declared parent would re-enter an ancestor
// already being resolved on this same call stack, that link falls back to
// 'root' instead of recursing forever — every other ancestor's own true
// `kind` is unaffected.
//
// Only `id` itself (the specific ancestor a caller asked to resolve, at the
// top of this recursion) is required to exist in `registry` — that's a
// genuine caller error if missing, so it throws. Recursing further up from
// an already-found record is lenient: if *that* record's own declared `kind`
// doesn't resolve to anything (e.g. a dangling reference — see
// completeRecord()'s comment), there's simply nothing further to inherit
// from, not an error.
//
// Generic over which registry is passed in — the same function resolves
// ancestry against {@link recordRegistry} (or a collection's own scoped
// registry — see `getCollection.ts`) for both a product's requested `kind`
// and a factory's own identity.
export function resolveAncestorRecord(
  id: string,
  registry: Map<string, RootConfig>,
  cache: Map<string, RootRecord> | undefined,
  visiting: Set<string>
): RootRecord {
  if (id === 'root') return registry.get('root') as RootRecord; // always pre-registered, complete

  const cached = cache?.get(id);
  if (cached) return cached;

  const partial = registry.get(id);
  if (!partial) {
    throw new Error(`No record with id '${id}' found in the registry.`);
  }

  // Defaults come only from `extends`; `kind` is structural and never consulted here.
  let parent: RootRecord | undefined;
  if (partial.extends !== undefined) {
    if (visiting.has(partial.extends) || partial.extends === id) {
      throw new Error(`Record '${id}' extends '${partial.extends}', which would create a cycle (${[...visiting, id, partial.extends].join(' -> ')}).`);
    }
    if (partial.extends !== 'root' && !registry.has(partial.extends)) {
      throw new Error(`Record '${id}' extends '${partial.extends}', which is not registered.`);
    }
    visiting.add(id);
    parent = resolveAncestorRecord(partial.extends, registry, cache, visiting);
    visiting.delete(id);
  }

  const complete = completeRecord(id, partial, parent);
  cache?.set(id, complete);
  return complete;
}
