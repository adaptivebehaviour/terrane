import { createElement, type ComponentType, type ReactElement, type ReactNode } from 'react';
import {
  Root, RootRecord, RootConfig, Instance, rootInstance, rootRecord,
  generateId, recordRegistry, resolveAncestorRecord, completeRecord, parseRefsIntoProps,
} from './Root';
import type { Runnable } from './Runnable';
import { Factory, type FactoryCapability } from './Factory';
import { validateProduct } from './schema';

// This module is the low-level creation engine — build()/buildAsync()/
// buildInstance()/buildRecord()/buildComponent()/buildOperation() below.
// getCollection.ts wraps each of these in two friendlier layers under the
// `create`-verb names instead (`collection.create()`/`.createAsync()`/etc.,
// and the top-level `create()`/`createAsync()`/etc. convenience functions) —
// `build*` exists so those two layers can use the intuitive `create*` names
// without colliding with this module's own exports. Application code should
// reach for `getCollection.ts`'s exports, not this file's, unless it
// specifically needs the extra cache/target parameters this layer exposes.

// Re-exported for backward compatibility — recordRegistry now lives in
// Root.ts (see the comment below), but existing consumers (tests,
// manifesto/index.ts) import it from here.
export { recordRegistry } from './Root';

// ── Registries ─────────────────────────────────────────────────────────────────
// Every object created via the public factory functions is stored here, keyed
// by id. root is pre-registered so it is always available as a parent
// without any setup call.
//
// recordRegistry (Root.ts) is the *global, merged* view — every collection's
// records.json entries end up here, later collections overwriting earlier
// ones under the same id (see getCollection.ts). instanceRegistry and
// componentRegistry below are the equivalent global, merged views for
// factory dispatch. A {@link RegistryTarget} bundles all three so a
// collection-scoped `Collection` (via `getCollection(collectionId)`) can
// resolve against one specific collection's own, un-overridden entries
// instead — see getCollection.ts's own module comment for the full
// mechanism. Every function below defaults to the global registries when no
// `target`/`records` override is supplied, so ordinary (non-scoped) callers
// are unaffected.

/** Every {@link Root} instance ever created via {@link buildInstance}, keyed by id. Not collection-scoped — this tracks actually-created instances, not collection-declared configuration. */
export const instancesById = new Map<string, Root>([
  [rootInstance.id, rootInstance],
]);

/**
 * The argument type accepted by {@link buildRecord}, {@link buildInstance},
 * and {@link build} — an alias of {@link RootConfig}, since a call's
 * options and a collection's `records.json` entry are the same "partially
 * complete record" concept.
 */
export type CreateOptions = RootConfig;

/**
 * A bundle of the three factory-dispatch registries a `Collection` resolves
 * against. `getCollection()` (no id) uses the global, merged registries
 * below by default; `getCollection(collectionId)` instead passes one
 * specific collection's own scoped bundle, built fresh by `getCollection.ts`
 * on every call — see that file's module comment.
 */
export interface RegistryTarget {
  recordRegistry: Map<string, RootConfig>;
  instanceRegistry: Map<string, RecordInstance>;
  componentRegistry: Map<string, RecordComponent>;
}

// ── Private inheritance helper (instances) ────────────────────────────────────
// Used by buildInstance() when `extends` names a parent instance. instancesById
// holds only Root instances, which are always complete (the Root class fills in
// every field's default itself — see Root.ts, and an instance built with
// `extends` already merged its parent's defaults in when it was created), so the
// parent's own `props` are the entire inherited set — there is no chain to walk.
// `cache`, when supplied, is keyed by parent id (a Collection's own cache).

function resolveInheritedProps(
  parent: Root,
  cache?: Map<string, Record<string, unknown>>
): Record<string, unknown> {
  const cached = cache?.get(parent.id);
  if (cached) return cached;
  const resolved = { ...parent.props };
  cache?.set(parent.id, resolved);
  return resolved;
}

// ── Private colon-shorthand helper ────────────────────────────────────────────
// A string factory arg may take the form 'foo:bar', where everything after
// the first colon is shorthand for a single-element items array — e.g.
// 'crm:apple-whole' means { factory: 'crm', items: ['apple-whole'] }. Splits
// on the first colon only, so a value that itself contains a colon (a URL, a
// timestamp) round-trips unchanged. This makes ':' a reserved character in
// every factory key from here on — no existing key uses it.
//
// This is a blind, generic transform: it always targets items, regardless of
// which factory 'foo' is. A factory that reads its primary input from
// somewhere else (e.g. 'image', which reads props.url, not items) simply
// won't be affected by the shorthand — items would be set but never read,
// the same as passing an explicit, unread items array today. It is not an
// error to use the shorthand with such a factory, just a no-op beyond the
// ordinary object form.

function parseFactoryArg(arg: string): { factory: string; items?: unknown[] } {
  const i = arg.indexOf(':');
  return i === -1 ? { factory: arg } : { factory: arg.slice(0, i), items: [arg.slice(i + 1)] };
}

/**
 * {@link CreateOptions} widened to accept arbitrary extra top-level keys —
 * accepted only by {@link build}/{@link buildAsync}'s own `arg`/`options`
 * parameters (never `buildRecord`/`buildInstance`, which keep the stricter
 * {@link CreateOptions} shape), folded into `props` via
 * {@link foldExtraPropsIntoProps} before anything else runs.
 */
export type CreateOptionsWithExtraProps = CreateOptions & Record<string, unknown>;

const ROOT_CONFIG_KEYS = new Set(['id', 'kind', 'extends', 'factory', 'props', 'items', 'refs']);

// ── Private extra-props helper ────────────────────────────────────────────────
// A top-level key on an options object that isn't one of RootConfig's own
// fields is shorthand for placing it under `props` instead — e.g.
// `{ width: 32 }` means `{ props: { width: 32 } }`, and `{ props: { url: 'x' },
// width: 32 }` merges to `{ props: { url: 'x', width: 32 } }`. An explicit
// `props` entry wins on a conflicting key, since it's the caller's more
// deliberate designation — the loose top-level key is the inferred one.
//
// Deliberately keyed off RootConfig's *current* field set — this makes any
// future RootConfig field silently reinterpret a same-named loose key that
// used to fold into props as that new field instead. Documented here rather
// than guarded against, since RootConfig's field set changes rarely and
// deliberately, unlike a typo'd prop name (which this transform also can't
// distinguish from an intentional loose key — see this function's own
// module comment in create.ts's array-shorthand section for the same
// caller-trust tradeoff already made there).

function foldExtraPropsIntoProps(options: CreateOptionsWithExtraProps): CreateOptionsWithExtraProps {
  const extra: Record<string, unknown> = {};
  let hasExtra = false;
  for (const key of Object.keys(options)) {
    if (!ROOT_CONFIG_KEYS.has(key)) {
      extra[key] = options[key];
      hasExtra = true;
    }
  }
  if (!hasExtra) return options;
  const { id, kind, extends: extendsId, factory, props, items, refs } = options;
  return { id, kind, extends: extendsId, factory, items, refs, props: { ...extra, ...props } };
}

// build()/buildAsync()/buildProductAsync() each normalize their own `arg`/
// `options` through these two — array shorthand, then extra-props folding —
// into plain, narrow-typed values, rather than reassigning the wider
// `arg`/`options` parameters in place across multiple steps: TypeScript's
// control-flow narrowing doesn't reliably track a union-typed parameter
// through more than one sequential reassignment (confirmed — reassigning
// `arg` twice in place, once per normalization step, left `unknown[]`
// lingering in its narrowed type at later call sites even though it's
// unreachable at runtime). Returning a fresh, explicitly-typed value from a
// dedicated function sidesteps that entirely.

function normalizeCreateArg(arg: string | CreateOptionsWithExtraProps | unknown[]): string | CreateOptions {
  if (typeof arg === 'string') return arg;
  return foldExtraPropsIntoProps(Array.isArray(arg) ? { items: arg } : arg);
}

function normalizeCreateOptions(options: CreateOptionsWithExtraProps | unknown[]): CreateOptions {
  return foldExtraPropsIntoProps(Array.isArray(options) ? { items: options } : options);
}

// ── Private normalisation helper ──────────────────────────────────────────────
// Resolves the two calling conventions into a single options object.
//
//   String first arg → parsed via parseFactoryArg() and merged into options
//                       as { factory, items? } — overriding any factory (and,
//                       if the shorthand supplied one, any items) already
//                       present in options, the same override rule already
//                       applied to factory alone.
//   Object first arg → used as-is.
//
// Used as-is by buildInstance() — instancesById has no notion of "does this
// string name an existing instance", so a bare string there always means
// "build fresh with this factory" (now also carrying any colon-shorthand
// items). buildRecord() below does not call this directly for its bare,
// non-colon string case — see its own id-lookup check — since recordRegistry
// can answer exactly that question for records.

function normalise(
  arg: string | CreateOptions,
  options: CreateOptions
): CreateOptions {
  if (typeof arg !== 'string') return arg;
  const { factory, items } = parseFactoryArg(arg);
  return items !== undefined ? { ...options, factory, items } : { ...options, factory };
}

/**
 * Build a {@link Root} class instance.
 *
 * Direct mode      `buildInstance('text')`,
 *                  `buildInstance('text', { id, props, items, refs })`
 *
 * Inheritance mode `buildInstance('text', { kind: 'parent-id', ... })`,
 *                  `buildInstance({ kind: 'parent-id', ... })`
 *
 * In inheritance mode, `props` is merged from every ancestor up to `root`
 * (see `resolveInheritedProps()`), not just the immediate parent. Direct
 * mode's `kind` (via {@link Root}'s own constructor default) is `'root'` —
 * a real, resolvable child of root, not an inheritance opt-out.
 *
 * A string `arg` of the form `'factory:bar'` is shorthand for
 * `{ factory: 'factory', items: ['bar'] }` — see `parseFactoryArg()`'s own
 * comment for the exact rule (first colon only, items-only, no per-factory
 * meaning).
 *
 * Not collection-scoped — `instancesById` tracks actually-created instances
 * globally, regardless of which `Collection` created them; see this file's
 * own `RegistryTarget` comment.
 *
 * @param arg - A factory string (optionally `'factory:bar'` shorthand for
 *   `items: ['bar']`), or a {@link CreateOptions} object.
 * @param options - Additional options when `arg` is a string.
 * @param propsCache - Optional, keyed by ancestor id — a hit skips
 *   re-walking that ancestor's `kind` chain. `getCollection()` supplies each
 *   {@link getCollection.Collection} its own cache; omit it for a fresh resolution every
 *   call.
 * @returns The new {@link Root} instance, already registered in
 *   {@link instancesById} under its resolved id.
 * @throws If `options.kind` is given but no instance with that id exists in
 *   {@link instancesById}, or if the resolved id equals the parent's id.
 */
export function buildInstance(
  arg: string | CreateOptions,
  options: CreateOptions = {},
  propsCache?: Map<string, Record<string, unknown>>
): Root {
  const opts = normalise(arg, options);

  if (opts.extends !== undefined) {
    // ── Inheritance mode: defaults come from the instance named by `extends` ────
    const parent = instancesById.get(opts.extends);
    if (!parent) {
      throw new Error(`No instance with id '${opts.extends}' found in the registry.`);
    }
    const factory = opts.factory !== undefined ? opts.factory : parent.factory;
    const id = opts.id ?? generateId(factory);
    if (id === parent.id) {
      throw new Error(`Child id '${id}' must differ from parent id '${parent.id}'.`);
    }
    const child = new Root({
      id,
      kind:    opts.kind,
      factory,
      props:   { ...resolveInheritedProps(parent, propsCache), ...opts.props },
      items:   opts.items !== undefined ? opts.items : [],
      refs:    opts.refs  !== undefined ? opts.refs  : [...parent.refs],
    });
    instancesById.set(child.id, child);
    return child;
  }

  // ── Direct mode ────────────────────────────────────────────────────────────
  const factory = opts.factory ?? 'object';
  const id = opts.id ?? generateId(factory);
  const instance = new Root({
    id,
    kind:    opts.kind,
    factory,
    props:   opts.props,
    items:   opts.items,
    refs:    opts.refs,
  });
  instancesById.set(instance.id, instance);
  return instance;
}

/**
 * Build a complete {@link RootRecord} plain-data record. Accepts the same
 * calling conventions as {@link buildInstance}, plus one more: a bare
 * string that names an id already registered is treated as Inheritance mode
 * against that id, so `buildRecord('sanity-fetch')` inherits that record's
 * stored `props` the same as `buildRecord({ kind: 'sanity-fetch' })` would
 * — this is what lets a collection's `records.json` entry (e.g.
 * `sanity-fetch`'s `projectId`/`dataset`) reach a call site through nothing
 * more than its factory name. Only when the string doesn't match any
 * registered id does it fall back to Direct mode, exactly as before
 * (`{ factory: arg }`, empty `props`). This lookup is skipped — falling
 * through to the plain string-to-factory rule — when `options.kind` is
 * already given explicitly, so the documented
 * `buildRecord('text', { kind: 'parent-id' })` form (a different string
 * factory grafted onto an unrelated parent) is unaffected. Also skipped
 * whenever `arg` contains a colon — see the next paragraph — since a colon
 * form is never a registered-id lookup, regardless of whether the literal
 * string happens to match one.
 *
 * `arg` may also take the `'factory:bar'` shorthand form — everything after
 * the first colon becomes a single-element `items` array (see
 * `parseFactoryArg()`'s own comment), so `buildRecord('crm:apple-whole')`
 * is `buildRecord('crm', { items: ['apple-whole'] })`. This is resolved by
 * `normalise()` before Direct mode's plain string-to-factory rule ever runs.
 *
 * In inheritance mode, the parent named by `options.kind` is resolved to a
 * complete record first (see `resolveAncestorRecord()` in `Root.ts`) —
 * recursively completing its own `kind` chain up to `root` if the parent
 * itself is only partially declared (e.g. a collection's `records.json`
 * entry) — then merged with this call's own fields via `completeRecord()`
 * (`Root.ts`). Every `refs` string on the result is parsed (see
 * {@link parseRef}) and folded into `props` as the final step, so a parsed
 * value wins over an inherited/explicit prop of the same key. Direct mode's
 * `kind` defaults to `'root'` — always a resolvable ancestor — so a record
 * built this way can later be passed back in as `arg` (e.g. to
 * {@link buildOperation}) without throwing.
 *
 * @param arg - A factory string (resolved against `target.recordRegistry`
 *   first — see above; optionally `'factory:bar'` shorthand for
 *   `items: ['bar']`), or a {@link CreateOptions} object.
 * @param options - Additional options when `arg` is a string.
 * @param recordCache - Optional, keyed by id — stores complete records (not
 *   just merged props, unlike `buildInstance`'s cache), since an ancestor
 *   here may itself need completing before it's usable as a parent. A hit
 *   skips resolving that id entirely. `getCollection()` supplies each
 *   {@link getCollection.Collection} its own cache; omit it for a fresh resolution every
 *   call.
 * @param target - Which registry to resolve against — defaults to the
 *   global {@link recordRegistry}. `getCollection(collectionId)` passes that
 *   collection's own scoped registry instead, so `arg`'s bare-string lookup
 *   and `options.kind`'s ancestry both resolve against that collection's
 *   un-overridden view — see `getCollection.ts`'s module comment.
 * @returns The new complete {@link RootRecord}, registered under its
 *   resolved id in `target.recordRegistry` (and, if `target` is a
 *   collection-scoped registry distinct from the global one, in the global
 *   {@link recordRegistry} too, so it stays generally discoverable).
 * @throws If `options.kind` is given (explicitly, or implicitly via a
 *   matching string `arg`) but no record with that id exists in `target`,
 *   or if the resolved id equals the parent's id.
 */
export function buildRecord(
  arg: string | CreateOptions,
  options: CreateOptions = {},
  recordCache?: Map<string, RootRecord>,
  target?: Map<string, RootConfig>
): RootRecord {
  const records = target ?? recordRegistry;
  // A bare string naming a registered record means "start from that record's defaults".
  const opts =
    typeof arg === 'string' && !arg.includes(':') && options.extends === undefined && records.has(arg)
      ? { ...options, extends: arg }
      : normalise(arg, options);

  if (opts.extends !== undefined) {
    // ── Inheritance mode: defaults come from the record named by `extends` ──────
    const parent = resolveAncestorRecord(opts.extends, records, recordCache, new Set());
    const factory = opts.factory !== undefined ? opts.factory : parent.factory;
    const id = opts.id ?? generateId(factory);
    if (id === parent.id) {
      throw new Error(`Child id '${id}' must differ from parent id '${parent.id}'.`);
    }
    const record = completeRecord(id, opts, parent);
    validateProduct(record);
    records.set(record.id, record);
    if (records !== recordRegistry) recordRegistry.set(record.id, record);
    recordCache?.set(record.id, record);
    return record;
  }

  // ── Direct mode ────────────────────────────────────────────────────────────
  const factory = opts.factory ?? 'object';
  const id = opts.id ?? generateId(factory);
  const refs = opts.refs ? [...opts.refs] : [];
  const record: RootRecord = {
    id,
    kind:    opts.kind ?? 'root',
    factory,
    props:   parseRefsIntoProps(opts.props ? { ...opts.props } : {}, refs),
    items:   opts.items ? [...opts.items] : [],
    refs,
  };
  validateProduct(record);
  records.set(record.id, record);
  if (records !== recordRegistry) recordRegistry.set(record.id, record);
  recordCache?.set(record.id, record);
  return record;
}

// ── A factory's own resolved identity ─────────────────────────────────────────
// Resolves `factoryKey` against `records` via inheritance, exactly like any
// other record resolves its own ancestry. A factory key with no
// records.json-style entry there (most of them — only a factory with real
// defaults to declare needs one) simply gets the ordinary root-level
// default, matching Root's own constructor defaults — this is what makes
// registering a factory's own config entry optional, not required, for
// every factory.
//
// Exported (not just used internally by the generic Factory-default path
// below) so a custom instanceRegistry-registered class can replicate the
// same two-phase merge Factory.produce() provides, when it needs its own
// identity's declared defaults *and* something extra (e.g. `manifesto/
// ImageFactory.ts` resolving an items[0] element into its own props on top)
// — see that file's own comment for why composing with a plain Factory
// instance built from this is necessary rather than relying on the
// "existing path"'s buildRecord() alone.
export function resolveFactoryRecord(
  factoryKey: string,
  records: Map<string, RootConfig>,
  cache?: Map<string, RootRecord>
): RootRecord {
  if (factoryKey === 'root' || records.has(factoryKey)) {
    return resolveAncestorRecord(factoryKey, records, cache, new Set());
  }
  return { id: factoryKey, kind: 'root', factory: factoryKey, props: {}, items: [], refs: [] };
}

// ── Instance registry ─────────────────────────────────────────────────────────
// Maps a record's `factory` to the constructor responsible for building its
// instance form — push additional entries here as new instance types are
// added. 'object' is registered against the base Root class as the default.
// Any constructor pushed here must return something satisfying the
// Instance interface (see Root.ts) — a record() method is not optional.
//
// A factory key registered here always uses build()'s "existing path" (see
// build()'s own comment) — Factory.ts's two-phase produce() flow only
// applies to factory keys with *no* entry here.

/** A function that builds an {@link Instance} from a {@link RootRecord}. */
export type RecordInstance = (record: RootRecord) => Instance;

/**
 * Maps a record's `factory` to the {@link RecordInstance} constructor
 * responsible for building it. Push additional entries here as new instance
 * types are added — `'object'` is registered against the base {@link Root}
 * class as the default. This is the global, merged view — see this file's
 * `RegistryTarget` comment.
 */
export const instanceRegistry = new Map<string, RecordInstance>([
  ['object', (record) => new Root(record)],
]);

// ── buildComponent() ──────────────────────────────────────────────────────────
// Renders a record as a UI component instance (a ReactElement).
//
// componentRegistry maps a record's `factory` to the component responsible for
// rendering it. Deliberately empty here — this module has no UI dependency of
// its own. A collection registers its own components into it.
//
// 'factory' is dedicated to this lookup; 'kind' continues to record the
// object's position in the hierarchy (see Root.ts) and is not used here.

/** Props shared by every component dispatched through {@link componentRegistry}. */
export interface RecordComponentProps {
  record: RootRecord;
}

/**
 * A React component that renders a {@link RootRecord}: it receives `{ record }`
 * as props. {@link buildComponent} renders it with `createElement()`, so it is
 * a real component in React's tree — hooks inside it are safe, and a Client
 * Component imported from a `'use client'` module can be registered directly.
 */
export type RecordComponent = ComponentType<RecordComponentProps>;

/**
 * The legacy shape: a plain function from a record to something renderable,
 * called with the record itself rather than as a component. Adapt one with
 * {@link fromRecordFunction} to register it.
 */
export type RecordRenderer = (record: RootRecord) => ReactNode;

/**
 * A component that takes the record's own fields as props (and optional
 * `children`), e.g. `Stage`/`Scene`/`ContainerComponent`, so it can also be
 * used as `<Stage {...record}>`. Adapt one with {@link fromRecordProps}.
 */
export type RecordPropsComponent = ComponentType<RootRecord & { children?: ReactNode }>;

/**
 * Adapts a legacy `(record) => node` function into a {@link RecordComponent}.
 * The function now runs inside a component's render, so any hooks it calls are
 * safe (calling it directly from `buildComponent()` ran them in the *caller's*
 * render, which breaks as soon as the set of rendered records changes). Meant
 * for migrating code that still has renderer functions.
 */
export function fromRecordFunction(render: RecordRenderer, displayName?: string): RecordComponent {
  const component: RecordComponent = ({ record }) => render(record) as ReactElement | null;
  component.displayName = displayName ?? (render.name ? `fromRecordFunction(${render.name})` : 'fromRecordFunction');
  return component;
}

/**
 * Adapts a component that takes the record's own fields as props
 * (a {@link RecordPropsComponent}) into a {@link RecordComponent}.
 */
export function fromRecordProps(Component: RecordPropsComponent, displayName?: string): RecordComponent {
  const component: RecordComponent = ({ record }) => createElement(Component, record);
  component.displayName = displayName ?? `fromRecordProps(${Component.displayName ?? Component.name ?? 'Component'})`;
  return component;
}

function isRecord(value: unknown): value is RootRecord {
  return typeof value === 'object' && value !== null && typeof (value as RootRecord).factory === 'string';
}

export interface PropsComponentOptions<P> {
  /** Maps the record to the component's props. Default: `record.props`. */
  map?: (record: RootRecord) => P;
}

/**
 * Builds a {@link RecordComponent} from an ordinary typed-props component:
 * it renders `<Component {...props}>{children}</Component>`, where `props` is
 * `record.props` (or `options.map(record)`) and `children` are the record's
 * `items` — strings and plain values as they are, resolved child records
 * rendered through {@link buildComponent}.
 */
export function propsComponent<P extends object>(
  Component: ComponentType<P & { children?: ReactNode }>,
  options: PropsComponentOptions<P> = {}
): RecordComponent {
  const map = options.map ?? ((record: RootRecord) => record.props as unknown as P);
  const component: RecordComponent = ({ record }) => {
    const children = record.items.map((item, index) =>
      isRecord(item) ? createElement(RecordItem, { key: item.id ?? index, record: item }) : (item as ReactNode)
    );
    return createElement(Component, map(record) as P & { children?: ReactNode }, ...children);
  };
  component.displayName = `propsComponent(${Component.displayName ?? Component.name ?? 'Component'})`;
  return component;
}

// Renders a child record through the same registry the parent was dispatched
// from — the global one, which is what a propsComponent child sees.
const RecordItem: RecordComponent = ({ record }) => buildComponent(record);

/**
 * Registers a typed-props component under `key` in `target.componentRegistry`
 * in one line — see {@link propsComponent}.
 *
 * ```ts
 * registerPropsComponent(target, 'badge', Badge, { map: (record) => ({ label: String(record.props.label) }) });
 * ```
 */
export function registerPropsComponent<P extends object>(
  target: RegistryTarget,
  key: string,
  Component: ComponentType<P & { children?: ReactNode }>,
  options: PropsComponentOptions<P> = {}
): void {
  target.componentRegistry.set(key, propsComponent(Component, options));
}

/**
 * Maps a record's `factory` to the {@link RecordComponent} responsible for
 * rendering it. Starts empty — a collection registers its own entries here.
 * This is the global, merged view — see this file's `RegistryTarget` comment.
 */
export const componentRegistry = new Map<string, RecordComponent>();

/**
 * Render a record as a UI component instance.
 *
 * Looks up the {@link RecordComponent} registered in `components` (defaults
 * to the global {@link componentRegistry}) for `record.factory` and returns
 * `createElement(Component, { record, key: record.id })` — an element, not the
 * component's output, so the component renders as a real node in React's tree
 * and may use hooks.
 *
 * @param record - The record to render. Its `factory` selects the component.
 * @param components - Which registry to look the component up in — defaults
 *   to the global {@link componentRegistry}. `getCollection(collectionId)`
 *   passes that collection's own scoped registry instead.
 * @returns The rendered component instance.
 * @throws If no component is registered for `record.factory`.
 *
 * @example
 * ```ts
 * const record = { id: 'hello', kind: 'text', factory: 'text', props: {}, items: ['Hi!'], refs: [] };
 * const element = buildComponent(record); // same as <Text record={record} />
 * ```
 */
export function buildComponent(
  record: RootRecord,
  components: Map<string, RecordComponent> = componentRegistry
): ReactElement<RecordComponentProps> {
  const component = components.get(record.factory);
  if (!component) {
    throw new Error(`No component registered for factory '${record.factory}'.`);
  }
  return createElement(component, { record, key: record.id });
}

// True when a constructed instance also implements FactoryCapability (has a
// callable produce()) — used by both build() and buildAsync() to decide
// whether the "existing path" (a custom instanceRegistry entry) should
// render the instance as-is (the pre-existing Operation behaviour: Fetch,
// SanityFetch, HelloWorld) or call produce() to build a distinct product
// record first (a custom Factory-capable class, e.g. one that needs I/O to
// resolve its props). Previously, produce() was only ever invoked for the
// generic default Factory (the "new path" below) — this extends the same
// contract to instanceRegistry-registered classes too, so FactoryCapability
// means the same thing regardless of which path resolved the instance.
function isFactoryCapable(instance: Instance): instance is Instance & FactoryCapability {
  return typeof (instance as Partial<FactoryCapability>).produce === 'function';
}

// Resolves a string arg into build()/buildAsync()'s dispatch factory key
// and produce() options, honouring the 'factory:bar' shorthand (see
// parseFactoryArg()). Deliberately not just normalise(arg, options) — that
// would also fold `factory` itself into produceOptions, which
// Factory.produce() would then prefer over the factory instance's own
// resolved `this.factory`. That resolved value can legitimately differ from
// the raw dispatch key when a records.json entry declares a `factory` other
// than its own `id` (an aliasing case nothing currently uses, but the type
// allows); injecting the dispatch key back in as an override would silently
// clobber it. Folding in only the shorthand's own `items` (never `factory`)
// keeps that resolution path exactly as it was before this shorthand existed.
function resolveStringArg(
  arg: string,
  options: CreateOptions
): { factoryKey: string; produceOptions: CreateOptions } {
  const { factory, items } = parseFactoryArg(arg);
  return { factoryKey: factory, produceOptions: items !== undefined ? { ...options, items } : options };
}

/**
 * General-purpose factory. Resolves `arg` to a factory key (a string `arg`
 * is the key directly — optionally `'factory:bar'` shorthand for
 * `items: ['bar']`, see `parseFactoryArg()`; an object `arg` uses
 * `arg.factory ?? 'object'`), then dispatches down one of two paths:
 *
 * 1. **Existing path** — a custom constructor is registered in
 *    `target.instanceRegistry` (defaults to the global {@link instanceRegistry})
 *    for this factory key (an `Operation` like `Fetch`/`SanityFetch`/
 *    `HelloWorld`, or any future custom `FactoryCapability`). Builds the
 *    record via {@link buildRecord} exactly as before — including its
 *    bare-string-as-registered-id inheritance lookup — then constructs the
 *    instance. If that instance is also Factory-capable (has a callable
 *    `produce()`), calls it to build the product record instead of using the
 *    instance as-is — see {@link isFactoryCapable}. Otherwise (the
 *    pre-existing behaviour, unchanged: `Fetch`/`SanityFetch`/`HelloWorld`),
 *    renders the instance via `target.componentRegistry` if a component is
 *    registered for its factory, otherwise returns the instance itself.
 * 2. **New path** — no custom constructor is registered. Resolves the
 *    factory's own identity from `target.recordRegistry` (its own default
 *    `props`, if any were declared), constructs a generic {@link Factory}
 *    instance from it, and calls `produce(options, recordCache, target.recordRegistry)`
 *    to build the product record — see `Factory.ts`'s own module comment
 *    for the two-phase resolution model this implements. Renders the
 *    product via `target.componentRegistry` if registered for its factory,
 *    otherwise returns the plain record.
 *
 * `arg` and `options` each also accept a bare array as shorthand for
 * `{ items: array }` — e.g. `build(['bar'])` is `build({ items: ['bar'] })`
 * (factory defaults to `'object'`, same as any other factory-less object
 * `arg`), and `build('foo', ['bar'])` is `build('foo', { items: ['bar'] })`.
 * Resolved to a plain {@link CreateOptions} object before anything else in
 * this function runs, so every step below (including `buildRecord` and
 * `produce()`) sees the same `string | CreateOptions` shape it always has.
 *
 * An object `arg`/`options` also accepts arbitrary extra top-level keys
 * beyond {@link CreateOptions}'s own `id`/`kind`/`factory`/`props`/`items`/
 * `refs` — see {@link CreateOptionsWithExtraProps}. Any such key is folded
 * into `props` via {@link foldExtraPropsIntoProps} — e.g. `build('image',
 * { width: 32 })` is `build('image', { props: { width: 32 } })` — applied at
 * the same point as the array shorthand above, so everything below sees the
 * plain, already-folded `CreateOptions` shape either way.
 *
 * Either path's `produce()` call may legitimately return a `RootRecord`
 * directly (every existing factory) or, for a custom Factory-capable class
 * that needs I/O to build its product, a `Promise<RootRecord>` — this
 * synchronous function has no way to await the latter, so it throws rather
 * than silently returning an unresolved Promise as if it were a record. Call
 * {@link buildAsync} instead for a factory that may do this.
 *
 * @param arg - A factory string (optionally `'factory:bar'` shorthand for
 *   `items: ['bar']`), a {@link CreateOptionsWithExtraProps} object, or a
 *   bare array — shorthand for `{ items: array }`.
 * @param options - Additional options when `arg` is a string — also accepts
 *   a bare array, shorthand for `{ items: array }`.
 * @param recordCache - Forwarded to whichever path is taken — see
 *   {@link buildRecord}'s and `Factory.produce`'s own `cache`/`recordCache`
 *   parameters.
 * @param target - Which registries to resolve against — defaults to the
 *   global {@link recordRegistry}/{@link instanceRegistry}/
 *   {@link componentRegistry}. `getCollection(collectionId)` passes that
 *   collection's own scoped bundle instead — see `getCollection.ts`'s
 *   module comment.
 * @returns A record, an {@link Instance}, or a rendered React element, per
 *   the steps above.
 * @throws If a resolved `produce()` returns a `Promise` — see above.
 */
export function build(
  arg: string | CreateOptionsWithExtraProps | unknown[],
  options: CreateOptionsWithExtraProps | unknown[] = {},
  recordCache?: Map<string, RootRecord>,
  target?: RegistryTarget
): RootRecord | Instance | ReactElement<RecordComponentProps> {
  const normalizedArg = normalizeCreateArg(arg);
  const normalizedOptions = normalizeCreateOptions(options);

  const records = target?.recordRegistry ?? recordRegistry;
  const instances = target?.instanceRegistry ?? instanceRegistry;
  const components = target?.componentRegistry ?? componentRegistry;

  const { factoryKey, produceOptions } = typeof normalizedArg === 'string'
    ? resolveStringArg(normalizedArg, normalizedOptions)
    : { factoryKey: normalizedArg.factory ?? 'object', produceOptions: normalizedArg };

  const buildInstanceFn = instances.get(factoryKey);
  if (buildInstanceFn) {
    const record = buildRecord(normalizedArg, normalizedOptions, recordCache, records);
    const instance = buildInstanceFn(record);
    if (isFactoryCapable(instance)) {
      const product = instance.produce(produceOptions, recordCache, records);
      if (product instanceof Promise) {
        throw new Error(`Factory '${factoryKey}' returned a Promise from produce() — use createAsync() instead of create().`);
      }
      const component = components.get(product.factory);
      return component ? buildComponent(product, components) : product;
    }
    const component = components.get(instance.factory);
    return component ? buildComponent(instance.record(), components) : instance;
  }

  // ── New path — generic Factory default ────────────────────────────────────
  const factoryRecord = resolveFactoryRecord(factoryKey, records, recordCache);
  const factoryInstance = new Factory(factoryRecord);
  const product = factoryInstance.produce(produceOptions, recordCache, records);
  const component = components.get(product.factory);
  return component ? buildComponent(product, components) : product;
}

/**
 * Async core shared by {@link buildAsync} — resolves `arg` to a product (a
 * {@link RootRecord} or {@link Instance}) via the same two-path dispatch, but
 * stops short of the final "render if a component is registered" step.
 * {@link buildAsync} is a thin wrapper: it calls this, then renders the
 * result if `product.factory` has a registered component.
 *
 * Exists as its own export for a caller that specifically needs the
 * unrendered product itself — e.g. a Factory-capable class resolving its own
 * nested `items` into plain child records rather than pre-rendered elements,
 * so those records stay renderable later (by whatever eventually calls
 * {@link buildComponent} on them) instead of being collapsed into UI at
 * resolution time. `manifesto/factories/ContainerComponentFactory.ts` is the first
 * such caller.
 *
 * `arg`/`options` accept the same array shorthand and extra-top-level-key
 * folding as {@link build}'s own — see its doc comment.
 *
 * @param arg - Same as {@link buildAsync}'s own `arg` parameter.
 * @param options - Same as {@link buildAsync}'s own `options` parameter.
 * @param recordCache - Same as {@link buildAsync}'s own `recordCache` parameter.
 * @param target - Same as {@link buildAsync}'s own `target` parameter.
 * @returns The resolved {@link RootRecord} or {@link Instance}, never rendered.
 */
export async function buildProductAsync(
  arg: string | CreateOptionsWithExtraProps | unknown[],
  options: CreateOptionsWithExtraProps | unknown[] = {},
  recordCache?: Map<string, RootRecord>,
  target?: RegistryTarget
): Promise<RootRecord | Instance> {
  const normalizedArg = normalizeCreateArg(arg);
  const normalizedOptions = normalizeCreateOptions(options);

  const records = target?.recordRegistry ?? recordRegistry;
  const instances = target?.instanceRegistry ?? instanceRegistry;

  const { factoryKey, produceOptions } = typeof normalizedArg === 'string'
    ? resolveStringArg(normalizedArg, normalizedOptions)
    : { factoryKey: normalizedArg.factory ?? 'object', produceOptions: normalizedArg };

  const buildInstanceFn = instances.get(factoryKey);
  if (buildInstanceFn) {
    const record = buildRecord(normalizedArg, normalizedOptions, recordCache, records);
    const instance = buildInstanceFn(record);
    if (isFactoryCapable(instance)) {
      return instance.produce(produceOptions, recordCache, records);
    }
    return instance;
  }

  // ── New path — generic Factory default ────────────────────────────────────
  const factoryRecord = resolveFactoryRecord(factoryKey, records, recordCache);
  const factoryInstance = new Factory(factoryRecord);
  return factoryInstance.produce(produceOptions, recordCache, records);
}

/**
 * Async counterpart to {@link build} — identical dispatch, but awaits
 * `produce()` in both paths instead of rejecting a `Promise` result. Every
 * existing (synchronous) factory works unchanged here too — `await`ing a
 * plain, already-resolved value is a no-op. Use this instead of `build()`
 * whenever the factory being called might be a custom Factory-capable class
 * whose `produce()` needs to do I/O (e.g. fetching a document to resolve an
 * image's `url`) — see `Factory.ts`'s `FactoryCapability.produce()` comment.
 * Implemented as a thin wrapper over {@link buildProductAsync}, which does
 * the actual dispatch work.
 *
 * `arg` and `options` each also accept a bare array — shorthand for
 * `{ items: array }` — and arbitrary extra top-level keys, folded into
 * `props` — both the same as {@link build}'s own forms; see its doc comment.
 *
 * @param arg - A factory string (optionally `'factory:bar'` shorthand for
 *   `items: ['bar']`), a {@link CreateOptionsWithExtraProps} object, or a
 *   bare array — shorthand for `{ items: array }`.
 * @param options - Additional options when `arg` is a string — also accepts
 *   a bare array, shorthand for `{ items: array }`.
 * @param recordCache - Forwarded to whichever path is taken — see
 *   {@link build}'s own `recordCache` parameter.
 * @param target - Forwarded to whichever path is taken — see {@link build}'s
 *   own `target` parameter.
 * @returns A record, an {@link Instance}, or a rendered React element, per
 *   {@link build}'s own steps.
 */
export async function buildAsync(
  arg: string | CreateOptionsWithExtraProps | unknown[],
  options: CreateOptionsWithExtraProps | unknown[] = {},
  recordCache?: Map<string, RootRecord>,
  target?: RegistryTarget
): Promise<RootRecord | Instance | ReactElement<RecordComponentProps>> {
  const components = target?.componentRegistry ?? componentRegistry;
  const product = await buildProductAsync(arg, options, recordCache, target);
  const component = components.get(product.factory);
  if (!component) return product;
  const record = typeof (product as Partial<Instance>).record === 'function'
    ? (product as Instance).record()
    : (product as RootRecord);
  return buildComponent(record, components);
}

/**
 * Build a Runnable via {@link build} and immediately `run()` it.
 *
 * Uses {@link build}, not {@link buildInstance} — only `build()` consults
 * `instanceRegistry` to dispatch a record's `factory` to its registered
 * constructor (e.g. `HelloWorld`); `buildInstance()` always builds a plain
 * {@link Root}, regardless of `factory`. This is the one-liner calling
 * convention analogous to `AB/projects/operations/`'s module-level
 * `run(args)` function, e.g. `buildOperation('hello-world', { name: 'Drew' })`
 * instead of `(build('hello-world') as Runnable).run({ name: 'Drew' })`.
 *
 * @param arg - A factory string (optionally `'factory:bar'` shorthand for
 *   `items: ['bar']`), or a {@link CreateOptions} object.
 * @param args - Forwarded to the resolved instance's `run()`.
 * @param recordCache - Forwarded to {@link build} — see its own
 *   `recordCache` parameter.
 * @param target - Forwarded to {@link build} — see its own `target` parameter.
 * @returns Whatever the resolved instance's `run()` returns.
 * @throws If the resolved value has no `run()` method (i.e. its factory is
 *   not registered against a Runnable).
 */
export function buildOperation(
  arg: string | CreateOptions,
  args?: unknown,
  recordCache?: Map<string, RootRecord>,
  target?: RegistryTarget
): unknown | Promise<unknown> {
  // CreateOptions (RootConfig) has no index signature, so it doesn't
  // structurally satisfy CreateOptionsWithExtraProps's Record<string, unknown>
  // half even though every CreateOptions value trivially qualifies (zero
  // extra keys) — hence the double cast, not a real type-hole.
  const result = build(arg as unknown as string | CreateOptionsWithExtraProps, {}, recordCache, target);
  if (typeof (result as Partial<Runnable>).run !== 'function') {
    const factory = typeof arg === 'string' ? parseFactoryArg(arg).factory : arg.factory;
    throw new Error(`'${factory}' is not Runnable.`);
  }
  return (result as Runnable).run(args);
}
