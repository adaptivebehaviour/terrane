import { Root, type RootRecord, type Instance } from './Root';
import type { FactoryCapability, ProduceOptions } from './Factory';
import { buildProductAsync, type CreateOptionsWithExtraProps } from './create';

/**
 * True when `item` is an explicit `[arg, options]` pair rather than a bare
 * create-arg — a 2-element array whose first element is a `string` and
 * whose second element is a plain (non-array) object. Deliberately narrow:
 * this is the one array shape that would otherwise turn into a fairly
 * unusual `{ items: [...] }` request under the ordinary top-level array
 * shorthand (`build()`'s own `Array.isArray(arg) → { items: arg }`), so
 * claiming it here doesn't meaningfully compete with that existing meaning.
 * Any other array shape (wrong length, or elements that don't match this
 * pattern) falls through to ordinary `arg` resolution unchanged — including
 * a plain array item, which still means what it always has via the
 * top-level array shorthand.
 *
 * Restricted to a *string* first element on purpose, not "string or plain
 * object" — when `arg` is an object, `buildProductAsync()`'s own dispatch
 * uses that object directly as `produceOptions` and silently ignores a
 * separate `options` argument entirely (`{ factoryKey: arg.factory ??
 * 'object', produceOptions: arg }`). Allowing `[objectArg, options]` as a
 * tuple would mean the `options` half is quietly dropped — exactly the kind
 * of silent misbehaviour this codebase avoids elsewhere. A caller with an
 * object `arg` should fold any extra options directly into that object
 * instead (e.g. `{ factory: 'text', items: ['Hi!'], props: {...} }`), which
 * already works via the ordinary bare-object item form.
 */
function isArgOptionsTuple(
  item: unknown
): item is [string, CreateOptionsWithExtraProps] {
  if (!Array.isArray(item) || item.length !== 2) return false;
  const [arg, options] = item;
  const optionsIsValid = typeof options === 'object' && options !== null && !Array.isArray(options);
  return typeof arg === 'string' && optionsIsValid;
}

/**
 * Resolves one raw `items` entry into a plain, complete {@link RootRecord}
 * — never a rendered element. Uses {@link buildProductAsync} rather than
 * the friendlier `createAsync()` (`getCollection.ts`) specifically because
 * that one auto-renders into a component when its resolved factory has one
 * registered; storing an already-rendered element back onto a record's
 * `items` would break the "items is plain content" convention everywhere
 * else in this codebase relies on. An `Instance` result (e.g. a resolved
 * `Fetch`/`HelloWorld`, or any bare `Root`) is normalised via its own
 * `.record()` so every stored item is uniformly record-shaped; rendering
 * (and throwing if a given item's factory has no registered component)
 * happens later, at actual render time.
 *
 * `item` may be a bare create-arg (a factory string, optionally
 * `'factory:bar'` shorthand, or a {@link CreateOptionsWithExtraProps}
 * object) or an explicit `[arg, options]` pair — see {@link isArgOptionsTuple}.
 */
export async function resolveItemRecord(item: unknown, cache?: Map<string, RootRecord>): Promise<RootRecord> {
  const [arg, options] = isArgOptionsTuple(item)
    ? item
    : [item as string | CreateOptionsWithExtraProps, undefined];
  const resolved = await buildProductAsync(arg, options, cache);
  return typeof (resolved as Partial<Instance>).record === 'function'
    ? (resolved as Instance).record()
    : (resolved as RootRecord);
}

/**
 * Factory-capable base class for "my `items` are always create-args" — the
 * general form `manifesto/factories/ContainerComponentFactory.ts` (factory
 * `'component'`) was first built as, now extracted here so any other
 * collection can build the same kind of factory. Resolves every element of
 * `items` into its own resolved child record (see {@link resolveItemRecord}),
 * replacing the caller's raw items with the resolved ones on the returned
 * product.
 *
 * `produce()` is unconditionally `async`: an `items` element may itself
 * name a factory that needs I/O to resolve (e.g. a Sanity-backed factory),
 * and — matching the precedent set by `SanityCrmFactory` — that
 * possibility is a property of this factory as a whole, not something
 * decided per call based on what a given call's `items` happen to contain.
 * Every call must therefore use `createAsync(...)`, never a plain,
 * synchronous `create(...)`.
 *
 * Preserves the two-phase resolution the generic {@link Factory} default
 * provides (a real `kind` ancestor's props merged with this factory's own
 * declared defaults) via `this.record()`, which already reflects that same
 * merge by the time `produce()` runs (see `buildRecord()` in `create.ts`)
 * — only `items` needs further resolution. This works for a factory with no
 * declared defaults of its own (like `'component'`); a factory that *does*
 * have real declared defaults and also needs `items` resolution should
 * extend {@link ItemFactory} instead and compose with {@link Factory}
 * directly — see `manifesto/factories/ImageFactory.ts`'s own comment for why.
 */
export class ContainerFactory extends Root implements FactoryCapability {
  async produce(_options: ProduceOptions = {}, cache?: Map<string, RootRecord>): Promise<RootRecord> {
    const base = this.record();
    const items = await this.resolveItemRecords(base.items, cache);
    return { ...base, items };
  }

  /**
   * The "creating records" step of `produce()` — resolves every raw `items`
   * entry into its own complete {@link RootRecord} (see
   * {@link resolveItemRecord}). Broken out from `produce()` as its own
   * overridable method so a subclass can customise *how* raw item specs
   * become records (e.g. filtering some out, injecting extra props into
   * each) without having to reimplement `produce()`'s own record-assembly
   * (the `{ ...base, items }` merge above) too.
   *
   * @param items - The raw, unresolved `items` array — bare create-args,
   *   options objects, or `[arg, options]` tuples (see
   *   {@link resolveItemRecord}).
   * @param cache - Forwarded to {@link resolveItemRecord}.
   */
  resolveItemRecords(items: unknown[], cache?: Map<string, RootRecord>): Promise<RootRecord[]> {
    return Promise.all(items.map((item) => resolveItemRecord(item, cache)));
  }
}
