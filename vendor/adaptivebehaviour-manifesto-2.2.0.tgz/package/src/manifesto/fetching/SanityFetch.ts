import { Operation, OperationResult, type ArgSpec } from '../../Runnable';
import type { RootConfig } from '../../Root';
import type { SecretResolver } from './Fetch';
import { formatIssues } from '../../schema';
import { sanityDocumentSchema } from '../schemas';
import { fetchSanityGroq } from './sanityGroq';

/**
 * Factory `sanity-fetch` — fetches a single Sanity document by its
 * document-defined `id` field.
 *
 * Uses the GROQ query endpoint (`/data/query/`), not the `/data/doc/`
 * doc-fetch endpoint — that endpoint looks documents up by Sanity's own
 * system `_id`, but the identifier this operation is handed (e.g.
 * `'apple-whole'`) is the document's own `id` field, a separate,
 * schema-defined property. The query is `*[id == $id][0]`, so the result is
 * either a single matching document or `null`. The actual query/auth/fetch
 * work is done by {@link fetchSanityGroq} (`sanityGroq.ts`) — shared with
 * `SanityFetchMany` — this class owns only its own arg validation, query
 * shape, and found/not-found policy on top of that.
 *
 * `props` configure the project the document is fetched from (constructor
 * time, same convention as {@link Fetch}'s `baseUrl`/`authScheme`):
 * - `projectId` (required) — the Sanity project id.
 * - `dataset` — defaults to `'production'`.
 * - `apiVersion` — defaults to `'2024-01-01'`; any dated version accepted by
 *   Sanity's `/data/query/` endpoint works.
 * - `tokenEnvVar` — defaults to `'SANITY_TOKEN_READ'`; the secret identifier
 *   resolved (via the `resolveSecret` passed to `run()`/`execute()`) and
 *   sent as `Authorization: Bearer <token>`. Only the identifier lives on
 *   the record/props — never the token value itself, so it stays safe to
 *   store in a git-tracked `records.json`.
 *
 * `id` (the document to fetch, matched against the document's own `id`
 * field) is the one run-time argument — see `argSpecs` — so the same
 * configured operation can fetch different documents across calls.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const record = (collection.create('sanity-fetch', {
 *   props: { projectId: 'myprojectid' },
 * }) as SanityFetch).record();
 *
 * // Later, from that same record — construct again and fetch a document:
 * const result = await new SanityFetch(record).run({ id: 'abc123' }, (name) => process.env[name]);
 * ```
 */
export class SanityFetch extends Operation {
  static argSpecs: ArgSpec[] = [
    { id: 'id', type: 'string', help: 'Id of the Sanity document to fetch', required: true },
  ];

  constructor(config: RootConfig = {}) {
    super(config);
  }

  /**
   * Fetch the Sanity document identified by `args.id`.
   *
   * @param args - Coerced arguments, per `argSpecs` — just `id`.
   * @param resolveSecret - Resolves `props.tokenEnvVar` to the real token;
   *   required since every Sanity document fetch is authenticated.
   * @returns An {@link OperationResult} whose `.payload.document` is the
   *   fetched document — an error result if `props.projectId` is missing,
   *   the token can't be resolved, the request fails, or no document with
   *   that id exists.
   */
  async execute(args: Record<string, unknown>, resolveSecret?: SecretResolver): Promise<OperationResult> {
    const documentId = args.id as string | undefined;
    if (!documentId) {
      return OperationResult.error(`'${this.factory}' requires an 'id' argument.`);
    }

    const response = await fetchSanityGroq({
      props: this.props,
      factory: this.factory,
      query: '*[id == $id][0]',
      params: { $id: JSON.stringify(documentId) },
      describe: `document with id '${documentId}'`,
      errorPayload: { id: documentId },
      resolveSecret,
    });
    if (!response.ok) {
      return response.error;
    }

    const document = response.result;
    if (!document) {
      return OperationResult.error(`Sanity document with id '${documentId}' was not found.`, 1, { id: documentId });
    }

    // The response body is data from outside the system: check its shape before handing it on.
    const checked = sanityDocumentSchema.safeParse(document);
    if (!checked.success) {
      return OperationResult.error(
        `Sanity document with id '${documentId}' has an unexpected shape:\n  ${formatIssues('result', checked.error).join('\n  ')}`,
        1,
        { id: documentId }
      );
    }

    return OperationResult.ok(JSON.stringify(document), { id: documentId, document });
  }

  /**
   * Entry point for import and instance-method use. Overrides
   * {@link Operation.run} to thread an optional {@link SecretResolver}
   * through to {@link execute}, same pattern as {@link Fetch.run}.
   *
   * @param args - `{ id }` — the document to fetch.
   * @param resolveSecret - Forwarded to {@link execute}.
   */
  async run(args?: unknown, resolveSecret?: SecretResolver): Promise<string> {
    const coerced = (args ?? {}) as Record<string, unknown>;
    const result = await this.execute(coerced, resolveSecret);
    return result.text;
  }
}

/**
 * Import entry point. `config` is treated as `{ props, id }` — `props`
 * configures the operation (`projectId`/`dataset`/...) at construction time,
 * same split as `Fetch.ts`'s own module-level `run()`; `id` is passed
 * through as the run-time argument. `resolveSecret` is forwarded unchanged.
 */
export function run(config?: unknown, resolveSecret?: SecretResolver): Promise<string> {
  const { props, ...args } = (config ?? {}) as RootConfig & Record<string, unknown>;
  return new SanityFetch({ factory: 'sanity-fetch', props }).run(args, resolveSecret);
}
