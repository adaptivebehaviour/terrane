import { Operation, OperationResult, type ArgSpec } from '../../Runnable';
import type { RootConfig } from '../../Root';
import { propsOf } from '../../schema';
import { fetchProps } from '../schemas';

/**
 * Resolves an env-var-style secret identifier (e.g. `'SANITY_TOKEN_READ'`) to its
 * actual value. Injected by the caller — `Fetch` never reads `process.env`
 * (or any other secret store) itself, so it stays usable in contexts with no
 * such global (e.g. a browser bundle) as long as no resolver-requiring
 * `authScheme` is in play. An implementation that reads real secrets must
 * guarantee it only ever runs server-side — see
 * `nextjs/src/app/lib/secrets.ts` for the one used by the Next.js app.
 */
export type SecretResolver = (envVarName: string) => string | undefined;

/**
 * Factory `fetch` — resolves a `baseUrl` prop and `items` (path segments)
 * into a `url` prop at construction time, then fetches that url on `run()`.
 *
 * Construction is synchronous and side-effect-free: `props.url` is derived
 * and folded into the record the moment a `Fetch` is built, so a record
 * built via `create('fetch', {...})` (or `.record()` on the instance)
 * already carries its resolved `url` — usable by anything that wants it
 * (e.g. a client component rendering an image) without ever calling
 * `run()`. `run()`/`execute()` is the separate, async step that actually
 * performs the GET.
 *
 * `props.authScheme` controls how the request is authenticated:
 * - `undefined` / `'none'` — a plain `fetch(url)`, no extra headers.
 * - `'bearer'` — `props.tokenEnvVar` names the secret to resolve (via the
 *   `resolveSecret` passed to `run()`/`execute()`) and send as
 *   `Authorization: Bearer <token>`. Only the identifier lives on the
 *   record/props — never the token value itself, so it stays safe to store
 *   in a git-tracked `records.json`.
 * - any other value — `execute()` returns an error result rather than
 *   silently sending an unauthenticated request.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const record = (collection.create('fetch', {
 *   items: ['foo'],
 *   props: { baseUrl: 'https://myapi.com', width: 32, height: 32 },
 * }) as Fetch).record();
 * // record.props.url === 'https://myapi.com/foo'
 *
 * // Later, from that same record — construct again and actually fetch:
 * const result = await new Fetch(record).run();
 *
 * // A record requiring a bearer token, resolved by the caller:
 * const authed = new Fetch({
 *   factory: 'fetch',
 *   items: ['assets'],
 *   props: { baseUrl: 'https://api.sanity.io', authScheme: 'bearer', tokenEnvVar: 'SANITY_TOKEN_READ' },
 * });
 * await authed.run(undefined, (name) => process.env[name]);
 * ```
 */
export class Fetch extends Operation {
  static argSpecs: ArgSpec[] = [];

  constructor(config: RootConfig = {}) {
    const props = { ...config.props };
    const items = config.items ?? [];
    if (typeof props.baseUrl === 'string' && items.length > 0) {
      const base = props.baseUrl.replace(/\/+$/, '');
      const path = items.map((item) => String(item)).join('/');
      props.url = `${base}/${path}`;
    }
    super({ ...config, props });
  }

  /**
   * Fetch `this.props.url`, derived at construction time (see class doc).
   * Never re-derives or re-reads `baseUrl`/`items` here — `url` is already
   * whatever the constructor computed.
   *
   * @param _args - Unused; `Fetch` has no run-time arguments of its own,
   *   everything relevant was already resolved into `props` at construction.
   * @param resolveSecret - Required only when `props.authScheme` is
   *   `'bearer'`; resolves `props.tokenEnvVar` to the real token. Omitted
   *   entirely for unauthenticated fetches.
   * @returns An {@link OperationResult} whose `.payload` is the parsed JSON
   *   body (or raw text, if the body isn't valid JSON) — an error result if
   *   `url` is missing, `authScheme` can't be satisfied, or the request
   *   fails.
   */
  async execute(_args: Record<string, unknown>, resolveSecret?: SecretResolver): Promise<OperationResult> {
    const props = propsOf(fetchProps, this);
    const url = props.url;
    if (!url) {
      return OperationResult.error(
        `'${this.factory}' has no url to fetch — set props.baseUrl and items before calling run().`
      );
    }

    const headers: Record<string, string> = {};
    const authScheme = props.authScheme;
    if (authScheme === 'bearer') {
      const tokenEnvVar = props.tokenEnvVar;
      if (!tokenEnvVar) {
        return OperationResult.error(`'${this.factory}' has authScheme 'bearer' but no props.tokenEnvVar set.`);
      }
      const token = resolveSecret?.(tokenEnvVar);
      if (!token) {
        return OperationResult.error(
          `'${this.factory}' could not resolve secret '${tokenEnvVar}' — is it set, and was a resolveSecret provided?`
        );
      }
      headers.Authorization = `Bearer ${token}`;
    } else if (authScheme !== undefined && authScheme !== 'none') {
      return OperationResult.error(`'${this.factory}' has unsupported authScheme '${authScheme}'.`);
    }

    let response: Response;
    try {
      response = await fetch(url, Object.keys(headers).length > 0 ? { headers } : undefined);
    } catch (err) {
      return OperationResult.error(`Fetch of '${url}' failed: ${(err as Error).message}`, 1, { url });
    }
    if (!response.ok) {
      return OperationResult.error(`Fetch of '${url}' failed: ${response.status} ${response.statusText}`, 1, {
        url,
        status: response.status,
      });
    }

    const bodyText = await response.text();
    let data: unknown;
    try {
      data = JSON.parse(bodyText);
    } catch {
      data = bodyText;
    }
    const text = typeof data === 'string' ? data : JSON.stringify(data);
    return OperationResult.ok(text, { url, data });
  }

  /**
   * Entry point for import and instance-method use. Overrides
   * {@link Operation.run} to thread an optional {@link SecretResolver}
   * through to {@link execute} — `Fetch` has no run-time `argSpecs`
   * (everything meaningful is constructor-time), so this bypasses
   * `Operation.run()`'s `coerceArgs()` machinery entirely rather than
   * duplicating it for no reason.
   *
   * @param _args - Unused; kept only for signature parity with
   *   {@link Operation.run}.
   * @param resolveSecret - Forwarded to {@link execute}.
   */
  async run(_args?: unknown, resolveSecret?: SecretResolver): Promise<string> {
    const result = await this.execute({}, resolveSecret);
    return result.text;
  }
}

/**
 * Import entry point. Unlike `HelloWorld`'s `run()` — whose args are
 * run-time — `Fetch`'s meaningful input (`items`/`props.baseUrl`) is
 * constructor-time, so this builds a fresh `Fetch` from `args` (treated as
 * `{ items, props }`) and runs it immediately. `resolveSecret` is forwarded
 * unchanged — omit it for fetches that don't need one.
 */
export function run(args?: unknown, resolveSecret?: SecretResolver): Promise<string> {
  const config = (args ?? {}) as RootConfig;
  return new Fetch({ factory: 'fetch', ...config }).run(undefined, resolveSecret);
}
