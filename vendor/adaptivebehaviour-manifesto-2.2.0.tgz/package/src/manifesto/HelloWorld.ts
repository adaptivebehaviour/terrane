import { Operation, OperationResult, type ArgSpec } from '../Runnable';

/**
 * Factory `hello-world` — greets by name. Ported from
 * AB/projects/operations/hello_world.py as the worked example of a Runnable
 * object in manifesto.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * await collection.createOperation('hello-world', { name: 'Drew', shout: true });
 * ```
 */
export class HelloWorld extends Operation {
  static argSpecs: ArgSpec[] = [
    { id: 'name', type: 'string', help: 'Name to greet', default: 'world' },
    { id: 'shout', type: 'boolean', help: 'Print the greeting in upper case' },
  ];

  /**
   * Build the greeting.
   *
   * @param args - Coerced arguments — `name` (defaults to `'world'`) and `shout`.
   * @returns An {@link OperationResult} whose `.text` is the greeting and
   *   whose `.payload` carries the resolved `name`/`shout` values.
   */
  execute(args: Record<string, unknown>): OperationResult {
    const name = (args.name as string) ?? 'world';
    const shout = Boolean(args.shout);
    const text = shout ? `Hello, ${name}!`.toUpperCase() : `Hello, ${name}!`;
    return OperationResult.ok(text, { name, shout });
  }
}

/**
 * Import entry point; creates a {@link HelloWorld} and calls its `run()`.
 * The JS analogue of AB/projects/operations/hello_world.py's module-level
 * `run()`.
 */
export function run(args?: unknown): string | Promise<string> {
  return new HelloWorld({ factory: 'hello-world' }).run(args);
}
