import { Root, type RootRecord, type RootConfig } from '../../Root';
import type { FactoryCapability, ProduceOptions } from '../../Factory';
import { Factory } from '../../Factory';
import { resolveFactoryRecord, recordRegistry } from '../../create';
import { resolveOnlyItem } from '../../ItemFactory';

/**
 * Factory `'image'` — resolves an optional single `items[0]` element (e.g.
 * a nested `'crm:...'` fetch) into this image's own `props`, on top of the
 * ordinary two-phase resolution (this factory's own declared `records.json`
 * defaults merged with a real `kind` ancestor's props) the generic
 * {@link Factory} default previously provided for `'image'` on its own.
 * Registered in `instanceRegistry` (see `index.ts`), replacing that generic
 * default.
 *
 * Conceptually an `ItemFactory` (see `ItemFactory.ts`) — but doesn't
 * literally extend it. `ItemFactory`'s own `produce()` is unconditionally
 * `async`, and `'image'` has real backward-compatibility to preserve: the
 * overwhelming majority of existing/expected `'image'` usage passes no
 * `items` at all, and forcing every such call through `createAsync()`
 * would be a large, disruptive breaking change for no benefit (unlike
 * `'component'`/`ContainerFactory`, where *every* use case already goes
 * through `items` resolution, so committing to async unconditionally costs
 * nothing extra). So `produce()` here stays a plain, non-`async` function
 * that conditionally returns a synchronous `RootRecord` when no items are
 * given — via a plain, temporary {@link Factory} instance, so the ordinary
 * two-phase merge behaves exactly as it did before this class existed — and
 * only returns a `Promise<RootRecord>` (via {@link resolveOnlyItem},
 * `ItemFactory.ts`'s shared, exported resolution+warning logic) when an
 * item is actually present to resolve. This is the same reason
 * `manifesto/factories/ContainerComponentFactory.ts` couldn't literally extend the
 * generic `Factory` class either — TypeScript's return-type covariance
 * doesn't allow overriding a method with a differently-"colored" (sync vs.
 * conditionally-async) signature, so composition takes the place of
 * inheritance here.
 *
 * Why composing with a fresh `Factory` instance (via {@link resolveFactoryRecord})
 * rather than just using `this.record()` (the way `ContainerFactory`/
 * `ContainerComponentFactory` do): `this.record()` only correctly carries `'image'`'s
 * own declared defaults when the caller's `options.kind` is left
 * unspecified (via `buildRecord()`'s "bare string as registered id" rule).
 * When `options.kind` *is* given explicitly — e.g. positioning an image
 * under `'profile-card'`, merging that ancestor's own props too — that rule
 * doesn't apply, and `this.record()` would be missing `'image'`'s own
 * declared `url`/`width`/`height`/`alt` defaults entirely. Re-resolving
 * `'image'`'s own identity via `resolveFactoryRecord()` and handing it to a
 * plain `Factory` instance replicates the *exact* two-phase merge the
 * generic default always provided, regardless of whether `kind` was given.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * collection.create('image', { props: { url: 'avatar.jpg' } }); // unchanged, still synchronous
 * await collection.createAsync('image', { items: ['crm:apple-whole'] }); // new — resolves items[0] into props
 * ```
 */
export class ImageFactory extends Root implements FactoryCapability {
  produce(
    options: ProduceOptions = {},
    cache?: Map<string, RootRecord>,
    records: Map<string, RootConfig> = recordRegistry
  ): RootRecord | Promise<RootRecord> {
    const rawItems = (options.items ?? []) as unknown[];
    const factoryRecord = resolveFactoryRecord(this.factory, records, cache);
    const factoryInstance = new Factory(factoryRecord);

    if (rawItems.length === 0) {
      return factoryInstance.produce(options, cache, records);
    }

    return resolveOnlyItem(rawItems, this.factory, cache).then((resolvedItem) => ({
      ...factoryInstance.produce(
        { ...options, props: { ...resolvedItem?.props, ...options.props } },
        cache,
        records
      ),
      items: [],
    }));
  }
}
