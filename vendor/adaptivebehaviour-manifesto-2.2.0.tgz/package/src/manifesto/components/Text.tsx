import type { RecordComponent } from '../../create';
import { propsOf } from '../../schema';
import { styledProps, toCss } from '../schemas';

/** Factory `'text'` — renders each string in `record.items` as its own paragraph. */
export const Text: RecordComponent = ({ record }) => (
  <div data-id={record.id} data-factory="text" style={toCss(propsOf(styledProps, record).styling)}>
    {record.items.map((item, index) => (
      <p key={index}>{item as string}</p>
    ))}
  </div>
);
