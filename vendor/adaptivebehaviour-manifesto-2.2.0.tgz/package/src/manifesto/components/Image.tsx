import type { RecordComponent } from '../../create';
import { propsOf } from '../../schema';
import { imageProps, toCss } from '../schemas';

/**
 * Factory `'image'` — renders `record.props.url` as an image.
 *
 * `url`/`alt`/`width`/`height` defaults are no longer looked up here —
 * `create('image', ...)` resolves them automatically before this component
 * ever runs, via `records.json`'s `'image'` entry and `Factory.ts`'s
 * `produce()` (see that file's module comment). This component only ever
 * needs to read `record.props` directly.
 */
export const Image: RecordComponent = ({ record }) => {
  const props = propsOf(imageProps, record);
  return (
    <img
      data-id={record.id}
      data-factory="image"
      src={props.url}
      alt={props.alt}
      style={{
        width: props.width,
        height: props.height,
        ...toCss(props.styling),
      }}
    />
  );
};
