import { z } from 'zod';
import type { CSSProperties } from 'react';

// Props schemas for the base collection's factories. `z.looseObject`: a record may carry props a
// schema does not name; only the ones named here are checked and typed.

/** Inline styles as written in a record (`props.styling`): property name -> string or number. */
export const cssProperties = z.record(z.string(), z.union([z.string(), z.number()])).meta({ id: 'CssProperties' });

/**
 * The one place a record's style map is typed as React's `CSSProperties` (a record of string/number
 * cannot be assigned to it without a cast, because `CSSProperties` names every property).
 */
export function toCss(styling: z.infer<typeof cssProperties> | undefined): CSSProperties | undefined {
  return styling as CSSProperties | undefined;
}

export const rootProps = z.looseObject({}).meta({ id: 'RootProps' });

/** `component`, `item-component` and `text`: a wrapper that may be styled. */
export const styledProps = z.looseObject({ styling: cssProperties.optional() }).meta({ id: 'StyledProps' });

export const imageProps = z.looseObject({
  url: z.string().optional(),
  alt: z.string().optional(),
  width: z.union([z.string(), z.number()]).optional(),
  height: z.union([z.string(), z.number()]).optional(),
  styling: cssProperties.optional(),
}).meta({ id: 'ImageProps' });

export const helloWorldProps = z.looseObject({}).meta({ id: 'HelloWorldProps' });

export const fetchProps = z.looseObject({
  baseUrl: z.string().optional(),
  url: z.string().optional(),
  authScheme: z.string().optional(),
  tokenEnvVar: z.string().optional(),
}).meta({ id: 'FetchProps' });

export const sanityProps = z.looseObject({
  projectId: z.string().optional(),
  dataset: z.string().optional(),
  apiVersion: z.string().optional(),
  tokenEnvVar: z.string().optional(),
}).meta({ id: 'SanityProps' });

/** A Sanity document as the fetch operations return it: any object (their own fields vary). */
export const sanityDocumentSchema = z.looseObject({}).meta({ id: 'SanityDocument' });
export const sanityDocumentsSchema = z.array(sanityDocumentSchema);
