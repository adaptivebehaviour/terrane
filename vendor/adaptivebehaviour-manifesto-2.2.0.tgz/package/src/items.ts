/**
 * Normalizes a value that may arrive as a single item, an array of items, or
 * `null`/`undefined` into one canonical shape: always an array, never a bare
 * item and never `null`/`undefined`. `null`/`undefined` collapse to `[]` —
 * there is no separate "no result" state, only "zero items".
 *
 * Meant to run exactly once, at the boundary where a value crosses in from
 * outside this codebase's own always-array `items` convention (see
 * `RootRecord.items` in `Root.ts`) — e.g. a Sanity GROQ result (`*[id in
 * $ids]` yields an array, `*[id == $id][0]` yields a single document or
 * `null`) or a parsed directive argument (`resolveArgs()` in `parse.ts`).
 * Once a value has been normalized here, nothing downstream should re-check
 * `Array.isArray` on it.
 *
 * An array input is returned as-is, not defensively copied — a caller that
 * needs isolation from the source should copy it itself.
 */
export function toItems<T>(value: T | T[] | null | undefined): T[] {
  if (value === null || value === undefined) {
    return [];
  }
  return Array.isArray(value) ? value : [value];
}
