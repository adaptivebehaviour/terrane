import type { CreateOptions } from './create';
import { getCollection } from './getCollection';
import { toItems } from './items';

// ── Directive matching ────────────────────────────────────────────────────────
// Both directive forms share the same body shape — `factory:args` — and
// differ only in what they create:
//   • ${factory:args} — creates a record via getCollection().createRecord().
//   • @{factory:args} — creates an instance via getCollection().createInstance()
//                        and resolves to instance.record().
// args may itself contain nested directives or a JSON object literal (both
// introduce their own '{'/'}' pairs), so finding the closing brace means
// tracking depth rather than just searching for the next '}'.

interface DirectiveMatch {
  sigil: '$' | '@';
  factory: string;
  rawArgs: string;
  /** Index immediately after the directive's closing '}'. */
  end: number;
}

/**
 * Attempt to parse a directive starting at `value[start]`. Recognises both
 * `${factory:args}` and `@{factory:args}`.
 *
 * Tracks brace depth from the opening `{` so a nested `${...}`/`@{...}` or a
 * JSON object literal inside `args` doesn't terminate the match early.
 * `rawArgs` is returned unresolved — the caller is responsible for
 * recursively resolving it.
 *
 * @returns The match, or `null` if `start` isn't the start of a well-formed
 *   directive (no `factory:` prefix, or no matching closing brace).
 */
function parseDirectiveAt(value: string, start: number): DirectiveMatch | null {
  const sigil = value[start];
  if ((sigil !== '$' && sigil !== '@') || value[start + 1] !== '{') return null;

  const factoryMatch = /^([a-z]+):/.exec(value.slice(start + 2));
  if (!factoryMatch) return null;
  const factory = factoryMatch[1];
  const argsStart = start + 2 + factoryMatch[0].length;

  // Depth tracks every '{'/'}' pair, not just directive-prefixed ones — args
  // may itself be a JSON object literal with its own braces (e.g.
  // '{"items":["Hi!"]}'), and those must balance the same way nested
  // directives do.
  let depth = 1;
  let i = argsStart;
  while (i < value.length && depth > 0) {
    if (value[i] === '{') {
      depth += 1;
      i += 1;
    } else if (value[i] === '}') {
      depth -= 1;
      i += 1;
    } else {
      i += 1;
    }
  }
  if (depth !== 0) return null;

  return { sigil, factory, rawArgs: value.slice(argsStart, i - 1), end: i };
}

// ── Resolution ─────────────────────────────────────────────────────────────────

/**
 * Resolves a directive's raw `args` substring into the `options` value
 * passed to `createRecord`/`createInstance`:
 *
 * - If `args`, taken as a whole, is itself a well-formed `${...}`/`@{...}`
 *   directive, it's parsed recursively (via {@link parseString}) and the
 *   object it creates becomes this directive's content (`items`) — not a
 *   raw options merge, since the created object always carries its own
 *   `kind`, which would otherwise misfire `createRecord`/`createInstance`'s
 *   inheritance mode.
 * - Otherwise, any directives embedded inside `args` are resolved and
 *   spliced into a string first. If that string is valid JSON and parses to
 *   a plain object, it's used directly as `options` (so directive authors
 *   can write e.g. `${text:{"items":["Hi"]}}`). Any other JSON value (array,
 *   string, number, boolean, null), or a string that isn't valid JSON at
 *   all, becomes this directive's content (`items`) instead — via
 *   {@link toItems}, so a bare `null` (e.g. `${text:null}`) collapses to
 *   `items: []` rather than `items: [null]`.
 */
function resolveArgs(rawArgs: string): CreateOptions {
  const resolved = parseString(rawArgs);
  if (typeof resolved !== 'string') {
    return { items: [resolved] };
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(resolved);
  } catch {
    return { items: [resolved] };
  }
  if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) {
    return parsed as CreateOptions;
  }
  return { items: toItems(parsed) };
}

/** Creates the object a directive describes, per its sigil (see {@link parseString}). */
function createFromDirective(match: DirectiveMatch) {
  const args = resolveArgs(match.rawArgs);
  const collection = getCollection();
  if (match.sigil === '$') {
    return collection.createRecord(match.factory, args);
  }
  return collection.createInstance(match.factory, args).record();
}

// resolveToString recurses into a directive's *written* args before creating
// its object, so nested directives resolve innermost-first. It only ever
// recurses into that original substring — never into a value just created —
// so a created record can never be re-interpreted as a directive.

function resolveToString(value: string): string {
  let result = '';
  let i = 0;
  while (i < value.length) {
    if (value[i] === '$' && value[i + 1] === '$') {
      result += '$';
      i += 2;
      continue;
    }
    if (value[i] === '@' && value[i + 1] === '@') {
      result += '@';
      i += 2;
      continue;
    }
    if ((value[i] === '$' || value[i] === '@') && value[i + 1] === '{') {
      const match = parseDirectiveAt(value, i);
      if (!match) {
        result += value[i];
        i += 1;
        continue;
      }
      result += String(createFromDirective(match));
      i = match.end;
      continue;
    }
    result += value[i];
    i += 1;
  }
  return result;
}

/**
 * Parse a string for `${factory:args}` and `@{factory:args}` directives.
 *
 * Both forms create an object via {@link getCollection}, using `factory`
 * (the text before the first `:`) and `args` (everything up to the matching
 * `}`, resolved per {@link resolveArgs}):
 * - `${factory:args}` creates a record only — via `createRecord` — and the
 *   directive is replaced with that record.
 * - `@{factory:args}` creates an instance — via `createInstance` — calls
 *   `.record()` on it, and the directive is replaced with the resulting
 *   record.
 *
 * - If the *entire* string is exactly one well-formed directive, returns
 *   that directive's raw result (a `RootRecord`).
 * - Otherwise, returns a string: each directive's result is stringified and
 *   spliced back into the surrounding text; plain text with no directives
 *   round-trips unchanged.
 * - A malformed directive (no `factory:` prefix, or no closing brace) is
 *   left as literal text — this function never throws.
 * - `$$` escapes a literal `$` immediately before `{`; `@@` escapes a
 *   literal `@` immediately before `{`.
 * - Directives may nest and mix forms, e.g. `${text:@{test:}}` — the
 *   innermost directive resolves first.
 *
 * @param value - The string to parse.
 *
 * @example
 * ```ts
 * parseString('${text:{"items":["Hi!"]}}'); // a RootRecord with items: ['Hi!']
 * parseString('@{test:}');                   // the `test` instance's record, via .record()
 * ```
 */
export function parseString(value: string): unknown {
  const wholeMatch = parseDirectiveAt(value, 0);
  if (wholeMatch && wholeMatch.end === value.length) {
    return createFromDirective(wholeMatch);
  }
  return resolveToString(value);
}
