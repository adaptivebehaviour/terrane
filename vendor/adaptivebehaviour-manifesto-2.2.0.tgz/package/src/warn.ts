/**
 * The single place a "something unexpected happened, but execution should
 * continue" signal goes out — e.g. {@link ItemFactory}'s `resolveOnlyItem`
 * choosing to ignore extra caller-supplied items rather than reject them.
 *
 * Deliberately just a thin wrapper around `console.warn` for now — nothing
 * about *how* a warning is surfaced (log level, deduping, telemetry, a
 * dev-only no-op in production builds) is decided yet. Every caller goes
 * through this one function so that decision can be made once, later,
 * without touching every call site that currently wants to warn.
 */
export function warn(message: string): void {
  console.warn(message);
}
