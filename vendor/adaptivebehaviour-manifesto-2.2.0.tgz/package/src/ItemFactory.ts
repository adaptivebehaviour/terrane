import { Root, type RootRecord } from './Root';
import type { FactoryCapability, ProduceOptions } from './Factory';
import { resolveItemRecord } from './ContainerFactory';
import { warn } from './warn';

/**
 * Resolves `rawItems` down to at most one record — `rawItems[0]`, if
 * present — warning via {@link warn} when the caller supplied more than
 * one. Returns `undefined` when no items were given at all (nothing to
 * resolve, not an "extra items" situation).
 *
 * A plain exported function, not a method on {@link ItemFactory}, so a
 * factory that can't literally extend `ItemFactory` — e.g. `manifesto/
 * ImageFactory.ts`, whose `produce()` must conditionally return a plain
 * `RootRecord` (no items — preserving `'image'`'s existing synchronous
 * behaviour) or a `Promise<RootRecord>` (items given), which TypeScript's
 * return-type covariance won't allow as an override of `ItemFactory`'s own
 * unconditionally-`async` `produce()` — can still reuse this exact
 * resolution and warning logic via composition instead of inheritance.
 *
 * @param rawItems - The raw, unresolved `items` array.
 * @param factory - The calling factory's own `this.factory`, named in the
 *   warning message.
 * @param cache - Forwarded to {@link resolveItemRecord}.
 */
export async function resolveOnlyItem(
  rawItems: unknown[],
  factory: string,
  cache?: Map<string, RootRecord>
): Promise<RootRecord | undefined> {
  if (rawItems.length > 1) {
    warn(`'${factory}' has ${rawItems.length - 1} item(s) beyond items[0] — only items[0] is used.`);
  }
  if (rawItems.length === 0) return undefined;
  return resolveItemRecord(rawItems[0], cache);
}

/**
 * Factory-capable base class for "always exactly one item" — the sibling
 * of {@link ContainerFactory} ("always every item"): both resolve `items`
 * via the same {@link resolveItemRecord} per-item logic, differing only in
 * how many elements they keep.
 *
 * `items` beyond the first are silently dropped rather than rejected — a
 * caller mistake here doesn't need to be a hard error (unlike, say,
 * `create()` rejecting an unresolved Promise, or `SanityFetchMany` requiring
 * a non-empty `ids`) — but it does go through {@link warn} (via
 * {@link resolveOnlyItem}), a single, swappable seam for "something
 * unexpected happened, but execution should continue" signals, so a caller
 * who passed more than one item by mistake has *some* way to notice.
 *
 * Nests the (at most one) resolved item under `items`, mirroring
 * {@link ContainerFactory}'s own shape but capped to one element — suitable
 * for a factory with no declared defaults of its own to preserve. A factory
 * that needs to fold the resolved item's data into its own `props` instead,
 * or that (like `'image'`) needs to stay synchronous when no items are
 * given, should call {@link resolveOnlyItem} directly rather than extending
 * this class — see `manifesto/factories/ImageFactory.ts`.
 */
export class ItemFactory extends Root implements FactoryCapability {
  async produce(_options: ProduceOptions = {}, cache?: Map<string, RootRecord>): Promise<RootRecord> {
    const base = this.record();
    const resolved = await resolveOnlyItem(base.items, this.factory, cache);
    return { ...base, items: resolved ? [resolved] : [] };
  }
}
