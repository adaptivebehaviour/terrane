import { Root, type RootRecord, type RootConfig } from './Root';
import type { FactoryCapability, ProduceOptions } from './Factory';
import { Factory } from './Factory';
import { resolveFactoryRecord, recordRegistry } from './create';
import { resolveItemRecord } from './ContainerFactory';

/**
 * Factory-capable base class for "every item, mapped into a flattened
 * value" — the third member of this codebase's item-resolution family,
 * alongside {@link ContainerFactory} ("every item, each becomes its own
 * full resolved child record") and {@link ItemFactory} ("at most one item,
 * `warn()` on the rest"). Neither of those two fits a factory that wants
 * *every* item resolved, but doesn't want to keep each one as a full,
 * independently rendered child record — e.g. several lines of fitted text,
 * or a set of selectable options, where each resolved item only
 * contributes a small, caller-defined value (drawn from the resolved
 * item's own `.items`/`.props`) rather than standing on its own as a
 * rendered component.
 *
 * Resolves every element of `items` via {@link resolveItemRecord} (the same
 * per-item resolution `ContainerFactory` uses), then maps each element of
 * each resolved item's own `.items` through the overridable {@link mapItem}
 * hook, replacing the product's raw `items` with the flattened result.
 * `mapItem`'s default — `(text, props) => ({ text: String(text), props })`
 * — suits a factory whose flattened items are themselves lines of text
 * (see `scenes/factories/ProportionalTextFactory.ts`); a subclass with a
 * different per-item shape overrides it.
 *
 * Composes with a fresh {@link Factory} instance (via
 * {@link resolveFactoryRecord}) rather than relying on `this.record()`, for
 * the same two reasons `manifesto/factories/ImageFactory.ts` does:
 * `produce()` stays conditionally sync/async — a plain `RootRecord` when no
 * items are given (preserving the ordinary two-phase merge and a
 * subclass's existing synchronous call sites), a `Promise<RootRecord>`
 * only once there's something to resolve — and `this.record()` alone
 * wouldn't correctly carry this factory's own declared defaults once
 * `options.kind` is given explicitly. See `ImageFactory.ts`'s own doc
 * comment for the full rationale; this class differs only in what happens
 * once items exist to resolve (folded via `mapItem()` into `items`, not
 * merged into `props`).
 *
 * No item-count ceiling or `warn()` here on purpose — unlike `ItemFactory`,
 * where more than one item is a caller mistake worth signalling, *every*
 * item this class receives is legitimate input. A pathological item count
 * is a rendering concern (does the flattened result still fit legibly
 * wherever it's displayed), not a resolution-time one — see
 * `scenes/components/Proportional.tsx`'s `PROPORTIONAL_LEGIBLE_FONT_SIZE_PX`
 * for where that signal actually belongs for `'proportional-text'`.
 */
export class ItemsFactory extends Root implements FactoryCapability {
  protected mapItem(text: unknown, props: Record<string, unknown>): unknown {
    return { text: String(text), props };
  }

  produce(
    options: ProduceOptions = {},
    cache?: Map<string, RootRecord>,
    records: Map<string, RootConfig> = recordRegistry
  ): RootRecord | Promise<RootRecord> {
    const rawItems = (options.items ?? []) as unknown[];
    const factoryRecord = resolveFactoryRecord(this.factory, records, cache);
    const factoryInstance = new Factory(factoryRecord);

    if (rawItems.length === 0) {
      return factoryInstance.produce(options, cache, records);
    }

    return Promise.all(rawItems.map((item) => resolveItemRecord(item, cache))).then((resolvedItems) => ({
      ...factoryInstance.produce({ ...options, items: [] }, cache, records),
      items: resolvedItems.flatMap((resolvedItem) =>
        resolvedItem.items.map((text) => this.mapItem(text, resolvedItem.props))
      ),
    }));
  }
}
