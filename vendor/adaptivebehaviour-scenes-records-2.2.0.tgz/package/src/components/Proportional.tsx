'use client';

import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { toCss } from '@adaptivebehaviour/manifesto/src/manifesto/schemas';
import { proportionalProps } from '../schemas';
import {
  Children,
  Fragment,
  isValidElement,
  createContext,
  useContext,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from 'react';
import { RadioGroup as RadioGroupPrimitive } from 'radix-ui';
import type { RecordComponentProps } from '@adaptivebehaviour/manifesto/src/create';
import { warn } from '@adaptivebehaviour/manifesto/src/warn';
import { useScene } from '@adaptivebehaviour/scenes/src/hooks';

/** Content-box dimensions available to a direct child of ProportionalUi. */
export type ProportionalCell = {
  width: number;
  height: number;
};

/** Inset applied so fitted children stay smaller than the available cell. */
const PROPORTIONAL_FIT_INSET = 4;
const PROPORTIONAL_DEFAULT_CHILD_SIZE = 16;
/** Smallest a CSS font-size can meaningfully be — not a readability floor. */
const PROPORTIONAL_MIN_FONT_SIZE_PX = 1;
/**
 * Below this, fitted text is considered illegible rather than merely small
 * — {@link measureParagraphFontSize} calls {@link warn} (never truncates or
 * rejects `items`) whenever the binary search can't fit `'proportional-text'`'s
 * content at or above this size, so a pathological combination of cell size
 * and item count surfaces as a signal instead of shrinking silently all the
 * way down to {@link PROPORTIONAL_MIN_FONT_SIZE_PX}.
 */
const PROPORTIONAL_LEGIBLE_FONT_SIZE_PX = 10;

function insetProportionalCell(cell: ProportionalCell, inset = PROPORTIONAL_FIT_INSET): ProportionalCell {
  return {
    width: Math.max(0, Math.floor(cell.width) - inset),
    height: Math.max(0, Math.floor(cell.height) - inset),
  };
}

/**
 * One flattened line of `'proportional-text'`/`'proportional-radio-group'`
 * content, after `ItemsFactory`'s `mapItem()` (see
 * `../factories/ProportionalTextFactory.ts`/`../factories/ProportionalRadioGroupFactory.ts`)
 * — `{ text, props }` normalized down to just the per-line `styling` these
 * components actually read.
 */
type ProportionalTextItem = { text: string; styling?: CSSProperties };

/**
 * Normalizes one element of `record.items` into a {@link ProportionalTextItem}.
 * `ItemsFactory`'s `mapItem()` default produces `{ text, props }` objects;
 * a bare, non-object item (e.g. a bare string, matching this factory's
 * behaviour before it supported more than one item) is treated as text with
 * no per-line styling.
 */
function normalizeProportionalTextItem(item: unknown): ProportionalTextItem {
  if (item != null && typeof item === 'object' && 'text' in item) {
    const { text, props } = item as { text: unknown; props?: Record<string, unknown> };
    return { text: String(text), styling: props?.styling as CSSProperties | undefined };
  }
  return { text: String(item) };
}

function paragraphFits(element: HTMLElement, width: number, height: number) {
  return element.scrollWidth <= width && element.scrollHeight <= height;
}

/** Fills `probe` with one `<span>` per item, `<br>`-separated, each carrying its own optional `styling`. */
function populateProbeItems(probe: HTMLElement, items: ProportionalTextItem[]) {
  probe.replaceChildren();
  items.forEach((item, index) => {
    if (index > 0) {
      probe.appendChild(document.createElement('br'));
    }
    const span = document.createElement('span');
    if (item.styling) {
      Object.assign(span.style, item.styling as Record<string, string>);
    }
    span.textContent = item.text;
    probe.appendChild(span);
  });
}

/**
 * Binary-searches the largest font size that fits every one of `items` —
 * `<br>`-separated, individually styled — inside `width`x`height`, as one
 * jointly-measured block (never per item independently; a single item is
 * just the one-element case of this same search). Falls back to
 * {@link PROPORTIONAL_MIN_FONT_SIZE_PX} outside a browser. Calls
 * {@link warn} — but never truncates `items` or refuses to render — once
 * the fitted size drops below {@link PROPORTIONAL_LEGIBLE_FONT_SIZE_PX};
 * see that constant's own doc comment for why this is a render-layer
 * signal, not an item-count cap.
 */
function measureParagraphFontSize(width: number, height: number, items: ProportionalTextItem[]) {
  if (typeof document === 'undefined') {
    return PROPORTIONAL_MIN_FONT_SIZE_PX;
  }

  const probe = document.createElement('p');
  probe.style.cssText = [
    'position:fixed',
    'visibility:hidden',
    'pointer-events:none',
    'margin:0',
    'box-sizing:border-box',
    'border:1px solid transparent',
    `width:${width}px`,
    `height:${height}px`,
    'line-height:normal',
    'overflow:hidden',
    'white-space:pre-line',
  ].join(';');
  populateProbeItems(probe, items);
  document.body.appendChild(probe);

  let low = PROPORTIONAL_MIN_FONT_SIZE_PX;
  let high = Math.max(width, height, PROPORTIONAL_MIN_FONT_SIZE_PX);
  let best = PROPORTIONAL_MIN_FONT_SIZE_PX;

  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    probe.style.fontSize = `${mid}px`;
    if (paragraphFits(probe, width, height)) {
      best = mid;
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }

  while (best > PROPORTIONAL_MIN_FONT_SIZE_PX) {
    probe.style.fontSize = `${best}px`;
    if (paragraphFits(probe, width, height)) {
      break;
    }
    best -= 1;
  }

  document.body.removeChild(probe);

  if (best < PROPORTIONAL_LEGIBLE_FONT_SIZE_PX) {
    warn(
      `'proportional-text' fitted ${items.length} item(s) down to ${best}px, below the ` +
        `${PROPORTIONAL_LEGIBLE_FONT_SIZE_PX}px legibility floor.`
    );
  }

  return best;
}

const ProportionalCellContext = createContext<ProportionalCell | null>(null);

const ProportionalContentLayoutContext = createContext<ProportionalCell | null>(null);

/**
 * Set by `ProportionalChild` whenever the record it's wrapping declares its
 * own explicit `props.proportionalWidth`/`props.proportionalHeight` (see
 * `getChildRecord()`/`hasExplicitSize` below), so a nested `ProportionalComponent`
 * can tell the difference between "I fill whatever cell my parent gave me"
 * (the default) and "my parent already sized me explicitly, so my own
 * `props.proportionalWidth`/`props.proportionalHeight` percentages would
 * double-apply against the wrong box."
 */
const ProportionalExplicitSizeContext = createContext(false);

/** Reads the content-box cell assigned to the nearest ProportionalChild ancestor. */
export function useProportionalCell(): ProportionalCell {
  return useContext(ProportionalCellContext) ?? { width: 0, height: 0 };
}

function useProportionalContentLayout() {
  return useContext(ProportionalContentLayoutContext) ?? { width: 0, height: 0 };
}

/**
 * Combines {@link useProportionalCell} and {@link useProportionalContentLayout}
 * into the one inset cell a leaf Proportional component (`ProportionalText`,
 * `ProportionalImage`, `ProportionalRadioGroup`) actually fits itself to —
 * shared here rather than duplicated in each, since all three resolve their
 * fit source the same way (see `getProportionalFitSource` below).
 */
export function useProportionalFitCell(): ProportionalCell {
  const cell = useProportionalCell();
  const contentLayout = useProportionalContentLayout();
  return useMemo(
    () => insetProportionalCell(getProportionalFitSource(cell, contentLayout)),
    [cell.height, cell.width, contentLayout.height, contentLayout.width],
  );
}

function useFitFontSize(
  width: number,
  height: number,
  items: ProportionalTextItem[],
) {
  const [fontSize, setFontSize] = useState(PROPORTIONAL_MIN_FONT_SIZE_PX);

  useLayoutEffect(() => {
    if (!width || !height) {
      return;
    }

    const fitWidth = Math.max(1, Math.floor(width));
    const fitHeight = Math.max(1, Math.floor(height));
    const best = measureParagraphFontSize(fitWidth, fitHeight, items);
    setFontSize((previous) => (previous === best ? previous : best));
  }, [width, height, items]);

  return fontSize;
}

function observeElementSize(
  element: HTMLElement,
  setSize: Dispatch<SetStateAction<{ width: number; height: number }>>,
) {
  const update = () => {
    const width = element.clientWidth;
    const height = element.clientHeight;
    setSize((previous) => {
      if (previous.width === width && previous.height === height) {
        return previous;
      }
      return { width, height };
    });
  };

  update();
  const observer = new ResizeObserver(update);
  observer.observe(element);
  return () => observer.disconnect();
}

function getProportionalFitSource(
  cell: ProportionalCell,
  contentLayout: ProportionalCell,
) {
  if (cell.width > 0 && cell.height > 0) {
    return cell;
  }

  const insideProportionalComponent = contentLayout.width > 0 || contentLayout.height > 0;
  if (insideProportionalComponent) {
    return { width: 0, height: 0 };
  }

  return contentLayout;
}

function toPercentageDimension(value: number | undefined) {
  if (value == null || !Number.isInteger(value)) {
    return undefined;
  }

  return `${value}%`;
}

function parseAspectRatio(width: number | undefined, height: number | undefined) {
  if (width == null || height == null) return undefined;

  if (!Number.isInteger(width) || !Number.isInteger(height) || height === 0) {
    return undefined;
  }

  return width / height;
}

function fitAspectRatio(
  availableWidth: number,
  availableHeight: number,
  aspectRatio: number | undefined,
) {
  if (!availableWidth || !availableHeight) {
    return { width: availableWidth, height: availableHeight };
  }

  if (aspectRatio == null) {
    return { width: availableWidth, height: availableHeight };
  }

  if (availableWidth / availableHeight > aspectRatio) {
    return { width: availableHeight * aspectRatio, height: availableHeight };
  }

  return { width: availableWidth, height: availableWidth / aspectRatio };
}

/**
 * Sees through a `<>...</>` Fragment wrapper (e.g. a child conditionally
 * rendered alongside a sibling) to the `<ProportionalXyz record={...} />`
 * element underneath, so `getChildRecord()`/`isNestedProportionalComponent`
 * below still recognize it — a bare Fragment itself never carries a
 * `record` prop.
 */
function unwrapFragment(node: ReactNode): ReactNode {
  if (isValidElement(node) && node.type === Fragment) {
    return unwrapFragment((node.props as { children?: ReactNode }).children);
  }
  return node;
}

// A child passed to ProportionalComponent is always a `<ProportionalXyz
// record={...} />` element (see RecordComponentProps), so its aspect ratio
// and size weight live on that nested record's own `props` — never on the
// child element's own JSX props directly.
function getChildRecord(child: ReactNode): RecordComponentProps['record'] | undefined {
  const resolved = unwrapFragment(child);
  if (!isValidElement(resolved)) return undefined;

  return (resolved.props as Partial<RecordComponentProps> | undefined)?.record;
}

function getChildAspectRatio(child: ReactNode) {
  const record = getChildRecord(child);
  const props = record ? propsOf(proportionalProps, record) : undefined;
  return parseAspectRatio(props?.proportionalWidth, props?.proportionalHeight);
}

function getChildSize(child: ReactNode) {
  const size = getChildRecord(child)?.props.size;

  if (typeof size === 'number' && Number.isInteger(size) && size > 0) {
    return size;
  }

  return PROPORTIONAL_DEFAULT_CHILD_SIZE;
}

function getProportionalDirection(props: Record<string, unknown>) {
  return props.direction === 'row' ? 'row' : 'column';
}

/**
 * Backs factory `'proportional-component'` — a flex container that lays out
 * its children (row or column, per `record.props.direction`) and hands each
 * one, via `ProportionalChild`, a content-box cell sized to its declared
 * `size` weight. Registered indirectly (see `../index.ts`): like `Stage`/
 * `Scene`, this is a hook-based Client Component, so the registered
 * `RecordComponent` must build a `<ProportionalComponent record={record} />`
 * element rather than calling this function directly.
 *
 * Skips its own `record.props.proportionalWidth`/`props.proportionalHeight`
 * percentage sizing whenever `ProportionalExplicitSizeContext` says the
 * nearest `ProportionalChild` ancestor already gave it an explicit box (see
 * that context's own doc comment) — otherwise a nested `ProportionalComponent`
 * would apply its declared size twice: once as the parent's explicit
 * width/height, and again as its own percentage of that already-sized box.
 */
export function ProportionalComponent({ record, children }: RecordComponentProps & { children?: ReactNode }) {
  const contentRef = useRef<HTMLDivElement>(null);
  const [contentLayout, setContentLayout] = useState<ProportionalCell>({ width: 0, height: 0 });
  const contentLayoutContext = useMemo(
    () => contentLayout,
    [contentLayout],
  );
  const isExplicitlySizedByParent = useContext(ProportionalExplicitSizeContext);
  const width = isExplicitlySizedByParent
    ? undefined
    : toPercentageDimension(propsOf(proportionalProps, record).proportionalWidth);
  const height = isExplicitlySizedByParent
    ? undefined
    : toPercentageDimension(propsOf(proportionalProps, record).proportionalHeight);
  const hasExplicitHeight = height != null;
  const fillsParentSlot = width == null && height == null;
  const direction = getProportionalDirection(record.props);
  const isRowCard = direction === 'row';

  useLayoutEffect(() => {
    const element = contentRef.current;
    if (!element) return;

    return observeElementSize(element, setContentLayout);
  }, []);

  return (
    <div
      style={{
        boxSizing: 'border-box',
        ...(fillsParentSlot
          ? {
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: direction,
          }
          : {
            width,
            height,
            ...(hasExplicitHeight
              ? {}
              : {
                display: 'flex',
                flexDirection: direction,
                flex: 1,
              }),
          }),
        padding: isRowCard ? '1.5rem 2rem' : '1rem',
        fontSize: '1rem',
        borderRadius: isRowCard ? 8 : undefined,
        background: isRowCard ? '#f5f5f5' : undefined,
        minWidth: 0,
        minHeight: 0,
        overflow: 'hidden',
      }}
    >
      <ProportionalContentLayoutContext.Provider value={contentLayoutContext}>
        <div
          ref={contentRef}
          style={{
            boxSizing: 'border-box',
            width: '100%',
            height: fillsParentSlot ? undefined : '100%',
            display: 'flex',
            flexDirection: direction,
            gap: isRowCard ? '1.5rem' : undefined,
            minWidth: 0,
            minHeight: 0,
            ...(fillsParentSlot || !hasExplicitHeight ? { flex: 1 } : {}),
          }}
        >
          {Children.toArray(children).map((child, childIndex) => (
            <ProportionalChild
              key={childIndex}
              child={child}
              direction={direction}
              sizeWeight={getChildSize(child)}
            />
          ))}
        </div>
      </ProportionalContentLayoutContext.Provider>
    </div>
  );
}

/**
 * Wraps one `ProportionalComponent` child, assigning it either a flex-weighted
 * share of the available space (the default — `sizeWeight`, from the child
 * record's own `props.size`) or, when the child record declares its own
 * explicit `props.proportionalWidth`/`props.proportionalHeight`, a fixed box
 * sized directly from those percentages instead — signalling the latter down
 * to a nested `ProportionalComponent` via `ProportionalExplicitSizeContext` so it doesn't
 * re-apply its own percentage sizing on top (see that context's doc comment).
 *
 * The flex-weighted share and the fixed percentage box aren't mutually
 * exclusive per axis — only the parent's own main axis (`direction`: the
 * axis `sizeWeight` actually distributes) is ever taken over by an explicit
 * percentage. A `proportionalWidth`/`proportionalHeight` given only for the
 * *cross* axis (e.g. `proportionalWidth` alone in a `direction: 'column'`
 * parent) still fixes that axis directly, but leaves the main axis on the
 * normal `sizeWeight` flex-share — it does not also opt the child out of
 * flex-grow on an axis nothing was said about, which would otherwise leave
 * that axis at its `auto`/`0` default and collapse the child to nothing.
 */
function ProportionalChild({
  child,
  direction,
  layout = 'fill',
  sizeWeight = PROPORTIONAL_DEFAULT_CHILD_SIZE,
}: {
  child: ReactNode;
  direction: 'row' | 'column';
  layout?: 'fill' | 'hug';
  sizeWeight?: number;
}) {
  const outerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const isFill = layout === 'fill';
  const resolvedChild = unwrapFragment(child);
  const isNestedProportionalComponent = isValidElement(resolvedChild) && resolvedChild.type === ProportionalComponent;

  useLayoutEffect(() => {
    const element = outerRef.current;
    if (!element) return;

    return observeElementSize(element, setSize);
  }, []);

  const childRecord = getChildRecord(child);
  const explicitWidth = toPercentageDimension(childRecord ? propsOf(proportionalProps, childRecord).proportionalWidth : undefined);
  const explicitHeight = toPercentageDimension(childRecord ? propsOf(proportionalProps, childRecord).proportionalHeight : undefined);
  const hasExplicitSize = explicitWidth != null || explicitHeight != null;
  const hasExplicitMainAxisSize = direction === 'row' ? explicitWidth != null : explicitHeight != null;

  const aspectRatio = hasExplicitSize ? undefined : getChildAspectRatio(child);
  const { width, height } = fitAspectRatio(size.width, size.height, aspectRatio);
  const contentWidth = aspectRatio != null ? width : size.width;
  const contentHeight = aspectRatio != null ? height : size.height;
  const cell = useMemo(
    () => insetProportionalCell({
      width: contentWidth,
      height: isFill ? contentHeight : 0,
    }),
    [contentWidth, contentHeight, isFill],
  );

  const inner = (
    <div
      style={{
        boxSizing: 'border-box',
        width: aspectRatio != null ? width : '100%',
        height: isFill ? '100%' : 'auto',
        maxWidth: '100%',
        maxHeight: isFill ? '100%' : undefined,
        overflow: 'hidden',
        ...(isFill && isNestedProportionalComponent
          ? {
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
          }
          : {}),
      }}
    >
      <ProportionalExplicitSizeContext.Provider value={hasExplicitSize}>
        {child}
      </ProportionalExplicitSizeContext.Provider>
    </div>
  );

  return (
    <ProportionalCellContext.Provider value={cell}>
      <div
        ref={outerRef}
        style={{
          flex: hasExplicitMainAxisSize ? '0 0 auto' : (isFill ? `${sizeWeight} 1 0` : '0 0 auto'),
          minWidth: 0,
          minHeight: isFill ? 0 : undefined,
          width: explicitWidth ?? '100%',
          height: explicitHeight,
          overflow: 'hidden',
          position: isFill ? 'relative' : undefined,
          display: isFill ? undefined : 'flex',
          alignItems: isFill ? undefined : 'flex-start',
          justifyContent: isFill ? undefined : 'center',
        }}
      >
        {isFill ? (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              overflow: 'hidden',
              display: 'flex',
              alignItems: 'flex-start',
              justifyContent: 'center',
            }}
          >
            {inner}
          </div>
        ) : inner}
      </div>
    </ProportionalCellContext.Provider>
  );
}

/**
 * Backs factory `'proportional-text'` — fits every one of its record's own
 * items (`record.items`, each `{ text, props }` after `ItemsFactory`'s
 * `mapItem()` flattening — content belongs in `items`, never `props`; see
 * `../factories/ProportionalTextFactory.ts`) to the cell assigned by the
 * nearest `ProportionalChild`/content-layout ancestor (via
 * {@link useProportionalFitCell}), binary-searching **one** font size that
 * fits every item jointly, `<br>`-separated. Each item may carry its own
 * `props.styling`, applied per-line; `record.props.styling` is applied on
 * top of the whole block (never in place of the fitted defaults) — the same
 * escape hatch `ContainerComponent`/`ItemComponent`/`Scene` use. Registered
 * indirectly (see `../index.ts`) for the same reason as `ProportionalComponent`
 * above.
 *
 * A record with a single item behaves exactly as this factory always has —
 * the multi-item case is a generalization, not a separate code path.
 */
export function ProportionalText({ record }: RecordComponentProps) {
  const fitCell = useProportionalFitCell();
  const items = useMemo(() => record.items.map(normalizeProportionalTextItem), [record.items]);
  const fontSize = useFitFontSize(fitCell.width, fitCell.height, items);

  return (
    <p
      style={{
        boxSizing: 'border-box',
        width: fitCell.width > 0 ? fitCell.width : '100%',
        height: '100%',
        maxWidth: '100%',
        maxHeight: '100%',
        margin: 0,
        lineHeight: 'normal',
        fontSize: `${fontSize}px`,
        whiteSpace: 'pre-line',
        ...toCss(propsOf(proportionalProps, record).styling),
      }}
    >
      {items.map((item, index) => (
        <Fragment key={index}>
          {index > 0 ? <br /> : null}
          <span style={item.styling}>{item.text}</span>
        </Fragment>
      ))}
    </p>
  );
}

/**
 * Backs factory `'proportional-image'` — fits its record's own
 * `props.url`/`props.alt` image to the cell assigned by the nearest
 * `ProportionalChild`/content-layout ancestor (via {@link useProportionalFitCell}).
 * Registered indirectly (see `../index.ts`) for the same reason as
 * `ProportionalComponent` above.
 *
 * Renders a plain `<img>` rather than `next/image` — this collection lives
 * in the shared library, which every consuming app (the framework-agnostic
 * `vite` prototype included, not just `nextjs`) pulls in directly, so it can
 * never depend on a Next.js-specific API. Matches `manifesto`'s own
 * `components/Image.tsx`, which renders the same way for the same reason.
 */
export function ProportionalImage({ record }: RecordComponentProps) {
  const fitCell = useProportionalFitCell();

  const src = propsOf(proportionalProps, record).url;
  if (!src) {
    return null;
  }

  const alt = propsOf(proportionalProps, record).alt ?? '';

  return (
    <div
      style={{
        boxSizing: 'border-box',
        position: 'relative',
        width: fitCell.width > 0 ? fitCell.width : '100%',
        height: '100%',
        maxWidth: '100%',
        maxHeight: '100%',
        margin: 0,
        overflow: 'hidden',
      }}
    >
      <img
        src={src}
        alt={alt}
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          objectFit: 'contain',
        }}
      />
    </div>
  );
}

const RADIO_GROUP_ROW_GAP_PX = 8;
const RADIO_GROUP_ROW_PADDING_X_PX = 8;
const RADIO_GROUP_ROW_PADDING_Y_PX = 4;

/**
 * Backs factory `'proportional-radio-group'` — renders every one of its
 * record's own items (`record.items`, flattened by `ItemsFactory`'s
 * `mapItem()` exactly like `'proportional-text'`; see
 * `../factories/ProportionalRadioGroupFactory.ts`) as one option in a Radix
 * `RadioGroup`, fitted to the cell assigned by the nearest
 * `ProportionalChild`/content-layout ancestor (via {@link useProportionalFitCell}),
 * with the same joint font-size binary search `ProportionalText` uses so
 * every label shares one legible size. Registered indirectly (see
 * `../index.ts`) for the same reason as `ProportionalComponent` above.
 *
 * Selection state is a named `useScene` slot keyed on the record's own `id`
 * (`{ selectedIndex }`) — the same declarative state mechanism `Scene` uses
 * for its own visibility — so another component in the same `SceneProvider`
 * scope can read or drive the current selection by name (see `../hooks`).
 */
export function ProportionalRadioGroup({ record }: RecordComponentProps) {
  const fitCell = useProportionalFitCell();
  const items = useMemo(() => record.items.map(normalizeProportionalTextItem), [record.items]);
  const [selection, setSelection] = useScene(record.id, { selectedIndex: undefined as number | undefined });
  const selected = selection.selectedIndex != null ? `option-${selection.selectedIndex + 1}` : undefined;
  const labelWidth = Math.max(0, fitCell.width - RADIO_GROUP_ROW_PADDING_X_PX * 2);
  const labelHeight = Math.max(
    0,
    fitCell.height
      - RADIO_GROUP_ROW_GAP_PX * Math.max(0, items.length - 1)
      - RADIO_GROUP_ROW_PADDING_Y_PX * 2 * items.length
  );
  const fontSize = useFitFontSize(labelWidth, labelHeight, items);

  return (
    <RadioGroupPrimitive.Root
      data-id={record.id}
      value={selected ?? ''}
      onValueChange={(value) => setSelection({ selectedIndex: Number(value.slice('option-'.length)) - 1 })}
      style={{
        boxSizing: 'border-box',
        width: fitCell.width > 0 ? fitCell.width : '100%',
        height: '100%',
        maxWidth: '100%',
        maxHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        gap: `${RADIO_GROUP_ROW_GAP_PX}px`,
        fontSize: `${fontSize}px`,
        ...toCss(propsOf(proportionalProps, record).styling),
      }}
    >
      {items.map((item, index) => {
        const value = `option-${index + 1}`;
        const id = `${record.id}-${index + 1}`;
        return (
          <label
            key={value}
            htmlFor={id}
            style={{
              boxSizing: 'border-box',
              display: 'block',
              margin: 0,
              padding: `${RADIO_GROUP_ROW_PADDING_Y_PX}px ${RADIO_GROUP_ROW_PADDING_X_PX}px`,
              borderRadius: 'var(--radius-compact)',
              backgroundColor: selected === value ? 'var(--color-surface-active)' : 'transparent',
              cursor: 'pointer',
              ...item.styling,
            }}
          >
            <RadioGroupPrimitive.Item
              value={value}
              id={id}
              style={{ position: 'absolute', opacity: 0, pointerEvents: 'none' }}
            />
            {item.text}
          </label>
        );
      })}
    </RadioGroupPrimitive.Root>
  );
}
