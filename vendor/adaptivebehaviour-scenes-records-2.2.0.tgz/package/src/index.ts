import { defineCollection } from '@adaptivebehaviour/manifesto/src/registry';
import { defineFactory, validateRecordsJson } from '@adaptivebehaviour/manifesto/src/schema';
import { proportionalProps, sceneProps, sceneProviderProps, stageProps } from './schemas';
import { fromRecordProps, type RegistryTarget, type RecordComponent, type RecordInstance } from '@adaptivebehaviour/manifesto/src/create';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { Stage } from './components/Stage';
import { Scene } from './components/Scene';
import { ProportionalComponent, ProportionalText, ProportionalImage, ProportionalRadioGroup, useProportionalFitCell } from './components/Proportional';
import { StageFactory } from './factories/StageFactory';
import { SceneFactory } from './factories/SceneFactory';
import { SceneProviderFactory } from './factories/SceneProviderFactory';
import { ProportionalComponentFactory } from './factories/ProportionalComponentFactory';
import { ProportionalImageFactory } from './factories/ProportionalImageFactory';
import { ProportionalTextFactory } from './factories/ProportionalTextFactory';
import { ProportionalRadioGroupFactory } from './factories/ProportionalRadioGroupFactory';
import records from './records.json' with { type: 'json' };

export {
  SceneProvider,
  useScene,
  useSceneState,
  useSceneEvent,
  useEmit,
  useAnchorRect,
  TUTORIAL_INTERACT_EVENT,
} from '@adaptivebehaviour/scenes/src/hooks';
export type { SceneExpose, AnchorRect } from '@adaptivebehaviour/scenes/src/hooks';

export { Stage, useIsPortrait } from './components/Stage';
export { Scene, SCENE_ACTIVATE_EVENT } from './components/Scene';
export { OrientationGate } from '@adaptivebehaviour/scenes/src/orientation';
export { ProportionalComponent, ProportionalText, ProportionalImage, ProportionalRadioGroup, useProportionalFitCell } from './components/Proportional';
export { StageFactory } from './factories/StageFactory';
export { SceneFactory } from './factories/SceneFactory';
export { SceneProviderFactory } from './factories/SceneProviderFactory';
export { ProportionalComponentFactory } from './factories/ProportionalComponentFactory';
export { ProportionalImageFactory } from './factories/ProportionalImageFactory';
export { ProportionalTextFactory } from './factories/ProportionalTextFactory';
export { ProportionalRadioGroupFactory } from './factories/ProportionalRadioGroupFactory';

interface SceneRegistryEntry {
  key: string;
  instance: RecordInstance;
  component: RecordComponent;
}

// Each entry's `component` is a real React component (a `RecordComponent`:
// `buildComponent()` renders it with `createElement()`), so the hook-based
// Client Components here — Stage, Scene and the Proportional family — run in
// their own render, never at dispatch time.
//
// Stage and Scene take the record's own fields as props (so they work as
// `<Stage {...record}>` too) and are adapted with `fromRecordProps()`.
// `ProportionalText`/`ProportionalImage`/`ProportionalRadioGroup` already take
// `{ record }` and are registered directly. `scene-provider` and
// `proportional-component` have items to resolve into pre-rendered `children`
// (`SceneProvider` and `ProportionalComponent` do not read `record.items`
// themselves), so their components go through the matching factory's
// `renderComponent()` — see `SceneProviderFactory`'s and
// `ProportionalComponentFactory`'s own doc comments.
//
// Adding a new proportional/scene type only requires one more entry here.
const SceneProviderComponent: RecordComponent = ({ record }) =>
  new SceneProviderFactory(record).renderComponent(record.items as RootRecord[]);
const ProportionalComponentRecord: RecordComponent = ({ record }) =>
  new ProportionalComponentFactory(record).renderComponent(record.items as RootRecord[]);

const entries: SceneRegistryEntry[] = [
  {
    key: 'stage',
    instance: (record) => new StageFactory(record),
    component: fromRecordProps(Stage, 'Stage'),
  },
  {
    key: 'scene',
    instance: (record) => new SceneFactory(record),
    component: fromRecordProps(Scene, 'Scene'),
  },
  {
    key: 'scene-provider',
    instance: (record) => new SceneProviderFactory(record),
    component: SceneProviderComponent,
  },
  {
    key: 'proportional-component',
    instance: (record) => new ProportionalComponentFactory(record),
    component: ProportionalComponentRecord,
  },
  {
    key: 'proportional-text',
    instance: (record) => new ProportionalTextFactory(record),
    component: ProportionalText,
  },
  {
    key: 'proportional-image',
    instance: (record) => new ProportionalImageFactory(record),
    component: ProportionalImage,
  },
  {
    key: 'proportional-radio-group',
    instance: (record) => new ProportionalRadioGroupFactory(record),
    component: ProportionalRadioGroup,
  },
];

/**
 * Registers this collection's records and factories into the
 * {@link RegistryTarget} it's handed — `records.json` entries (`recordRegistry`
 * — e.g. `stage`'s default `shortMin`/`longMin` props) plus every `entries`
 * row above (`componentRegistry`/`instanceRegistry` — {@link StageFactory},
 * {@link SceneFactory}, {@link SceneProviderFactory}, {@link ProportionalComponentFactory},
 * {@link ProportionalImageFactory}, {@link ProportionalTextFactory}, and
 * {@link ProportionalRadioGroupFactory}, all Factory-capable; see each one's
 * own doc comment for why it has a custom entry rather than going through
 * the generic {@link Factory} default). This collection also exports a
 * standalone React context/hooks system (`SceneProvider`, `useScene`,
 * `useSceneState`, `useSceneEvent`, `useEmit` — see `./hooks`) that sits
 * alongside the record/factory pattern rather than going through it —
 * `Scene` (factory `'scene'`) seeds a named `useScene` slot from its own
 * record's `id`/`props`; `SceneProviderFactory` (factory `'scene-provider'`)
 * is the other place the two meet, letting a whole `SceneProvider` scope
 * tree — nesting, `expose` wiring, and all — be described declaratively as
 * one record graph instead of hand-composed JSX (see its own doc comment).
 *
 * Writes into `target` rather than `create.ts`'s module-level registries
 * directly — `getCollection.ts` calls this against a fresh, empty target to
 * capture exactly what this collection declares (for `getCollection('scenes')`'s
 * own-scope resolution) before merging it into the shared global registries
 * — see `getCollection.ts`'s own module comment for the full mechanism.
 */
export function register(target: RegistryTarget): void {
  // Each entry is defined as a factory with its props schema; registering records the schema, which is
  // checked against the factory's records as they are built and against records.json below.
  const propsByKey = {
    stage: stageProps,
    scene: sceneProps,
    'scene-provider': sceneProviderProps,
  } as const;
  for (const { key, instance, component } of entries) {
    const props = propsByKey[key as keyof typeof propsByKey] ?? proportionalProps;
    defineFactory({ type: key, props, component, instance }).register(target);
  }
  for (const record of validateRecordsJson('scenes/records.json', records)) {
    target.recordRegistry.set(record.id as string, record);
  }
}

/** This collection's declaration, for composing into a registry (see registry.ts's createRegistry()). */
export const scenes = defineCollection({ id: 'scenes', dependsOn: ['manifesto'], register });
