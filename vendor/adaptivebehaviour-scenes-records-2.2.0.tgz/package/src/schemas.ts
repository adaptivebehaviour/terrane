import { z } from 'zod';
import { cssProperties } from '@adaptivebehaviour/manifesto/src/manifesto/schemas';

// Props schemas for the scenes collection's factories (see the base collection's schemas.ts).

export const stageProps = z.looseObject({
  shortMin: z.number().optional(),
  longMin: z.number().optional(),
  styling: cssProperties.optional(),
}).meta({ id: 'StageProps' });

export const sceneProps = z.looseObject({
  fadeInMs: z.number().optional(),
  initiallyVisible: z.boolean().optional(),
  backgroundImage: z.looseObject({ url: z.string().optional() }).optional(),
  styling: cssProperties.optional(),
}).meta({ id: 'SceneProps' });

export const sceneProviderProps = z.looseObject({}).meta({ id: 'SceneProviderProps' });

/** The `proportional-*` family: a child's explicit box, a text/image/radio group's own props. */
export const proportionalProps = z.looseObject({
  proportionalWidth: z.number().optional(),
  proportionalHeight: z.number().optional(),
  direction: z.string().optional(),
  url: z.string().optional(),
  alt: z.string().optional(),
  styling: cssProperties.optional(),
}).meta({ id: 'ProportionalProps' });
