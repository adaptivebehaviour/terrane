import { createElement, type ReactElement } from 'react';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { ContainerComponentFactory } from '@adaptivebehaviour/manifesto/src/manifesto/factories/ContainerComponentFactory';
import { Stage } from '../components/Stage';

/**
 * Factory `'stage'` — resolves each element of a passed `items` array into
 * its own component (e.g. a nested `'scene'`), wrapped in the base `stage`
 * factory's own responsive viewport frame (see `components/Stage.tsx`).
 * Registered in `instanceRegistry` (see `index.ts`), replacing the generic
 * {@link Factory} default `'stage'` previously used.
 *
 * `Stage`'s purpose is to provide a single-page application container — the
 * one fixed-size viewport frame an app's scenes render inside (see
 * `components/Stage.tsx`'s own doc comment).
 *
 * Extends {@link ContainerComponentFactory} (manifesto's own `'component'`
 * factory) rather than {@link ContainerFactory} directly, to reuse both its
 * generic `renderItemComponents()` and its `renderComponent()` shape —
 * `'stage'` has no record-assembly needs beyond resolving every `items`
 * element, so the inherited `produce()` (itself inherited unchanged from
 * `ContainerFactory`) covers everything this factory needs; its own
 * declared defaults (`shortMin`/`longMin`, from `records.json`) are already
 * folded into `this.record()` by the time `produce()` runs. See
 * `ContainerFactory.ts`'s own doc comment for the full behavior: why it's
 * unconditionally `async` (`createAsync('stage', ...)`, never a plain
 * `create()`), how the two-phase `kind`-ancestor/own-defaults merge is
 * preserved, and how each `items` element is resolved (including the
 * `[arg, options]` tuple form).
 *
 * `renderComponent()` is overridden only to point at `Stage` instead of
 * `ContainerComponent` — the body is otherwise identical to
 * `ContainerComponentFactory.renderComponent()`'s, now that `Stage` has the
 * same `RecordComponent` shape as `ContainerComponent` (reads `record.items`
 * itself, rather than taking `children` as a separate prop). See that
 * method's own doc comment for the full "why this can't double-render or
 * loop" reasoning, which applies here unchanged: this stays lazy —
 * `renderItemComponents()` only actually runs once, inside `Stage`'s own
 * body, whenever the returned element is actually rendered.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('stage', {
 *   items: ['scene:anchor'],
 * });
 * // <div data-factory="stage">...<div data-factory="scene">...</div></div>
 * ```
 */
export class StageFactory extends ContainerComponentFactory {
  renderComponent(items: RootRecord[]): ReactElement {
    return createElement(Stage, { ...this.record(), items });
  }
}
