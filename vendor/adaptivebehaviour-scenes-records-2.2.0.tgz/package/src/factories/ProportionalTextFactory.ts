import { ItemsFactory } from '@adaptivebehaviour/manifesto/src/ItemsFactory';

/**
 * Factory `'proportional-text'` — resolves every element of `items` (e.g.
 * nested `'sanity-fetch:...'` fetches) into its own fitted line of content,
 * on top of the ordinary two-phase resolution (this factory's own declared
 * `records.json` defaults merged with a real `kind` ancestor's props)
 * {@link ItemsFactory} already provides. Registered in `instanceRegistry`
 * (see `../index.ts`), replacing the generic {@link Factory} default.
 *
 * No override needed — {@link ItemsFactory}'s default `mapItem()` (each
 * resolved item's own `.items` flattened into `{ text, props }`) is exactly
 * what `components/Proportional.tsx`'s `ProportionalText` expects, one
 * `<span>` per array element, `<br>`-separated. A single item behaves
 * exactly as `'proportional-text'` always has — the multi-item case is a
 * generalization of the single-item one, not a separate code path.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * collection.create('proportional-text', { items: ['Hello'] }); // unchanged, still synchronous
 * await collection.createAsync('proportional-text', {
 *   items: ['sanity-fetch:apple-whole', 'Line two'],
 * }); // resolves every item into its own fitted line
 * ```
 */
export class ProportionalTextFactory extends ItemsFactory {}
