import { ItemsFactory } from '@adaptivebehaviour/manifesto/src/ItemsFactory';

/**
 * Factory `'proportional-radio-group'` — resolves every element of `items`
 * (e.g. nested `'sanity-fetch:...'` fetches) into its own radio option, on
 * top of the ordinary two-phase resolution (this factory's own declared
 * `records.json` defaults merged with a real `kind` ancestor's props)
 * {@link ItemsFactory} already provides. Registered in `instanceRegistry`
 * (see `../index.ts`), replacing the generic {@link Factory} default.
 *
 * No override needed — same reasoning as `ProportionalTextFactory`:
 * {@link ItemsFactory}'s default `mapItem()` (each resolved item's own
 * `.items` flattened into `{ text, props }`) is exactly what
 * `components/Proportional.tsx`'s `ProportionalRadioGroup` expects, one
 * option per array element.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * collection.create('proportional-radio-group', { items: ['Yes', 'No'] });
 * ```
 */
export class ProportionalRadioGroupFactory extends ItemsFactory {}
