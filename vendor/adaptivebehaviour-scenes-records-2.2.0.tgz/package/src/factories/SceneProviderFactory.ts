import { createElement, type ReactElement } from 'react';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { ContainerComponentFactory } from '@adaptivebehaviour/manifesto/src/manifesto/factories/ContainerComponentFactory';
import { SceneProvider, type SceneExpose } from '@adaptivebehaviour/scenes/src/hooks';

function readExpose(props: Record<string, unknown>): SceneExpose | undefined {
  const value = props.expose;
  if (Array.isArray(value)) {
    return value.every((entry) => typeof entry === 'string') ? (value as string[]) : undefined;
  }
  if (value !== null && typeof value === 'object') {
    const entries = Object.entries(value as Record<string, unknown>);
    return entries.every(([, exposedName]) => typeof exposedName === 'string')
      ? (Object.fromEntries(entries) as Record<string, string>)
      : undefined;
  }
  return undefined;
}

function readExposeEvents(props: Record<string, unknown>): string[] | undefined {
  const value = props.exposeEvents;
  return Array.isArray(value) && value.every((entry) => typeof entry === 'string')
    ? (value as string[])
    : undefined;
}

/**
 * Factory `'scene-provider'` — resolves each element of a passed `items`
 * array into its own component, exactly like `SceneFactory`/`StageFactory`,
 * then nests the resolved components inside a `SceneProvider` rather than a
 * `<div>`. The record's own `id` becomes `SceneProvider`'s `scope`;
 * `props.expose`/`props.exposeEvents` become its `expose`/`exposeEvents` —
 * see `../hooks`' own doc comment for what those control.
 *
 * Extends {@link ContainerComponentFactory}, like `SceneFactory`/`StageFactory`,
 * to reuse its `renderItemComponents()` — but unlike those two,
 * `renderComponent()` below calls `renderItemComponents()` itself, eagerly,
 * rather than deferring it into the wrapped component's own render body.
 * `SceneProvider` (`../hooks`) is plain React infrastructure with a
 * `{ children, scope, expose, exposeEvents }` signature, not a `RecordComponent`
 * reading `record.items` the way `Scene`/`Stage` do — there is no
 * record-aware body to defer into. This is still safe: `renderItemComponents()`
 * only builds `ReactElement` descriptors via `createElement()`/`buildComponent()`,
 * never executes a hook-based component's body directly (see
 * `create.ts`'s `buildComponent()` — it dispatches to a registered
 * `RecordComponent`, which itself only calls `createElement()`), so calling
 * it here, before `SceneProvider` itself has rendered, can't run hooks
 * outside React's own render the way calling `Scene(record)`/`Stage(record)`
 * directly would.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('scene-provider', {
 *   id: 'apple',
 *   props: { expose: ['apple-whole-scene'] },
 *   items: [{ factory: 'scene', id: 'apple-whole-scene', items: ['crm:apple-whole'] }],
 * });
 * // <SceneProvider scope="apple" expose={['apple-whole-scene']}>
 * //   <Scene ... />
 * // </SceneProvider>
 * ```
 */
export class SceneProviderFactory extends ContainerComponentFactory {
  renderComponent(items: RootRecord[]): ReactElement {
    const record = this.record();
    return createElement(SceneProvider, {
      scope: record.id,
      expose: readExpose(record.props),
      exposeEvents: readExposeEvents(record.props),
      children: this.renderItemComponents(items),
    });
  }
}
