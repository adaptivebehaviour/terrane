'use client';

import { useEffect, useState, type ReactNode } from 'react';

/**
 * True while the device is in portrait orientation (`(orientation: portrait)`),
 * updating on change. Starts `true` so server rendering and the first client
 * render agree. `Stage` (`@adaptivebehaviour/scenes-records`) uses this hook for
 * its short/long-axis flip, and `OrientationGate` below reuses it.
 */
export function useIsPortrait() {
  const [isPortrait, setIsPortrait] = useState(true);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(orientation: portrait)');
    const update = () => setIsPortrait(mediaQuery.matches);
    update();
    mediaQuery.addEventListener('change', update);
    return () => mediaQuery.removeEventListener('change', update);
  }, []);

  return isPortrait;
}

/**
 * Gates `children` behind landscape orientation, showing a "rotate your
 * device" message in portrait instead. Uses the same {@link useIsPortrait}
 * hook as `Stage`, so this stays consistent with `Stage`'s short/long-axis flip.
 */
export function OrientationGate({ children }: { children: ReactNode }) {
  const isPortrait = useIsPortrait();

  if (isPortrait) {
    return (
      <div className="flex h-dvh w-dvw items-center justify-center p-8 text-center">
        <p>Please rotate your device to landscape orientation to continue.</p>
      </div>
    );
  }

  return children;
}
