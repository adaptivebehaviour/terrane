import type { RegistryTarget } from '@adaptivebehaviour/manifesto/src/create';
import { defineCollection } from '@adaptivebehaviour/manifesto/src/registry';

export function register(target: RegistryTarget): void {}

/** This collection's declaration, for composing into a registry (see src/registry.ts). */
export const data = defineCollection({ id: 'data', dependsOn: ['manifesto'], register });
