'use client';

import { useEffect, useState, type ReactElement } from 'react';
import { useEventBuffer } from './useEventBuffer';
import type { SessionPropsConfig } from './session';
import { useScene, useSceneState } from '@adaptivebehaviour/scenes/src/hooks';

// The scene id `SessionInitStarter` (below) publishes `{ sessionId, userId }` to once
// `useEventBuffer()` resolves them — a fixed, well-known name (not configurable per
// page, unlike `startScene`) since anything reading it back needs to know it without
// `SessionInit` having to tell it.
export const SESSION_SCENE = 'session';

export interface SessionInitProps {
  // The calling page's own app id — always stamped onto every session as `app_id`
  // (session.ts's own `createSession()`), never gated the way `config` (below) is, so
  // this is required: a page mounting `SessionInit` at all must know which app it is.
  id: string;
  // `true` runs this component's original behaviour unchanged (`SessionInitStarter`,
  // below: a real `POST /api/sessions` row plus the IndexedDB event buffer, both
  // ultimately landing in Supabase). `false` mounts `LocalSessionInitStarter` (below)
  // instead — a `sessionId`/`userId` pair minted entirely client-side, published to
  // `SESSION_SCENE` the same way, but with no backend call and no event buffer, so
  // nothing this component does reaches Supabase at all. Optional, defaulting to
  // `false` — a new page collects nothing unless it explicitly opts in with `true`.
  collectData?: boolean;
  // The calling page's own `SessionPropsConfig` overrides — see `SessionPropsConfig`'s
  // own doc comment (session.ts) for how this merges over `lib/src/data/records.json`'s
  // defaults. Omitted entirely means every field stays at its default.
  config?: Partial<SessionPropsConfig>;
  // Names a scene id to wait for before creating a session at all — no `POST
  // /api/sessions`, so no `data.users`/`data.sessions` row, until that scene has
  // become active at least once (`Scene.tsx`'s own published `isActive`). Omitted
  // starts a session immediately on mount, same as before this prop existed — requires
  // `SessionInit` to be mounted inside a `<SceneProvider>` either way, since
  // `useSceneState` (below) is called unconditionally regardless of whether this is
  // actually given.
  startScene?: string;
}

interface WatchedSceneState {
  isActive?: boolean;
}

// Split out from `SessionInit` itself so `useEventBuffer` — and so `ensureSession()`'s
// own `POST /api/sessions` — is only ever *called* once `SessionInit` decides it's time
// (below), rather than merely gating its own effect from running: a hook can't be
// called conditionally, but a whole component can be mounted conditionally instead.
function SessionInitStarter({ id, config }: { id: string; config?: Partial<SessionPropsConfig> }): null {
  const { sessionId, userId } = useEventBuffer(id, config);
  const [, setSession] = useScene<{ sessionId?: string; userId?: string }>(SESSION_SCENE, {});

  // Publishes the backend-assigned ids to `SESSION_SCENE` the moment they're known — a
  // caller elsewhere reads this back out via `useSceneState(SESSION_SCENE)`, the same
  // source-reads-scene-state pattern used throughout. A plain `useEffect`, not
  // `useLayoutEffect` — nothing here anchors to a pre-paint measurement.
  useEffect(() => {
    if (sessionId) {
      setSession({ sessionId, userId });
    }
  }, [sessionId, userId, setSession]);

  return null;
}

// `crypto.randomUUID()` twice, lazily — `useState`'s own lazy-initializer form, so this
// only ever runs once per mount rather than minting a fresh, discarded pair on every
// render. Never sent anywhere: no `fetch`, no IndexedDB — these ids exist purely so
// `SESSION_SCENE` (below) still has *something* to publish, the same shape
// `SessionInitStarter` publishes once its own real `POST /api/sessions` resolves, so
// anything downstream that waits on `SESSION_SCENE` still proceeds normally with
// `props.collectData: false` — only *where* these ids came from differs, not whether
// they exist.
function LocalSessionInitStarter(): null {
  const [ids] = useState(() => ({ sessionId: crypto.randomUUID(), userId: crypto.randomUUID() }));
  const [, setSession] = useScene<{ sessionId?: string; userId?: string }>(SESSION_SCENE, {});

  useEffect(() => {
    setSession(ids);
  }, [ids, setSession]);

  return null;
}

/**
 * Mounted once near the root of a page that should identify a user and record a
 * session the moment a visitor loads it (implementation.md Section 4/5) — or, when
 * `startScene` is given, once that named scene first becomes active instead (e.g. so
 * nothing reaches Supabase while an intro scene is still showing). A plain client
 * component rather than a `RecordComponent`, matching `eventBuffer.ts`'s own doc
 * comment on why this module stays outside the Operation/Runnable/records system
 * entirely.
 *
 * Mounting `SessionInitStarter` (above) is what actually starts things — its own
 * `useEventBuffer(id, config)` triggers the whole flow via its own mount effect
 * calling `ensureSession(id, config)` (session.ts): reads the `id` query parameter from
 * the page's own URL if present, else lets the backend generate a fresh one; `POST
 * /api/sessions` (rewritten to the FastAPI backend's own `POST /sessions`,
 * next.config.ts) upserts that id into `data.users` (`db.py`'s own
 * `get_or_create_user()` — a no-op if a row with that id already exists) and inserts a
 * new `data.sessions` row against it, its own `props` always carrying `app_id` (`id`,
 * above) plus whichever of `timezone`/`userAgent`/`screen` `config` (merged over
 * `records.json`'s defaults) actually flags `true` (`create_session()`); the resolved
 * `{ userId, sessionId }` then initialises the IndexedDB event buffer so any other
 * component in the tree can call its own `useEventBuffer().recordEvent()` afterward, and
 * is also republished to `SESSION_SCENE` (above) so anything reading scene state — not
 * just this module's own event-recording API — can get at the same two ids.
 *
 * `ready` starts `true` when no `startScene` is given — the original, ungated
 * behaviour — or `false` otherwise, flipping to `true` (and staying there — a one-shot
 * latch, not a live toggle) the first time `useSceneState(startScene)` reports
 * `isActive`. Renders nothing either way — this component exists purely to give a hook
 * a place to run from, for callers (e.g. an async Server Component page) that can't
 * call a hook or touch IndexedDB themselves.
 *
 * `collectData` (above) picks which of `SessionInitStarter`/`LocalSessionInitStarter`
 * actually mounts once `ready` — the choice of *which* component to render, rather than
 * a condition inside one shared component, is what keeps `SessionInitStarter`'s own
 * `useEventBuffer()` call (and so its `POST /api/sessions`) from ever running at all when
 * `collectData` is `false`, since a hook can't be called conditionally but a whole
 * component can be mounted conditionally instead — the same reason `ready`/`SessionInit`
 * are split from `SessionInitStarter` to begin with (this component's own doc comment,
 * just above).
 */
export function SessionInit({ id, config, startScene, collectData = false }: SessionInitProps): ReactElement | null {
  const scene = useSceneState<WatchedSceneState>(startScene ?? '');
  const [ready, setReady] = useState(!startScene);

  useEffect(() => {
    if (!ready && scene?.isActive) {
      setReady(true);
    }
  }, [ready, scene?.isActive]);

  if (!ready) {
    return null;
  }

  return collectData ? <SessionInitStarter id={id} config={config} /> : <LocalSessionInitStarter />;
}
