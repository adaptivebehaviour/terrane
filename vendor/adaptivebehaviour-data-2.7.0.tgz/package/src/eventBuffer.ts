/**
 * IndexedDB-backed event buffer (implementation.md Section 8). Browser-only code — it does
 * not go through the Operation/Runnable/Fetch abstractions in create.ts/Runnable.ts, since
 * those are Next.js server-side constructs; this has to run in the browser tab itself.
 *
 * Design: every recorded event is written to IndexedDB immediately, before anything touches
 * the network, so gameplay never waits on a round-trip. A background timer drains the buffer
 * through the application's `DataSender` (./sender.ts) on a fixed interval or an event-count
 * threshold, whichever fires first. An event is only deleted once the destination has
 * acknowledged the batch — on failure it stays buffered and is retried on the next tick.
 */

import type { EventBatchRequest } from './sender';
import { getDataSender } from './sender';
import { openDB, type IDBPDatabase } from 'idb';

const DB_NAME = 'data-events';
const DB_VERSION = 1;
const STORE_NAME = 'events';

// Sensible starting defaults (Section 8/11) — the game's actual event frequency isn't known
// yet and may vary a lot between games, so these are deliberately easy to tune later rather
// than hardcoded deep in the flush logic.
const FLUSH_INTERVAL_MS = 5_000;
const FLUSH_THRESHOLD_COUNT = 25;

export interface BufferedEvent {
  id: string;
  index: number;
  // Omitted (rather than defaulted here to some string) when a caller doesn't pass one —
  // `data.events.kind` has its own `'event'` column default at Supabase now, so an absent
  // `kind` reaches the database as a genuinely missing column, not a hardcoded fallback
  // this layer would otherwise have to invent and keep in sync with the DB's own default.
  kind?: string;
  props: Record<string, unknown>;
  browserTimestamp: string;
}

interface BufferState {
  sessionId: string;
  userId: string;
  nextIndex: number;
  dbPromise: Promise<IDBPDatabase>;
  flushing: boolean;
}

let state: BufferState | null = null;

function openEventDb(): Promise<IDBPDatabase> {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    },
  });
}

function toWireEvent(event: BufferedEvent) {
  return {
    id: event.id,
    index: event.index,
    // `JSON.stringify` drops a key entirely when its value is `undefined` — an unset
    // `kind` reaches `POST /api/events/batch` with no `kind` key at all, not a `null`.
    kind: event.kind,
    props: event.props,
    browser_timestamp: event.browserTimestamp,
  };
}

function toBatch(buffer: BufferState, events: BufferedEvent[]): EventBatchRequest {
  return { session_id: buffer.sessionId, user_id: buffer.userId, events: events.map(toWireEvent) };
}

/** Called once per page load, after the session is created (see session.ts). */
export function initEventBuffer(sessionId: string, userId: string): void {
  if (state) {
    return;
  }
  state = {
    sessionId,
    userId,
    nextIndex: 0,
    dbPromise: openEventDb(),
    flushing: false,
  };

  setInterval(() => {
    void flush();
  }, FLUSH_INTERVAL_MS);

  if (typeof window !== 'undefined') {
    window.addEventListener('pagehide', () => {
      void flushViaBeacon();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        void flushViaBeacon();
      }
    });
  }
}

export async function recordEvent(kind?: string, props: Record<string, unknown> = {}): Promise<void> {
  if (!state) {
    throw new Error(
      'recordEvent() called before initEventBuffer() — call session.ts\'s ensureSession() ' +
      '(or the useEventBuffer hook, which does this for you) first.'
    );
  }
  const event: BufferedEvent = {
    id: crypto.randomUUID(),
    index: state.nextIndex++,
    kind,
    props,
    browserTimestamp: new Date().toISOString(),
  };

  const db = await state.dbPromise;
  await db.put(STORE_NAME, event);

  const count = await db.count(STORE_NAME);
  if (count >= FLUSH_THRESHOLD_COUNT) {
    void flush();
  }
}

export async function getBufferedCount(): Promise<number> {
  if (!state) return 0;
  const db = await state.dbPromise;
  return db.count(STORE_NAME);
}

/**
 * Forces an immediate flush instead of waiting for the interval/threshold trigger, and
 * reports whether the buffer is empty afterwards. Intended for callers that want to know
 * the outcome (e.g. a "send now" UI action) — the periodic/threshold-triggered flushes
 * elsewhere in this module don't need this, since they're fire-and-forget by design.
 */
export async function flushNow(): Promise<boolean> {
  await flush();
  return (await getBufferedCount()) === 0;
}

async function flush(): Promise<void> {
  if (!state || state.flushing) return;
  state.flushing = true;
  try {
    const db = await state.dbPromise;
    const events: BufferedEvent[] = await db.getAll(STORE_NAME);
    if (events.length === 0) return;

    const acknowledged = await getDataSender().sendEvents(toBatch(state, events));

    if (acknowledged) {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      await Promise.all(events.map((event) => tx.store.delete(event.id)));
      await tx.done;
    }
    // Not acknowledged: leave the events buffered; retried on the next flush tick.
  } finally {
    state.flushing = false;
  }
}

/**
 * Final flush on pagehide/visibilitychange, through the sender's unload route (sendBeacon for the web routes), which
 * survives the page unloading mid-request (Section 8). It gives no response, so this deliberately does NOT delete the
 * flushed events from IndexedDB — they stay buffered and get ack-gated deletion on the next successful flush (e.g. after
 * the next page load re-initialises the buffer). A duplicate send in the meantime is harmless: the destination's write
 * is idempotent on event id (Section 6). A sender without an unload route is simply skipped.
 */
async function flushViaBeacon(): Promise<void> {
  const sender = getDataSender();
  if (!state || !sender.sendEventsOnUnload) return;
  const db = await state.dbPromise;
  const events: BufferedEvent[] = await db.getAll(STORE_NAME);
  if (events.length === 0) return;

  sender.sendEventsOnUnload(toBatch(state, events));
}
