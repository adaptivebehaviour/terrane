/**
 * Which destination an application sends its data to: a `kind` plus that kind's own `settings`, as plain data read when the
 * application starts. Something that lets an end user choose a destination later only has to produce one in the same form.
 * Credentials never appear in it: a destination reads them from its environment (or, on the desktop, `safeStorage`).
 */
export interface DestinationConfig {
  kind: string;
  settings?: Record<string, unknown>;
}

/**
 * The applications that may write to the user's local file system. `electron` covers every desktop project: the shell's
 * `src/main/config.ts` declares it, and `electron-fastapi` does not override that file.
 */
export const DESKTOP_APPLICATIONS = ['electron'] as const;

/**
 * The kinds of destination, and where each may be used. `applications` omitted means any application.
 * `supabase` runs in the Python backend (`ab_data.destinations`); `local-file` runs in the Electron main process
 * (`@adaptivebehaviour/desktop`). A new kind is added here, and its implementation next to wherever it runs.
 */
export const DESTINATION_KINDS: Record<string, { applications?: readonly string[] }> = {
  supabase: {},
  'local-file': { applications: DESKTOP_APPLICATIONS },
};

/** The destination each application starts with. */
export const DEFAULT_DESTINATIONS: Record<string, DestinationConfig> = {
  'nextjs-fastapi': { kind: 'supabase' },
  electron: { kind: 'local-file' },
};

export class DestinationConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DestinationConfigError';
  }
}

export function defaultDestinationConfig(application: string): DestinationConfig {
  const config = DEFAULT_DESTINATIONS[application];
  if (!config) throw new DestinationConfigError(`No default data destination for application '${application}'.`);
  return config;
}

/** Returns `config` when its kind exists and may be used in `application`; otherwise throws. */
export function resolveDestinationConfig(config: DestinationConfig, application: string): DestinationConfig {
  const kind = DESTINATION_KINDS[config.kind];
  if (!kind) {
    throw new DestinationConfigError(
      `Unknown data destination kind '${config.kind}' (known: ${Object.keys(DESTINATION_KINDS).join(', ')}).`,
    );
  }
  if (kind.applications && !kind.applications.includes(application)) {
    throw new DestinationConfigError(
      `The '${config.kind}' data destination is not available in '${application}' applications ` +
        `(only in: ${kind.applications.join(', ')}).`,
    );
  }
  return config;
}
