import { z } from 'zod';
import { cssProperties } from '@adaptivebehaviour/manifesto/src/manifesto/schemas';

// Props schemas for the ui collection. The Radix wrappers share one loose props shape (an optional
// `styling`: a class name or a style map); the two that read specific props have their own.

export const uiProps = z.looseObject({
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'UiProps' });

export const avatarProps = z.looseObject({
  src: z.string().optional(),
  alt: z.string().optional(),
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'AvatarProps' });

export const directionProps = z.looseObject({
  dir: z.enum(['ltr', 'rtl']).optional(),
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'DirectionProps' });

// Props for the components that read their own props. Components that only take a label from `items` use `uiProps`.

const styling = z.union([z.string(), cssProperties]).optional();

export const buttonProps = z.looseObject({
  variant: z.enum(['primary', 'secondary', 'ghost', 'link']).optional(),
  size: z.enum(['sm', 'md', 'lg']).optional(),
  fullWidth: z.boolean().optional(),
  loading: z.boolean().optional(),
  disabled: z.boolean().optional(),
  styling,
}).meta({ id: 'ButtonProps' });

export const iconButtonProps = z.looseObject({
  variant: z.enum(['ghost', 'secondary', 'primary']).optional(),
  size: z.enum(['sm', 'md', 'lg']).optional(),
  src: z.string().optional(),
  styling,
}).meta({ id: 'IconButtonProps' });

export const badgeProps = z.looseObject({
  tone: z.enum(['neutral', 'accent', 'success', 'warning', 'danger', 'outline']).optional(),
  styling,
}).meta({ id: 'BadgeProps' });

export const tagProps = z.looseObject({
  selected: z.boolean().optional(),
  styling,
}).meta({ id: 'TagProps' });

export const cardProps = z.looseObject({
  variant: z.enum(['outline', 'subtle', 'elevated']).optional(),
  padding: z.enum(['none', 'sm', 'md', 'lg']).optional(),
  interactive: z.boolean().optional(),
  styling,
}).meta({ id: 'CardProps' });

export const iconProps = z.looseObject({
  src: z.string().optional(),
  size: z.number().optional(),
  styling,
}).meta({ id: 'IconProps' });

export const inputProps = z.looseObject({
  hint: z.string().optional(),
  error: z.string().optional(),
  placeholder: z.string().optional(),
  type: z.string().optional(),
  icon: z.string().optional(),
  styling,
}).meta({ id: 'InputProps' });

export const wordmarkProps = z.looseObject({
  size: z.number().optional(),
  tone: z.enum(['ink', 'inverse']).optional(),
  styling,
}).meta({ id: 'WordmarkProps' });

export const likertScaleProps = z.looseObject({
  points: z.number().optional(),
  defaultValue: z.number().optional(),
  anchors: z.array(z.string()).optional(),
  name: z.string().optional(),
  showNumbers: z.boolean().optional(),
  styling,
}).meta({ id: 'LikertScaleProps' });

export const scoreBarProps = z.looseObject({
  score: z.number().optional(),
  min: z.number().optional(),
  max: z.number().optional(),
  band: z.tuple([z.number(), z.number()]).optional(),
  lowLabel: z.string().optional(),
  highLabel: z.string().optional(),
  valueLabel: z.string().optional(),
  description: z.string().optional(),
  variant: z.enum(['dot', 'fill']).optional(),
  styling,
}).meta({ id: 'ScoreBarProps' });

export const radioItemProps = z.looseObject({
  value: z.string().optional(),
  description: z.string().optional(),
  disabled: z.boolean().optional(),
  styling,
}).meta({ id: 'RadioItemProps' });

export const toastProps = z.looseObject({
  tone: z.enum(['neutral', 'accent', 'success', 'warning', 'danger']).optional(),
  styling,
}).meta({ id: 'ToastProps' });

export const progressProps = z.looseObject({
  value: z.number().optional(),
  max: z.number().optional(),
  showValue: z.boolean().optional(),
  valueLabel: z.string().optional(),
  size: z.enum(['sm', 'md', 'lg']).optional(),
  tone: z.enum(['ink', 'accent']).optional(),
  styling,
}).meta({ id: 'ProgressProps' });

export const tabsProps = z.looseObject({
  variant: z.enum(['underline', 'segmented']).optional(),
  styling,
}).meta({ id: 'TabsProps' });
