'use client';

import { Avatar as AvatarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { avatarProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/** Factory `'Avatar'` — wraps Radix Avatar with optional default styles. */
export const Avatar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <AvatarPrimitive.Root data-id={record.id} className={styled ? 'avatar' : undefined}>
      <AvatarPrimitive.Image
        src={propsOf(avatarProps, record).src}
        alt={propsOf(avatarProps, record).alt ?? 'Avatar'}
        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
      />
      <AvatarPrimitive.Fallback delayMs={600} className={styled ? 'avatar-fallback' : undefined}>
        {(record.items[0] as string) ?? 'AB'}
      </AvatarPrimitive.Fallback>
    </AvatarPrimitive.Root>
  );
};
