'use client';

import { RadioGroup as RadioGroupPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';
import { RadioOption } from './RadioItem';

/**
 * Factory `'RadioGroup'` — wraps Radix RadioGroup with optional default styles.
 * Renders one option per element of `record.items`, not a fixed count — each
 * item's own string value (or `Option <n>` if not a string) becomes that
 * option's label, and options are valued `'option-1'`, `'option-2'`, etc. in
 * `record.items` order.
 */
export const RadioGroup: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <RadioGroupPrimitive.Root data-id={record.id} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
      {record.items.map((item, index) => (
        <RadioOption
          key={`option-${index + 1}`}
          value={`option-${index + 1}`}
          label={(item as string) ?? `Option ${index + 1}`}
          styled={styled}
        />
      ))}
    </RadioGroupPrimitive.Root>
  );
};
