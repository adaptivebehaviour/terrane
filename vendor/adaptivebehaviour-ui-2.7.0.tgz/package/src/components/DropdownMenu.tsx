'use client';

import { DropdownMenu as DropdownMenuPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'DropdownMenu'` — wraps Radix DropdownMenu with optional default styles. */
export const DropdownMenu: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <DropdownMenuPrimitive.Root data-id={record.id}>
      <DropdownMenuPrimitive.Trigger className={styled ? 'button button-ghost button-md' : undefined}>
        {(record.items[0] as string) ?? 'Open menu'}
      </DropdownMenuPrimitive.Trigger>
      <DropdownMenuPrimitive.Portal>
        <DropdownMenuPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined} sideOffset={4}>
          <DropdownMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            {(record.items[1] as string) ?? 'Profile'}
          </DropdownMenuPrimitive.Item>
          <DropdownMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            {(record.items[2] as string) ?? 'Settings'}
          </DropdownMenuPrimitive.Item>
          <DropdownMenuPrimitive.Separator className={styled ? 'dropdown-menu-separator' : undefined} />
          <DropdownMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            Logout
          </DropdownMenuPrimitive.Item>
        </DropdownMenuPrimitive.Content>
      </DropdownMenuPrimitive.Portal>
    </DropdownMenuPrimitive.Root>
  );
};
