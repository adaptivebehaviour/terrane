'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { badgeProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const TONE = {
  neutral: 'badge-neutral',
  accent: 'badge-accent',
  success: 'badge-success',
  warning: 'badge-warning',
  danger: 'badge-danger',
  outline: 'badge-outline',
} as const;

/** Factory `'Badge'` — a small static status label with optional default styles. */
export const Badge: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { tone = 'neutral' } = propsOf(badgeProps, record);
  return (
    <span data-id={record.id} className={styled ? `badge ${TONE[tone]}` : undefined}>
      {(record.items[0] as string) ?? 'Badge'}
    </span>
  );
};
