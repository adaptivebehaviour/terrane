'use client';

import { ToggleGroup as ToggleGroupPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'ToggleGroup'` — wraps Radix ToggleGroup with optional default styles. */
export const ToggleGroup: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const item = styled ? 'button button-ghost button-md toggle' : undefined;
  return (
    <ToggleGroupPrimitive.Root data-id={record.id} type="single" defaultValue="center" className="toggle-group">
      <ToggleGroupPrimitive.Item value="left" className={item}>
        {(record.items[0] as string) ?? 'Left'}
      </ToggleGroupPrimitive.Item>
      <ToggleGroupPrimitive.Item value="center" className={item}>
        {(record.items[1] as string) ?? 'Center'}
      </ToggleGroupPrimitive.Item>
      <ToggleGroupPrimitive.Item value="right" className={item}>
        {(record.items[2] as string) ?? 'Right'}
      </ToggleGroupPrimitive.Item>
    </ToggleGroupPrimitive.Root>
  );
};
