'use client';

import { Accordion as AccordionPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Accordion'` — wraps Radix Accordion with optional default styles. */
export const Accordion: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <AccordionPrimitive.Root type="single" collapsible defaultValue="item-1" data-id={record.id}>
      <AccordionPrimitive.Item value="item-1">
        <AccordionPrimitive.Header>
          <AccordionPrimitive.Trigger className={styled ? 'button button-ghost button-md' : undefined}>
            {(record.items[0] as string) ?? 'Accordion item'}
          </AccordionPrimitive.Trigger>
        </AccordionPrimitive.Header>
        <AccordionPrimitive.Content className={styled ? 'accordion-content' : undefined}>
          {(record.items[1] as string) ?? 'Accordion content'}
        </AccordionPrimitive.Content>
      </AccordionPrimitive.Item>
    </AccordionPrimitive.Root>
  );
};
