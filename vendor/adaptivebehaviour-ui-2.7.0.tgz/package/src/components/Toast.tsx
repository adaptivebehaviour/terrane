'use client';

import { Toast as ToastPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { toastProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const TONE = {
  neutral: 'toast',
  accent: 'toast toast-accent',
  success: 'toast toast-success',
  warning: 'toast toast-warning',
  danger: 'toast toast-danger',
} as const;

/** Factory `'Toast'` — wraps Radix Toast with optional default styles; `props.tone` colours its status dot. */
export const Toast: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { tone = 'neutral' } = propsOf(toastProps, record);
  return (
    <ToastPrimitive.Provider swipeDirection="right">
      <ToastPrimitive.Root
        data-id={record.id}
        open
        className={styled ? TONE[tone] : undefined}
      >
        <span className={styled ? 'toast-dot' : undefined} aria-hidden="true" />
        <div className={styled ? 'toast-text' : undefined}>
          <ToastPrimitive.Title className={styled ? 'toast-title' : undefined}>
            {(record.items[0] as string) ?? 'Scheduled'}
          </ToastPrimitive.Title>
          <ToastPrimitive.Description className={styled ? 'toast-message' : undefined}>
            {(record.items[1] as string) ?? 'Your message has been sent.'}
          </ToastPrimitive.Description>
        </div>
        <ToastPrimitive.Close className={styled ? 'toast-close' : undefined} aria-label="Close">
          ×
        </ToastPrimitive.Close>
      </ToastPrimitive.Root>
      <ToastPrimitive.Viewport
        className={styled ? 'toast-viewport' : undefined}
        style={{
          position: 'fixed',
          bottom: 'var(--space-6)',
          right: 'var(--space-6)',
          display: 'flex',
          flexDirection: 'column',
          gap: 'var(--space-2)',
          width: 360,
          maxWidth: '100vw',
          margin: 0,
          listStyle: 'none',
          zIndex: 100,
          outline: 'none',
        }}
      />
    </ToastPrimitive.Provider>
  );
};
