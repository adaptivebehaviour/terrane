'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { cardProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const VARIANT = { outline: 'card-outline', subtle: 'card-subtle', elevated: 'card-elevated' } as const;
const PADDING = { none: 'p-0', sm: 'p-4', md: 'p-6', lg: 'p-8' } as const;

/** Factory `'Card'` — a bordered surface container with optional default styles; `items[0]` is its content. */
export const Card: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { variant = 'outline', padding = 'md', interactive = false } = propsOf(cardProps, record);
  const className = ['card', VARIANT[variant], PADDING[padding],interactive ? 'card-interactive' : ''].filter(Boolean).join(' ');
  return (
    <div data-id={record.id} className={styled ? className : undefined}>
      {record.items[0] as string | undefined}
    </div>
  );
};
