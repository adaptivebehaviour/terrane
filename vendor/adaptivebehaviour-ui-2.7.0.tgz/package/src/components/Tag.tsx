'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { tagProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/** Factory `'Tag'` — a pill-shaped keyword with optional default styles. */
export const Tag: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { selected = false } = propsOf(tagProps, record);
  return (
    <span data-id={record.id} className={styled ? (selected ? 'tag is-selected' : 'tag') : undefined}>
      <span>{(record.items[0] as string) ?? 'Tag'}</span>
    </span>
  );
};
