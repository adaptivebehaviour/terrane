'use client';

import { AlertDialog as AlertDialogPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'AlertDialog'` — wraps Radix AlertDialog with optional default styles. */
export const AlertDialog: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <AlertDialogPrimitive.Root data-id={record.id}>
      <AlertDialogPrimitive.Trigger className={styled ? 'button button-secondary button-md' : undefined}>
        {(record.items[0] as string) ?? 'Open alert'}
      </AlertDialogPrimitive.Trigger>
      <AlertDialogPrimitive.Portal>
        <AlertDialogPrimitive.Overlay className={styled ? 'overlay' : undefined}>
          <AlertDialogPrimitive.Content
            className={styled ? 'dialog' : undefined}
            style={styled ? { width: 480, maxWidth: '100%' } : undefined}
          >
            <AlertDialogPrimitive.Title className={styled ? 'dialog-title' : undefined}>
              {(record.items[1] as string) ?? 'Are you sure?'}
            </AlertDialogPrimitive.Title>
            <AlertDialogPrimitive.Description className={styled ? 'dialog-description' : undefined}>
              {(record.items[2] as string) ?? 'This action cannot be undone.'}
            </AlertDialogPrimitive.Description>
            <div className={styled ? 'dialog-footer' : undefined}>
              <AlertDialogPrimitive.Cancel className={styled ? 'button button-ghost button-md' : undefined}>
                Cancel
              </AlertDialogPrimitive.Cancel>
              <AlertDialogPrimitive.Action className={styled ? 'button button-primary button-md' : undefined}>
                Continue
              </AlertDialogPrimitive.Action>
            </div>
          </AlertDialogPrimitive.Content>
        </AlertDialogPrimitive.Overlay>
      </AlertDialogPrimitive.Portal>
    </AlertDialogPrimitive.Root>
  );
};
