'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { buttonProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const VARIANT = { primary: 'button-primary', secondary: 'button-secondary', ghost: 'button-ghost', link: 'button-link' } as const;
const SIZE = { sm: 'button-sm', md: 'button-md', lg: 'button-lg' } as const;

/** Factory `'Button'` — a button with optional default styles. One `primary` per view; `link` takes no size. */
export const Button: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { variant = 'primary', size = 'md', fullWidth = false, loading = false, disabled = false } = propsOf(buttonProps, record);
  const className = ['button', VARIANT[variant], variant === 'link' ? '' : SIZE[size], fullWidth ? 'w-full' : '']
    .filter(Boolean).join(' ');
  return (
    <button
      type="button"
      data-id={record.id}
      className={styled ? className : undefined}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
    >
      {loading && <span className={styled ? 'spinner' : undefined} aria-hidden="true" />}
      <span>{(record.items[0] as string) ?? 'Button'}</span>
    </button>
  );
};
