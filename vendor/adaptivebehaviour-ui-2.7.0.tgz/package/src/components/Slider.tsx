'use client';

import { Slider as SliderPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Slider'` — wraps Radix Slider with optional default styles. */
export const Slider: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <SliderPrimitive.Root
      data-id={record.id}
      defaultValue={[40]}
      max={100}
      step={1}
      className={styled ? 'slider' : undefined}
    >
      <SliderPrimitive.Track className={styled ? 'slider-track' : undefined}>
        <SliderPrimitive.Range className={styled ? 'slider-range' : undefined} />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb
        className={styled ? 'slider-thumb' : undefined}
        aria-label={(record.items[0] as string) ?? 'Volume'}
      />
    </SliderPrimitive.Root>
  );
};
