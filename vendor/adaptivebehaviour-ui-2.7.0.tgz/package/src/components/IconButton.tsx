'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { iconButtonProps } from '../schemas';
import { useDefaultStyling } from '../styling';
import { IconMask } from './Icon';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const VARIANT = { ghost: 'icon-button-ghost', secondary: 'icon-button-secondary', primary: 'icon-button-primary' } as const;
const SIZE = { sm: 'icon-button-sm', md: 'icon-button-md', lg: 'icon-button-lg' } as const;

/** Factory `'IconButton'` — a square icon-only button; `items[0]` is its accessible label, `props.src` its icon. */
export const IconButton: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { variant = 'ghost', size = 'md', src } = propsOf(iconButtonProps, record);
  const label = (record.items[0] as string) ?? 'Icon button';
  return (
    <button
      type="button"
      data-id={record.id}
      aria-label={label}
      title={label}
      className={styled ? `icon-button ${VARIANT[variant]} ${SIZE[size]}` : undefined}
    >
      {src && <IconMask src={src} className={styled ? 'icon' : undefined} />}
    </button>
  );
};
