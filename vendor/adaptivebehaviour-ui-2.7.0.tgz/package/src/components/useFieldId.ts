import { useId } from 'react';

/** The explicit `id` if given, otherwise a stable generated one — links a field's label to its control. */
export function useFieldId(id?: string): string {
  const generated = useId();
  return id ?? `field-${generated}`;
}
