'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { wordmarkProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/** Factory `'Wordmark'` — the psymetri logo: the lowercase word in Poppins Medium. `ink` on light surfaces, `inverse` on ink. */
export const Wordmark: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { size = 24, tone = 'ink' } = propsOf(wordmarkProps, record);
  return (
    <span
      data-id={record.id}
      className={styled ? 'wordmark' : undefined}
      style={styled ? { fontSize: size, color: tone === 'inverse' ? 'var(--text-inverse)' : 'var(--text-primary)' } : undefined}
    >
      psymetri
    </span>
  );
};
