'use client';

import { RadioGroup as RadioGroupPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { likertScaleProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/**
 * Factory `'LikertScale'` — an ordered response scale for a measure item, built on Radix RadioGroup.
 * 2–3 `anchors` are spread (ends / middle); a list as long as `points` labels every option.
 */
export const LikertScale: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { points = 5, defaultValue, anchors, name, showNumbers = true } = propsOf(likertScaleProps, record);
  const items = Array.from({ length: points }, (_, i) => i + 1);
  const labels = anchors || ['Strongly disagree', 'Neutral', 'Strongly agree'];
  const labelled = labels.length === points;
  const columns = `repeat(${points},minmax(0,1fr))`;
  return (
    <RadioGroupPrimitive.Root
      data-id={record.id}
      className={styled ? 'likert' : undefined}
      aria-label={name}
      defaultValue={defaultValue != null ? String(defaultValue) : undefined}
    >
      <div className={styled ? 'likert-row' : undefined} style={{ display: 'grid', gridTemplateColumns: columns }}>
        {items.map((n) => (
          <RadioGroupPrimitive.Item
            key={n}
            value={String(n)}
            aria-label={labelled ? labels[n - 1] : String(n)}
            className={styled ? 'likert-option' : undefined}
          >
            {showNumbers ? n : ''}
          </RadioGroupPrimitive.Item>
        ))}
      </div>
      <div
        className={styled ? (labelled ? 'likert-anchors likert-anchors-grid' : 'likert-anchors likert-anchors-spread') : undefined}
        style={labelled ? { gridTemplateColumns: columns } : undefined}
      >
        {labels.map((text, i) => <span key={i}>{text}</span>)}
      </div>
    </RadioGroupPrimitive.Root>
  );
};
