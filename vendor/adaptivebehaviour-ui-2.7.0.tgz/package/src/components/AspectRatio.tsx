'use client';

import { AspectRatio as AspectRatioPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';

/** Factory `'AspectRatio'` — wraps Radix AspectRatio. */
export const AspectRatio: RecordComponent = ({ record }) => (
  <AspectRatioPrimitive.Root ratio={16 / 9} data-id={record.id} className="aspect-ratio">
    <div className="aspect-ratio-content">
      {(record.items[0] as string) ?? '16:9'}
    </div>
  </AspectRatioPrimitive.Root>
);
