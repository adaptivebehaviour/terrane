'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { scoreBarProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/**
 * Factory `'ScoreBar'` — a single scored dimension in a results report: the dot-on-track motif.
 * `items[0]` is its label; `variant` `dot` is a position marker (bipolar traits), `fill` a magnitude bar.
 */
export const ScoreBar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { score = 0, min = 0, max = 100, band, lowLabel, highLabel, valueLabel, description, variant = 'dot' } =
    propsOf(scoreBarProps, record);
  const label = record.items[0] as string | undefined;
  const position = (value: number) => Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
  const at = position(score);
  return (
    <div data-id={record.id} className={styled ? 'score' : undefined}>
      {(label || valueLabel !== undefined) && (
        <div className={styled ? 'score-head' : undefined}>
          <span className={styled ? 'score-label' : undefined}>{label}</span>
          <span className={styled ? 'score-value tabular-nums lining-nums' : undefined}>{valueLabel !== undefined ? valueLabel : score}</span>
        </div>
      )}
      {description && <p className={styled ? 'score-description' : undefined}>{description}</p>}
      <div
        className={styled ? 'score-track' : undefined}
        role="meter"
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={score}
        aria-label={label}
      >
        {band && (
          <div
            className={styled ? 'score-band' : undefined}
            style={{ left: `${position(band[0])}%`, width: `${position(band[1]) - position(band[0])}%` }}
          />
        )}
        {variant === 'fill' && <div className={styled ? 'score-fill' : undefined} style={{ width: `${at}%` }} />}
        {variant === 'dot' && <div className={styled ? 'score-marker' : undefined} style={{ left: `${at}%` }} />}
      </div>
      {(lowLabel || highLabel) && <div className={styled ? 'score-ends' : undefined}><span>{lowLabel}</span><span>{highLabel}</span></div>}
    </div>
  );
};
