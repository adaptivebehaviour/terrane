'use client';

import type { CSSProperties } from 'react';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { iconProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/**
 * An icon drawn from an SVG at `src`, painted in the current text colour (a CSS mask, so it follows
 * `color` the way a font icon would). Where the SVG comes from is up to the application: a Sanity URL
 * requested at run time, or a downloaded file the application imports.
 */
export function IconMask({ src, size = 18, className }: { src: string; size?: number; className?: string }) {
  const mask = `url("${src}") center / contain no-repeat`;
  const style: CSSProperties = { width: size, height: size, mask, WebkitMask: mask, backgroundColor: 'currentColor' };
  return <span className={className} style={style} aria-hidden="true" />;
}

/** Factory `'Icon'` — an SVG icon from `props.src`, with optional default styles. */
export const Icon: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { src, size } = propsOf(iconProps, record);
  return src ? <IconMask src={src} size={size} className={styled ? 'icon' : undefined} /> : null;
};
