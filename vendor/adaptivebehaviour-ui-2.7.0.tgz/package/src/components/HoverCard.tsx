'use client';

import { HoverCard as HoverCardPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'HoverCard'` — wraps Radix HoverCard with optional default styles. */
export const HoverCard: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <HoverCardPrimitive.Root data-id={record.id}>
      <HoverCardPrimitive.Trigger className={styled ? 'button button-ghost button-md' : undefined}>
        {(record.items[0] as string) ?? 'Hover me'}
      </HoverCardPrimitive.Trigger>
      <HoverCardPrimitive.Portal>
        <HoverCardPrimitive.Content className={styled ? 'popover-content' : undefined} sideOffset={4}>
          {(record.items[1] as string) ?? 'Hover card content'}
        </HoverCardPrimitive.Content>
      </HoverCardPrimitive.Portal>
    </HoverCardPrimitive.Root>
  );
};
