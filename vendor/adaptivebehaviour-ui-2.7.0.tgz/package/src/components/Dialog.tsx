'use client';

import { Dialog as DialogPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Dialog'` — wraps Radix Dialog with optional default styles. */
export const Dialog: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <DialogPrimitive.Root data-id={record.id}>
      <DialogPrimitive.Trigger className={styled ? 'button button-primary button-md' : undefined}>
        {(record.items[0] as string) ?? 'Open dialog'}
      </DialogPrimitive.Trigger>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className={styled ? 'overlay' : undefined}>
          <DialogPrimitive.Content
            className={styled ? 'dialog' : undefined}
            style={styled ? { width: 480, maxWidth: '100%' } : undefined}
          >
            <DialogPrimitive.Close
              className={styled ? 'icon-button icon-button-ghost icon-button-sm dialog-close' : undefined}
              aria-label="Close"
            >
              ×
            </DialogPrimitive.Close>
            <DialogPrimitive.Title className={styled ? 'dialog-title' : undefined}>
              {(record.items[1] as string) ?? 'Dialog title'}
            </DialogPrimitive.Title>
            <DialogPrimitive.Description className={styled ? 'dialog-description' : undefined}>
              {(record.items[2] as string) ?? 'Dialog description.'}
            </DialogPrimitive.Description>
            <div className={styled ? 'dialog-footer' : undefined}>
              <DialogPrimitive.Close className={styled ? 'button button-secondary button-md' : undefined}>
                Close
              </DialogPrimitive.Close>
            </div>
          </DialogPrimitive.Content>
        </DialogPrimitive.Overlay>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
};
