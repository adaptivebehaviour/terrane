'use client';

import { Menubar as MenubarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Menubar'` — wraps Radix Menubar with optional default styles. */
export const Menubar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <MenubarPrimitive.Root data-id={record.id} className={styled ? 'menubar' : undefined}>
      <MenubarPrimitive.Menu>
        <MenubarPrimitive.Trigger className={styled ? 'button button-ghost button-md' : undefined}>
          {(record.items[0] as string) ?? 'File'}
        </MenubarPrimitive.Trigger>
        <MenubarPrimitive.Portal>
          <MenubarPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined}>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>New</MenubarPrimitive.Item>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Open</MenubarPrimitive.Item>
          </MenubarPrimitive.Content>
        </MenubarPrimitive.Portal>
      </MenubarPrimitive.Menu>
      <MenubarPrimitive.Menu>
        <MenubarPrimitive.Trigger className={styled ? 'button button-ghost button-md' : undefined}>
          {(record.items[1] as string) ?? 'Edit'}
        </MenubarPrimitive.Trigger>
        <MenubarPrimitive.Portal>
          <MenubarPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined}>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Cut</MenubarPrimitive.Item>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Copy</MenubarPrimitive.Item>
          </MenubarPrimitive.Content>
        </MenubarPrimitive.Portal>
      </MenubarPrimitive.Menu>
    </MenubarPrimitive.Root>
  );
};
