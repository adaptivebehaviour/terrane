'use client';

import { Label as LabelPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { inputProps } from '../schemas';
import { useDefaultStyling } from '../styling';
import { IconMask } from './Icon';
import { useFieldId } from './useFieldId';

/** Factory `'Input'` — a single-line text field; `items[0]` is its label, `props.icon` a leading icon (an SVG URL). */
export const Input: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { hint, error, placeholder, type, icon } = propsOf(inputProps, record);
  const label = record.items[0] as string | undefined;
  const id = useFieldId();
  return (
    <div data-id={record.id} className={styled ? 'field' : undefined}>
      {label && <LabelPrimitive.Root className={styled ? 'field-label' : undefined} htmlFor={id}>{label}</LabelPrimitive.Root>}
      <div className={styled ? ['input', error ? 'is-error' : '', icon ? 'has-icon' : ''].filter(Boolean).join(' ') : undefined}>
        {icon && <span className={styled ? 'input-icon' : undefined}><IconMask src={icon} /></span>}
        <input id={id} type={type} placeholder={placeholder} aria-invalid={error ? true : undefined} />
      </div>
      {(error || hint) && <div className={styled ? (error ? 'field-hint is-error' : 'field-hint') : undefined}>{error || hint}</div>}
    </div>
  );
};
