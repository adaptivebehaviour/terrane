'use client';

import { Progress as ProgressPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { progressProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const SIZE = { sm: 'progress progress-sm', md: 'progress progress-md', lg: 'progress progress-lg' } as const;

/** Factory `'Progress'` — a measure-completion bar built on Radix Progress; `items[0]` is an optional label. */
export const Progress: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { value = 60, max = 100, showValue = false, valueLabel, size = 'md', tone = 'ink' } = propsOf(progressProps, record);
  const label = record.items[0] as string | undefined;
  const percent = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div data-id={record.id} className={styled ? SIZE[size] : undefined}>
      {(label || showValue) && (
        <div className={styled ? 'progress-head' : undefined}>
          <span>{label}</span>
          {showValue && <span className="tabular-nums lining-nums">{valueLabel ?? `${Math.round(percent)}%`}</span>}
        </div>
      )}
      <ProgressPrimitive.Root
        className={styled ? 'progress-track' : undefined}
        value={Math.max(0, Math.min(max, value))}
        max={max}
      >
        <ProgressPrimitive.Indicator
          className={styled ? 'progress-fill' : undefined}
          style={{ width: `${percent}%`, background: tone === 'accent' ? 'var(--accent-500)' : 'var(--ink-900)' }}
        />
      </ProgressPrimitive.Root>
    </div>
  );
};
