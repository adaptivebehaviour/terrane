'use client';

import { Checkbox as CheckboxPrimitive, Label as LabelPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Checkbox'` — wraps Radix Checkbox with optional default styles; `items[1]` is an optional description. */
export const Checkbox: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const description = record.items[1] as string | undefined;
  return (
    <LabelPrimitive.Root className={styled ? 'checkbox' : undefined}>
      <CheckboxPrimitive.Root data-id={record.id} defaultChecked className={styled ? 'checkbox-box' : undefined}>
        <CheckboxPrimitive.Indicator className={styled ? 'checkbox-mark' : undefined} />
      </CheckboxPrimitive.Root>
      <span className={styled ? 'checkbox-text' : undefined}>
        <span className={styled ? 'checkbox-label' : undefined}>{(record.items[0] as string) ?? 'Checkbox'}</span>
        {description && <span className={styled ? 'checkbox-description' : undefined}>{description}</span>}
      </span>
    </LabelPrimitive.Root>
  );
};
