'use client';

import { Toolbar as ToolbarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Toolbar'` — wraps Radix Toolbar with optional default styles. */
export const Toolbar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const button = styled ? 'button button-ghost button-md' : undefined;
  return (
    <ToolbarPrimitive.Root data-id={record.id} className={styled ? 'toolbar' : undefined}>
      <ToolbarPrimitive.Button className={button}>
        {(record.items[0] as string) ?? 'Bold'}
      </ToolbarPrimitive.Button>
      <ToolbarPrimitive.Button className={button}>
        {(record.items[1] as string) ?? 'Italic'}
      </ToolbarPrimitive.Button>
      <ToolbarPrimitive.Separator className={styled ? 'toolbar-separator' : undefined} />
      <ToolbarPrimitive.Link href="#" className={button}>
        {(record.items[2] as string) ?? 'Link'}
      </ToolbarPrimitive.Link>
    </ToolbarPrimitive.Root>
  );
};
