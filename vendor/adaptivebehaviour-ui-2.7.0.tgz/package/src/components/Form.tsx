'use client';

import { Form as FormPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Form'` — wraps Radix Form with optional default styles. */
export const Form: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <FormPrimitive.Root data-id={record.id} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', maxWidth: 320 }}>
      <FormPrimitive.Field name="email" className={styled ? 'field' : undefined}>
        <FormPrimitive.Label className={styled ? 'field-label' : undefined}>
          {(record.items[0] as string) ?? 'Email'}
        </FormPrimitive.Label>
        <div className={styled ? 'input' : undefined}>
          <FormPrimitive.Control asChild>
            <input type="email" required placeholder="you@example.com" />
          </FormPrimitive.Control>
        </div>
        <FormPrimitive.Message match="valueMissing" className="field-hint">
          Please enter your email
        </FormPrimitive.Message>
      </FormPrimitive.Field>
      <FormPrimitive.Submit className={styled ? 'button button-primary button-md' : undefined}>
        {(record.items[1] as string) ?? 'Submit'}
      </FormPrimitive.Submit>
    </FormPrimitive.Root>
  );
};
