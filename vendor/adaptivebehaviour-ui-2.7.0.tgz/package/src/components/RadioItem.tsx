'use client';

import type { ReactNode } from 'react';
import { RadioGroup as RadioGroupPrimitive, Label as LabelPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { radioItemProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/** One radio button with its label and optional description. Must be rendered inside a Radix RadioGroup. */
export function RadioOption({ value, label, description, disabled, styled }: {
  value: string;
  label: ReactNode;
  description?: ReactNode;
  disabled?: boolean;
  styled: boolean;
}) {
  return (
    <LabelPrimitive.Root className={styled ? (disabled ? 'radio-item is-disabled' : 'radio-item') : undefined}>
      <RadioGroupPrimitive.Item value={value} disabled={disabled} className={styled ? 'radio-item-box' : undefined}>
        <RadioGroupPrimitive.Indicator className={styled ? 'radio-item-mark' : undefined} />
      </RadioGroupPrimitive.Item>
      <span className={styled ? 'radio-item-text' : undefined}>
        <span className={styled ? 'radio-item-label' : undefined}>{label}</span>
        {description && <span className={styled ? 'radio-item-description' : undefined}>{description}</span>}
      </span>
    </LabelPrimitive.Root>
  );
}

/** Factory `'RadioItem'` — a single radio button, in a group of its own (use `RadioGroup` for several). */
export const RadioItem: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { value = 'option-1', description, disabled } = propsOf(radioItemProps, record);
  return (
    <RadioGroupPrimitive.Root data-id={record.id}>
      <RadioOption
        value={value}
        label={(record.items[0] as string) ?? 'Option'}
        description={description}
        disabled={disabled}
        styled={styled}
      />
    </RadioGroupPrimitive.Root>
  );
};
