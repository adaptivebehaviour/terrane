'use client';

import { Tooltip as TooltipPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Tooltip'` — wraps Radix Tooltip with optional default styles. */
export const Tooltip: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <TooltipPrimitive.Provider delayDuration={0}>
      <TooltipPrimitive.Root data-id={record.id}>
        <span className={styled ? 'tooltip' : undefined}>
          <TooltipPrimitive.Trigger className={styled ? 'button button-secondary button-md' : undefined}>
            {(record.items[0] as string) ?? 'Hover'}
          </TooltipPrimitive.Trigger>
        </span>
        <TooltipPrimitive.Portal>
          <TooltipPrimitive.Content className={styled ? 'tooltip-bubble' : undefined} side="top" sideOffset={8}>
            {(record.items[1] as string) ?? 'Tooltip content'}
          </TooltipPrimitive.Content>
        </TooltipPrimitive.Portal>
      </TooltipPrimitive.Root>
    </TooltipPrimitive.Provider>
  );
};
