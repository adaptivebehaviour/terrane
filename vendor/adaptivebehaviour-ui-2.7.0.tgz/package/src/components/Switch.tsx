'use client';

import { Switch as SwitchPrimitive, Label as LabelPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Switch'` — wraps Radix Switch with optional default styles. */
export const Switch: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <LabelPrimitive.Root className={styled ? 'switch' : undefined}>
      <SwitchPrimitive.Root data-id={record.id} className={styled ? 'switch-track' : undefined}>
        <SwitchPrimitive.Thumb className={styled ? 'switch-thumb' : undefined} />
      </SwitchPrimitive.Root>
      <span>{(record.items[0] as string) ?? 'Airplane mode'}</span>
    </LabelPrimitive.Root>
  );
};
