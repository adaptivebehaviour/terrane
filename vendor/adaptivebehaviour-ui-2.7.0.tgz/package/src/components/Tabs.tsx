'use client';

import { Tabs as TabsPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { tabsProps } from '../schemas';
import { useDefaultStyling } from '../styling';

// Class names are written out in full: Tailwind finds classes by scanning for literal strings.
const VARIANT = { underline: 'tabs tabs-underline', segmented: 'tabs tabs-segmented' } as const;

/** Factory `'Tabs'` — wraps Radix Tabs with optional default styles; `props.variant` is `underline` (default) or `segmented`. */
export const Tabs: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const { variant = 'underline' } = propsOf(tabsProps, record);
  return (
    <TabsPrimitive.Root data-id={record.id} defaultValue="tab1">
      <TabsPrimitive.List
        className={styled ? VARIANT[variant] : undefined}
        style={styled ? { marginBottom: 'var(--space-3)' } : undefined}
      >
        <TabsPrimitive.Trigger value="tab1" className={styled ? 'tabs-trigger' : undefined}>
          {(record.items[0] as string) ?? 'Account'}
        </TabsPrimitive.Trigger>
        <TabsPrimitive.Trigger value="tab2" className={styled ? 'tabs-trigger' : undefined}>
          {(record.items[1] as string) ?? 'Password'}
        </TabsPrimitive.Trigger>
      </TabsPrimitive.List>
      <TabsPrimitive.Content value="tab1" className="caption">
        {(record.items[2] as string) ?? 'Account tab content'}
      </TabsPrimitive.Content>
      <TabsPrimitive.Content value="tab2" className="caption">
        Password tab content
      </TabsPrimitive.Content>
    </TabsPrimitive.Root>
  );
};
