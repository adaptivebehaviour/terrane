'use client';

import { Select as SelectPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Select'` — wraps Radix Select with optional default styles. */
export const Select: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <div data-id={record.id} className={styled ? 'field' : undefined}>
      <div className={styled ? 'select' : undefined}>
        <SelectPrimitive.Root defaultValue="apple">
          <SelectPrimitive.Trigger className={styled ? 'select-trigger' : undefined}>
            <SelectPrimitive.Value placeholder={(record.items[0] as string) ?? 'Select…'} />
          </SelectPrimitive.Trigger>
          <SelectPrimitive.Portal>
            <SelectPrimitive.Content className={styled ? 'select-content' : undefined} position="popper" sideOffset={4}>
              <SelectPrimitive.Viewport>
                <SelectPrimitive.Item value="apple" className={styled ? 'select-item' : undefined}>
                  <SelectPrimitive.ItemText>Apple</SelectPrimitive.ItemText>
                </SelectPrimitive.Item>
                <SelectPrimitive.Item value="banana" className={styled ? 'select-item' : undefined}>
                  <SelectPrimitive.ItemText>Banana</SelectPrimitive.ItemText>
                </SelectPrimitive.Item>
                <SelectPrimitive.Item value="orange" className={styled ? 'select-item' : undefined}>
                  <SelectPrimitive.ItemText>Orange</SelectPrimitive.ItemText>
                </SelectPrimitive.Item>
              </SelectPrimitive.Viewport>
            </SelectPrimitive.Content>
          </SelectPrimitive.Portal>
        </SelectPrimitive.Root>
      </div>
    </div>
  );
};
