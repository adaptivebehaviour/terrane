'use client';

import { ScrollArea as ScrollAreaPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'ScrollArea'` — wraps Radix ScrollArea with optional default styles. */
export const ScrollArea: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ScrollAreaPrimitive.Root data-id={record.id} className={styled ? 'scroll-area' : undefined}>
      <ScrollAreaPrimitive.Viewport style={{ width: '100%', height: '100%', padding: 'var(--space-3)' }}>
        <p className="caption" style={{ margin: 0 }}>
          {(record.items[0] as string) ??
            'Scrollable content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.'}
        </p>
      </ScrollAreaPrimitive.Viewport>
      <ScrollAreaPrimitive.Scrollbar orientation="vertical" style={{ width: 8, padding: 2 }}>
        <ScrollAreaPrimitive.Thumb className="scroll-area-thumb" />
      </ScrollAreaPrimitive.Scrollbar>
    </ScrollAreaPrimitive.Root>
  );
};
