'use client';

import { Portal as PortalPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Portal'` — wraps Radix Portal with optional default styles. */
export const Portal: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <div data-id={record.id}>
      <span className="caption">
        Portal host (content rendered into document body)
      </span>
      <PortalPrimitive.Root>
        <div
          className={styled ? 'popover-content' : undefined}
          style={{
            position: 'fixed',
            bottom: 'var(--space-4)',
            left: 'var(--space-4)',
            zIndex: 50,
            pointerEvents: 'none',
          }}
        >
          {(record.items[0] as string) ?? 'Portaled content'}
        </div>
      </PortalPrimitive.Root>
    </div>
  );
};
