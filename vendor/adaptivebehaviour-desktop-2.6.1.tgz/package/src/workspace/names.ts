// eslint-disable-next-line no-control-regex
const ILLEGAL_CHARACTERS = /[<>:"/\\|?*\u0000-\u001f]/;
const RESERVED_DEVICE_NAMES = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\..*)?$/i;

/**
 * Checks a workspace name. Returns a message describing the problem, or `null` if the name is acceptable.
 * The name becomes a folder name, so it must be a legal folder name on Windows. Used by the main process (which
 * decides) and by the renderer (which only tells the user sooner).
 */
export function workspaceNameProblem(name: string): string | null {
  if (name.trim() === '') return 'Enter a name.';
  if (name !== name.trim()) return 'The name cannot start or end with a space.';
  if (ILLEGAL_CHARACTERS.test(name)) return 'The name cannot contain < > : " / \\ | ? * or control characters.';
  if (name.endsWith('.')) return 'The name cannot end with a full stop.';
  if (RESERVED_DEVICE_NAMES.test(name)) return 'That name is reserved by Windows.';
  return null;
}
