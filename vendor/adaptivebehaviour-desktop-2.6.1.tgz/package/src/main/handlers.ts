import type { Destination } from '@adaptivebehaviour/data/src/destinations/types';
import { DesktopError } from '../ipc/errors';
import type { Handlers } from '../ipc/main';
import type { NetworkServices } from '../net/services';
import { SidecarError } from '../sidecar/errors';
import type { SidecarManager } from '../sidecar/manager';
import type { WorkspaceManager } from './workspace';

export interface HandlerDependencies {
  app: { name: string; version: string; platform: string };
  net: NetworkServices;
  /** The optional Python backend; without one, `sidecar.status` reports `absent` and `sidecar.request` fails cleanly. */
  sidecar?: Pick<SidecarManager, 'status' | 'request'>;
  /** The application's one data destination; without one, the `data.*` channels fail cleanly. */
  data?: Destination;
  /** The application's workspaces; without one, the `workspace.*` channels fail cleanly. */
  workspaces?: Pick<WorkspaceManager, 'beginNew' | 'chooseLocation' | 'create' | 'open'>;
}

/**
 * The implementation of every channel in the IPC contract, in terms of the network services and the optional
 * sidecar. Input arrives already validated against the channel's schema (see `registerHandlers`).
 */
export function createHandlers({ app, net, sidecar, data, workspaces }: HandlerDependencies): Handlers {
  const destination = (): Destination => {
    if (!data) throw new DesktopError('unavailable', 'This application has no data destination');
    return data;
  };
  const workspaceManager = () => {
    if (!workspaces) throw new DesktopError('unavailable', 'This application has no workspaces');
    return workspaces;
  };

  return {
    'app.info': () => app,

    'net.call': (input) => net.call(input.service, input.operation, { path: input.path, query: input.query, body: input.body }),
    'credentials.status': (input) => net.credentialStatus(input.service),

    'data.createSession': (input) =>
      destination().createSession({ id: input.session_id ?? null, user_id: input.user_id ?? null, extra_props: input.extra_props ?? {} }),
    'data.writeEvents': async (input) => {
      await destination().writeEvents(input);
      return { accepted: input.events.length };
    },
    'data.writeError': async (input) => {
      try {
        await destination().writeErrorLog({
          source: 'frontend',
          message: input.message,
          stack: input.stack ?? null,
          severity: input.severity ?? 'error',
          session_id: input.session_id ?? null,
          user_id: input.user_id ?? null,
          context: input.context ?? {},
        });
        return { logged: true };
      } catch {
        // A failed error-log write must not surface as a second error to a renderer that is already mid-crash.
        return { logged: false };
      }
    },

    'workspace.beginNew': () => workspaceManager().beginNew(),
    'workspace.chooseLocation': () => workspaceManager().chooseLocation(),
    'workspace.create': (input) => workspaceManager().create(input.name),
    'workspace.open': () => workspaceManager().open(),

    'sidecar.status': () => (sidecar ? sidecar.status() : { state: 'absent' as const, restarts: 0 }),
    'sidecar.request': (input) => {
      if (!sidecar) throw new SidecarError('unavailable', 'This application has no Python backend');
      return sidecar.request(input.method, input.path, input.body);
    },
  };
}
