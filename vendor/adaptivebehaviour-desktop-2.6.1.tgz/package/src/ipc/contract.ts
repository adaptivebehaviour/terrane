import { z } from 'zod';

/**
 * The one definition of every message the renderer can send to the main process. It drives three things, so they
 * cannot drift apart: the Zod validation of each payload in the main process (`./main.ts`), the typed `window.ab`
 * object the preload exposes (`./client.ts`), and the renderer's TypeScript types.
 *
 * Rules for adding a channel: name it `group.method`; make the input a closed object (never a path, URL or script
 * the renderer chooses unless the main process re-validates it); keep results plain data.
 * Deliberately absent: any generic "fetch this URL" channel (external access is only through declared services).
 */
const channel = <I extends z.ZodType, O extends z.ZodType>(input: I, output: O) => ({ input, output });

const id = z.string().min(1).max(200);

export const credentialStatus = z.object({
  available: z.boolean(),
  /** Where the credential comes from; never its value. */
  source: z.enum(['environment', 'none']),
  /** The environment variable to set when it is missing. */
  variable: z.string().optional(),
});

export const sidecarStatus = z.object({
  /** `absent`: this application has no Python backend. */
  state: z.enum(['absent', 'stopped', 'starting', 'ready', 'restarting', 'failed']),
  restarts: z.number(),
  reason: z.string().optional(),
});

/** The data collection's calls to the application's data destination (see `@adaptivebehaviour/data`'s `DataSender`). The renderer never names a file or a folder: where the data goes is fixed by the main process. */
const dataEvent = z.object({
  id,
  index: z.number().int(),
  kind: z.string().nullish(),
  props: z.record(z.string(), z.unknown()).optional(),
  browser_timestamp: z.string().min(1).max(100),
});

/** The same cap as the backend's `POST /events/batch`. */
export const MAX_EVENTS_PER_BATCH = 500;

const netArgs = z.object({
  service: id,
  operation: id,
  path: z.record(z.string(), z.string()).optional(),
  query: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  body: z.unknown().optional(),
});

export const contract = {
  'app.info': channel(z.undefined(), z.object({ name: z.string(), version: z.string(), platform: z.string() })),

  /** Calls an operation of a declared external service (see `../net`). The renderer never supplies a URL or a credential. */
  'net.call': channel(netArgs, z.unknown()),
  'credentials.status': channel(z.object({ service: id }), credentialStatus),

  /** Registers a session with the data destination; resolves the ids it stored (the caller's own unless the destination assigns its own). */
  'data.createSession': channel(
    z.object({ user_id: id.nullish(), session_id: id.nullish(), extra_props: z.record(z.string(), z.unknown()).nullish() }),
    z.object({ user_id: z.string(), session_id: z.string() }),
  ),
  /** Stores a batch of events, idempotently on each event id. Resolving means the destination has them. */
  'data.writeEvents': channel(
    z.object({ session_id: id, user_id: id, events: z.array(dataEvent).max(MAX_EVENTS_PER_BATCH) }),
    z.object({ accepted: z.number() }),
  ),
  /** Stores one error report in the data destination's error log; `logged: false` instead of an error when it could not. */
  'data.writeError': channel(
    z.object({
      message: z.string().max(100_000),
      stack: z.string().max(100_000).nullish(),
      severity: z.string().max(100).nullish(),
      session_id: id.nullish(),
      user_id: id.nullish(),
      context: z.record(z.string(), z.unknown()).nullish(),
    }),
    z.object({ logged: z.boolean() }),
  ),

  /** Starts the "new workspace" dialog: returns the workspace location path it starts with (the last used one, or the system's default). */
  'workspace.beginNew': channel(z.undefined(), z.object({ location: z.string() })),
  /** Shows the folder picker for the new workspace's location. `null` if the user cancels. The main process remembers the choice; the renderer never sends a folder back. */
  'workspace.chooseLocation': channel(z.undefined(), z.object({ location: z.string() }).nullable()),
  /** Creates `<location>/<name>`, makes that location the default for workspaces, and opens the new workspace. Fails with a coded error (`invalid_name`, `exists`, `create_failed`). */
  'workspace.create': channel(z.strictObject({ name: z.string().max(200) }), z.object({ name: z.string(), path: z.string() })),
  /** Shows the folder picker at the workspace location path and opens the chosen folder as the workspace. `null` if the user cancels. */
  'workspace.open': channel(z.undefined(), z.object({ name: z.string(), path: z.string() }).nullable()),

  /** The state of the optional Python backend. The renderer never learns its port or token. */
  'sidecar.status': channel(z.undefined(), sidecarStatus),
  /** Calls the Python backend through the main process, which holds the port and token. */
  'sidecar.request': channel(
    z.object({ method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']), path: z.string().min(1).max(2000), body: z.unknown().optional() }),
    z.unknown(),
  ),
} as const;

export type Contract = typeof contract;
export type ChannelName = keyof Contract & string;
export type ChannelInput<N extends ChannelName> = z.input<Contract[N]['input']>;
export type ChannelOutput<N extends ChannelName> = z.output<Contract[N]['output']>;

export const CHANNEL_NAMES = Object.keys(contract) as ChannelName[];

type Args<N extends ChannelName> = undefined extends ChannelInput<N> ? [input?: ChannelInput<N>] : [input: ChannelInput<N>];
type GroupOf<N extends string> = N extends `${infer G}.${string}` ? G : never;

/** The object the preload exposes as `window.ab`: `ab.records.get({ collection, id })` calls channel `records.get`. */
export type AbApi = {
  [G in GroupOf<ChannelName>]: {
    [N in ChannelName as N extends `${G}.${infer M}` ? M : never]: (...args: Args<N>) => Promise<ChannelOutput<N>>;
  };
};

/** Every response crosses the process boundary as a plain result, because Electron does not carry `Error` subclasses across. */
export type IpcResult<T> = { ok: true; value: T } | { ok: false; error: { code: string; message: string } };
