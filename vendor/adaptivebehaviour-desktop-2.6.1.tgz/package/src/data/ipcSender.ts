import type { DataSender } from '@adaptivebehaviour/data/src/sender';
import type { AbApi } from '../ipc/contract';

/**
 * The renderer's `DataSender` for a desktop application: every call goes to the main process over the IPC contract, which
 * hands it to the application's data destination (`createHandlers`' `data`). Install it once at startup, before the first
 * session is created: `setDataSender(createIpcSender(ab))`.
 *
 * There is no unload route (`sendEventsOnUnload`): events not yet acknowledged stay in the IndexedDB buffer and go out on
 * the next launch, which is safe because every destination stores an event id once.
 */
export function createIpcSender(api: Pick<AbApi, 'data'>): DataSender {
  return {
    createSession: (request) => api.data.createSession(request),

    async sendEvents(batch) {
      try {
        await api.data.writeEvents(batch);
        return true;
      } catch {
        // Not acknowledged: the buffer keeps the events and retries on the next tick.
        return false;
      }
    },

    async reportError(report) {
      try {
        await api.data.writeError(report);
      } catch {
        // Best-effort: a failed error report must not itself throw.
      }
    },
  };
}
