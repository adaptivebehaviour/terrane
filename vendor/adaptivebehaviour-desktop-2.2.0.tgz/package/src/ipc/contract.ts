import { z } from 'zod';

/**
 * The one definition of every message the renderer can send to the main process. It drives three things, so they
 * cannot drift apart: the Zod validation of each payload in the main process (`./main.ts`), the typed `window.ab`
 * object the preload exposes (`./client.ts`), and the renderer's TypeScript types.
 *
 * Rules for adding a channel: name it `group.method`; make the input a closed object (never a path, URL or script
 * the renderer chooses unless the main process re-validates it); keep results plain data.
 * Deliberately absent: any generic "fetch this URL" channel (external access is only through declared services).
 */
const channel = <I extends z.ZodType, O extends z.ZodType>(input: I, output: O) => ({ input, output });

const id = z.string().min(1).max(200);

export const credentialStatus = z.object({
  available: z.boolean(),
  /** Where the credential comes from; never its value. */
  source: z.enum(['environment', 'none']),
  /** The environment variable to set when it is missing. */
  variable: z.string().optional(),
});

export const sidecarStatus = z.object({
  /** `absent`: this application has no Python backend. */
  state: z.enum(['absent', 'stopped', 'starting', 'ready', 'restarting', 'failed']),
  restarts: z.number(),
  reason: z.string().optional(),
});

const netArgs = z.object({
  service: id,
  operation: id,
  path: z.record(z.string(), z.string()).optional(),
  query: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  body: z.unknown().optional(),
});

export const contract = {
  'app.info': channel(z.undefined(), z.object({ name: z.string(), version: z.string(), platform: z.string() })),

  /** Calls an operation of a declared external service (see `../net`). The renderer never supplies a URL or a credential. */
  'net.call': channel(netArgs, z.unknown()),
  'credentials.status': channel(z.object({ service: id }), credentialStatus),

  /** The state of the optional Python backend. The renderer never learns its port or token. */
  'sidecar.status': channel(z.undefined(), sidecarStatus),
  /** Calls the Python backend through the main process, which holds the port and token. */
  'sidecar.request': channel(
    z.object({ method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']), path: z.string().min(1).max(2000), body: z.unknown().optional() }),
    z.unknown(),
  ),
} as const;

export type Contract = typeof contract;
export type ChannelName = keyof Contract & string;
export type ChannelInput<N extends ChannelName> = z.input<Contract[N]['input']>;
export type ChannelOutput<N extends ChannelName> = z.output<Contract[N]['output']>;

export const CHANNEL_NAMES = Object.keys(contract) as ChannelName[];

type Args<N extends ChannelName> = undefined extends ChannelInput<N> ? [input?: ChannelInput<N>] : [input: ChannelInput<N>];
type GroupOf<N extends string> = N extends `${infer G}.${string}` ? G : never;

/** The object the preload exposes as `window.ab`: `ab.records.get({ collection, id })` calls channel `records.get`. */
export type AbApi = {
  [G in GroupOf<ChannelName>]: {
    [N in ChannelName as N extends `${G}.${infer M}` ? M : never]: (...args: Args<N>) => Promise<ChannelOutput<N>>;
  };
};

/** Every response crosses the process boundary as a plain result, because Electron does not carry `Error` subclasses across. */
export type IpcResult<T> = { ok: true; value: T } | { ok: false; error: { code: string; message: string } };
