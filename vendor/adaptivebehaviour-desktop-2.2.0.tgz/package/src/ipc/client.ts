import { CHANNEL_NAMES, type AbApi, type ChannelInput, type ChannelName, type ChannelOutput, type IpcResult } from './contract';
import { DesktopError } from './errors';

/** What the preload gives the client: Electron's `ipcRenderer.invoke`. */
export type Invoke = (channel: string, payload?: unknown) => Promise<unknown>;

/**
 * The shape the preload exposes across the context bridge: the same groups and methods as `AbApi`, but each method
 * resolves with a plain `IpcResult` instead of throwing. The bridge copies errors as plain `Error`s and drops custom
 * fields such as `code`, so errors travel as data and are turned back into `DesktopError`s inside the renderer.
 */
type RawArgs<N extends ChannelName> = undefined extends ChannelInput<N> ? [input?: ChannelInput<N>] : [input: ChannelInput<N>];
type GroupOf<N extends string> = N extends `${infer G}.${string}` ? G : never;
export type AbBridge = {
  [G in GroupOf<ChannelName>]: {
    [N in ChannelName as N extends `${G}.${infer M}` ? M : never]: (...args: RawArgs<N>) => Promise<IpcResult<ChannelOutput<N>>>;
  };
};

/**
 * Preload side: one named function per channel in the contract, nothing else. There is no function that accepts a
 * channel name, so the renderer cannot reach a channel that is not in the contract.
 */
export function buildBridge(invoke: Invoke): AbBridge {
  const bridge: Record<string, Record<string, (input?: unknown) => Promise<unknown>>> = {};
  for (const name of CHANNEL_NAMES) {
    const dot = name.indexOf('.');
    const group = name.slice(0, dot);
    bridge[group] ??= {};
    bridge[group][name.slice(dot + 1)] = (input?: unknown) => invoke(name, input);
  }
  return bridge as unknown as AbBridge;
}

/** Renderer side: wraps the bridge so a failed result throws a `DesktopError` carrying the main process's error code. */
export function unwrapBridge(bridge: AbBridge): AbApi {
  const api: Record<string, Record<string, (input?: unknown) => Promise<unknown>>> = {};
  for (const [group, methods] of Object.entries(bridge as unknown as Record<string, Record<string, (input?: unknown) => Promise<IpcResult<unknown>>>>)) {
    api[group] = {};
    for (const [method, call] of Object.entries(methods)) {
      api[group][method] = async (input?: unknown) => {
        const result = await call(input);
        if (result.ok) return result.value;
        throw new DesktopError(result.error.code, result.error.message);
      };
    }
  }
  return api as unknown as AbApi;
}

/** Both halves joined, for tests and for code that has `invoke` directly. */
export function buildApi(invoke: Invoke): AbApi {
  return unwrapBridge(buildBridge(invoke));
}
