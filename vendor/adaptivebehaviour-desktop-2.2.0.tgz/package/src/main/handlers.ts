import type { Handlers } from '../ipc/main';
import type { NetworkServices } from '../net/services';
import { SidecarError } from '../sidecar/errors';
import type { SidecarManager } from '../sidecar/manager';

export interface HandlerDependencies {
  app: { name: string; version: string; platform: string };
  net: NetworkServices;
  /** The optional Python backend; without one, `sidecar.status` reports `absent` and `sidecar.request` fails cleanly. */
  sidecar?: Pick<SidecarManager, 'status' | 'request'>;
}

/**
 * The implementation of every channel in the IPC contract, in terms of the network services and the optional
 * sidecar. Input arrives already validated against the channel's schema (see `registerHandlers`).
 */
export function createHandlers({ app, net, sidecar }: HandlerDependencies): Handlers {
  return {
    'app.info': () => app,

    'net.call': (input) => net.call(input.service, input.operation, { path: input.path, query: input.query, body: input.body }),
    'credentials.status': (input) => net.credentialStatus(input.service),

    'sidecar.status': () => (sidecar ? sidecar.status() : { state: 'absent' as const, restarts: 0 }),
    'sidecar.request': (input) => {
      if (!sidecar) throw new SidecarError('unavailable', 'This application has no Python backend');
      return sidecar.request(input.method, input.path, input.body);
    },
  };
}
