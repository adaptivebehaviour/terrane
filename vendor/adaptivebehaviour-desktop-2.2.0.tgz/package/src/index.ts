// This entry point is deliberately empty of Node and browser code so importing the package by name pulls in neither.
export {};
