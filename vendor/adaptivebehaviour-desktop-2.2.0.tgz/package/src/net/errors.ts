/** The reasons a call to an external service can fail, so a UI can tell "no connection" from "bad key". */
export type NetworkErrorCode =
  | 'unknown_service'
  | 'unknown_operation'
  | 'invalid_request'
  | 'forbidden_target'
  | 'missing_credential'
  | 'offline'
  | 'timeout'
  | 'unauthorised'
  | 'rate_limited'
  | 'service_error'
  | 'invalid_response';

/**
 * Raised by `NetworkServices`. Messages never contain a credential, a request header or a response body, because they
 * cross to the renderer and may be logged.
 */
export class NetworkError extends Error {
  readonly code: NetworkErrorCode;

  constructor(code: NetworkErrorCode, message: string) {
    super(message);
    this.name = 'NetworkError';
    this.code = code;
  }
}
