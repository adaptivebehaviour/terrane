import { ZodError } from 'zod';
import { resolvesToPrivateAddress } from './address';
import type { CredentialProvider, CredentialStatus } from './credentials';
import { redact } from './credentials';
import type { CallArgs, ServiceDeclaration, ServiceOperation } from './declaration';
import { NetworkError } from './errors';

export interface NetworkServicesOptions {
  services: ServiceDeclaration[];
  credentials: CredentialProvider;
  /** Replaceable for tests; defaults to the global `fetch`. */
  fetch?: typeof fetch;
  defaultTimeoutMs?: number;
  maxResponseBytes?: number;
  /** Receives redacted one-line diagnostics. Never given a header, body or credential. */
  log?: (line: string) => void;
}

interface Prepared {
  service: ServiceDeclaration;
  operation: ServiceOperation;
  url: URL;
  init: RequestInit;
  secret: string | undefined;
  timeoutMs: number;
}

const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_BYTES = 10 * 1024 * 1024;

function checkDeclaration(service: ServiceDeclaration): void {
  let url: URL;
  try {
    url = new URL(service.origin);
  } catch {
    throw new Error(`Service ${service.id}: origin is not a URL: ${service.origin}`);
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error(`Service ${service.id}: origin must be http or https`);
  if (url.origin !== service.origin) throw new Error(`Service ${service.id}: origin must be scheme + host (+ port) only, i.e. ${url.origin}`);
  if (url.protocol === 'http:' && !service.allowPrivateNetwork) throw new Error(`Service ${service.id}: plain http is allowed only with allowPrivateNetwork`);
  for (const [name, operation] of Object.entries(service.operations)) {
    if (!operation.path.startsWith('/')) throw new Error(`Service ${service.id}, operation ${name}: path must start with /`);
  }
}

/**
 * The only way the application reaches an external network. Each call names a declared service and operation; the
 * caller never supplies a URL, header or credential. Targets outside the declared origin are impossible by
 * construction, redirects are never followed, private-network targets are refused unless declared, and credentials are
 * attached here and nowhere else.
 */
export class NetworkServices {
  private readonly services = new Map<string, ServiceDeclaration>();
  private readonly options: NetworkServicesOptions;

  constructor(options: NetworkServicesOptions) {
    this.options = options;
    for (const service of options.services) {
      checkDeclaration(service);
      if (this.services.has(service.id)) throw new Error(`Duplicate service id: ${service.id}`);
      this.services.set(service.id, service);
    }
  }

  /** Every declared service (the application's network allow-list). */
  declarations(): ServiceDeclaration[] {
    return [...this.services.values()];
  }

  credentialStatus(serviceId: string): CredentialStatus {
    return this.options.credentials.status(this.service(serviceId));
  }

  private service(id: string): ServiceDeclaration {
    const service = this.services.get(id);
    if (!service) throw new NetworkError('unknown_service', `No such service: ${id}`);
    return service;
  }

  private async prepare(serviceId: string, operationId: string, args: CallArgs): Promise<Prepared> {
    const service = this.service(serviceId);
    const operation = service.operations[operationId];
    if (!operation) throw new NetworkError('unknown_operation', `Service ${serviceId} has no operation ${operationId}`);

    const given = args.path ?? {};
    const wanted = [...operation.path.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map((match) => match[1]);
    for (const name of Object.keys(given)) {
      if (!wanted.includes(name)) throw new NetworkError('invalid_request', `Unexpected path parameter: ${name}`);
    }
    const path = operation.path.replace(/\{([A-Za-z0-9_]+)\}/g, (_, name: string) => {
      const value = given[name];
      if (value === undefined || value === '') throw new NetworkError('invalid_request', `Missing path parameter: ${name}`);
      return encodeURIComponent(value);
    });

    const url = new URL(path, service.origin);
    if (url.origin !== service.origin) throw new NetworkError('forbidden_target', 'Request target is outside the declared origin');
    for (const [key, value] of Object.entries(args.query ?? {})) url.searchParams.set(key, String(value));

    if (!service.allowPrivateNetwork && (await resolvesToPrivateAddress(url.hostname))) {
      throw new NetworkError('forbidden_target', `Service ${serviceId} resolves to a private or loopback address`);
    }

    const headers: Record<string, string> = { accept: 'application/json, text/plain;q=0.9', ...service.headers };
    let secret: string | undefined;
    if (service.credential) {
      secret = this.options.credentials.get(service);
      if (!secret) {
        throw new NetworkError('missing_credential', `No credential for ${serviceId}: set the ${service.credential.env} environment variable and restart the app`);
      }
      const header = (service.credential.header ?? 'Authorization').toLowerCase();
      const prefix = service.credential.prefix ?? (header === 'authorization' ? 'Bearer ' : '');
      headers[header] = `${prefix}${secret}`;
    }

    const init: RequestInit = { method: operation.method, headers, redirect: 'manual' };
    if (args.body !== undefined) {
      if (operation.method === 'GET') throw new NetworkError('invalid_request', 'A GET operation cannot carry a body');
      let body: unknown = args.body;
      if (operation.request) {
        try {
          body = operation.request.parse(args.body);
        } catch (error) {
          if (error instanceof ZodError) throw new NetworkError('invalid_request', `Invalid request body: ${error.issues.map((i) => i.path.join('.') || '(root)').join(', ')}`);
          throw error;
        }
      }
      headers['content-type'] = 'application/json';
      init.body = JSON.stringify(body);
    } else if (operation.request) {
      throw new NetworkError('invalid_request', 'This operation requires a body');
    }

    return { service, operation, url, init, secret, timeoutMs: operation.timeoutMs ?? this.options.defaultTimeoutMs ?? DEFAULT_TIMEOUT_MS };
  }

  private async send(prepared: Prepared, signal: AbortSignal): Promise<Response> {
    const doFetch = this.options.fetch ?? fetch;
    let response: Response;
    try {
      response = await doFetch(prepared.url, { ...prepared.init, signal });
    } catch (error) {
      const name = (error as Error).name;
      if (name === 'AbortError' || name === 'TimeoutError') throw new NetworkError('timeout', `Service ${prepared.service.id} did not respond in time`);
      this.log(prepared, `request failed: ${redact(String((error as Error).message), prepared.secret)}`);
      throw new NetworkError('offline', `Could not reach ${prepared.service.id}`);
    }
    if (response.status >= 300 && response.status < 400) {
      throw new NetworkError('service_error', `Service ${prepared.service.id} answered with a redirect, which is not followed`);
    }
    if (!response.ok) {
      await response.body?.cancel().catch(() => undefined);
      const code = response.status === 401 || response.status === 403 ? 'unauthorised'
        : response.status === 429 ? 'rate_limited'
        : response.status === 408 || response.status === 504 ? 'timeout'
        : 'service_error';
      throw new NetworkError(code, `Service ${prepared.service.id} responded ${response.status}`);
    }
    return response;
  }

  private log(prepared: Prepared, line: string): void {
    this.options.log?.(redact(`[net] ${prepared.service.id} ${prepared.url.pathname}: ${line}`, prepared.secret));
  }

  /** Calls a declared operation and returns its parsed (and, if declared, validated) response. */
  async call(serviceId: string, operationId: string, args: CallArgs = {}): Promise<unknown> {
    const prepared = await this.prepare(serviceId, operationId, args);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new DOMException('timeout', 'TimeoutError')), prepared.timeoutMs);
    try {
      const response = await this.send(prepared, controller.signal);
      const bytes = await this.readLimited(response, prepared);
      const text = new TextDecoder().decode(bytes);
      let value: unknown = text;
      if ((response.headers.get('content-type') ?? '').includes('json')) {
        try {
          value = text === '' ? null : JSON.parse(text);
        } catch {
          throw new NetworkError('invalid_response', `Service ${serviceId} sent invalid JSON`);
        }
      }
      if (prepared.operation.response) {
        const parsed = prepared.operation.response.safeParse(value);
        if (!parsed.success) {
          throw new NetworkError('invalid_response', `Response from ${serviceId} did not match the declared shape (${parsed.error.issues.map((i) => i.path.join('.') || '(root)').join(', ')})`);
        }
        value = parsed.data;
      }
      return value;
    } catch (error) {
      if (controller.signal.aborted && !(error instanceof NetworkError)) throw new NetworkError('timeout', `Service ${serviceId} did not respond in time`);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Calls a declared operation and yields the response body as text chunks as they arrive (for streaming APIs).
   * The timeout covers waiting for the response to start; cancel an in-progress stream with `signal`.
   */
  async *stream(serviceId: string, operationId: string, args: CallArgs = {}, signal?: AbortSignal): AsyncGenerator<string> {
    const prepared = await this.prepare(serviceId, operationId, args);
    const controller = new AbortController();
    const onAbort = () => controller.abort(signal?.reason);
    signal?.addEventListener('abort', onAbort, { once: true });
    const timer = setTimeout(() => controller.abort(new DOMException('timeout', 'TimeoutError')), prepared.timeoutMs);
    try {
      const response = await this.send(prepared, controller.signal);
      clearTimeout(timer);
      if (!response.body) return;
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let total = 0;
      const max = this.options.maxResponseBytes ?? DEFAULT_MAX_BYTES * 10;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > max) {
          await reader.cancel();
          throw new NetworkError('invalid_response', `Stream from ${serviceId} exceeded the size limit`);
        }
        const text = decoder.decode(value, { stream: true });
        if (text) yield text;
      }
      const rest = decoder.decode();
      if (rest) yield rest;
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      controller.abort();
    }
  }

  private async readLimited(response: Response, prepared: Prepared): Promise<Uint8Array> {
    const max = this.options.maxResponseBytes ?? DEFAULT_MAX_BYTES;
    const declared = Number(response.headers.get('content-length'));
    if (Number.isFinite(declared) && declared > max) {
      await response.body?.cancel().catch(() => undefined);
      throw new NetworkError('invalid_response', `Response from ${prepared.service.id} is larger than ${max} bytes`);
    }
    if (!response.body) return new Uint8Array();
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > max) {
        await reader.cancel();
        throw new NetworkError('invalid_response', `Response from ${prepared.service.id} is larger than ${max} bytes`);
      }
      chunks.push(value);
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return bytes;
  }
}
