'use client';

import { createContext, createElement, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AbApi, ChannelOutput } from '../ipc/contract';
import { DesktopError } from '../ipc/errors';

export type BackendStatus = ChannelOutput<'sidecar.status'>;

/** A user-facing sentence for whatever an `ab.*` call threw. */
export function describeError(error: unknown): string {
  return error instanceof DesktopError ? `${error.message} (${error.code})` : error instanceof Error ? error.message : String(error);
}

export interface Desktop {
  api: AbApi;
  /** The optional Python backend (`absent` when the application has none). */
  backend: BackendStatus;
}

const DesktopContext = createContext<Desktop | undefined>(undefined);

const BACKEND_POLL_MS = 1000;

/**
 * Gives the components below it the state of the optional Python backend and the typed `ab` API. Pass the API the
 * preload exposed (`unwrapBridge(window.abBridge)`).
 */
export function DesktopProvider({ api, children }: { api: AbApi; children?: ReactNode }) {
  const [backend, setBackend] = useState<BackendStatus>({ state: 'absent', restarts: 0 });
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    const poll = () => api.sidecar.status().then((status) => mounted.current && setBackend(status), () => undefined);
    void poll();
    const timer = setInterval(poll, BACKEND_POLL_MS);
    return () => {
      mounted.current = false;
      clearInterval(timer);
    };
  }, [api]);

  const value = useMemo<Desktop>(() => ({ api, backend }), [api, backend]);
  return createElement(DesktopContext.Provider, { value }, children);
}

/** The desktop shell's state; must be used under a {@link DesktopProvider}. */
export function useDesktop(): Desktop {
  const desktop = useContext(DesktopContext);
  if (!desktop) throw new Error('useDesktop must be used inside a <DesktopProvider>');
  return desktop;
}
