export type SidecarErrorCode = 'unavailable' | 'timeout' | 'service_error' | 'invalid_request' | 'failed_to_start';

/** Raised by `SidecarManager`. Messages are safe to show a user and never contain the token. */
export class SidecarError extends Error {
  readonly code: SidecarErrorCode;

  constructor(code: SidecarErrorCode, message: string) {
    super(message);
    this.name = 'SidecarError';
    this.code = code;
  }
}
