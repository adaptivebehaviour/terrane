import { defineCollection } from '@adaptivebehaviour/manifesto/src/registry';
import type { RecordComponent, RegistryTarget } from '@adaptivebehaviour/manifesto/src/create';
import { defineFactory, validateRecordsJson } from '@adaptivebehaviour/manifesto/src/schema';
import {
  avatarProps, badgeProps, buttonProps, cardProps, directionProps, iconButtonProps, iconProps, inputProps,
  likertScaleProps, progressProps, radioItemProps, scoreBarProps, tabsProps, tagProps, toastProps, uiProps, wordmarkProps,
} from './schemas';
import { Accordion } from './components/Accordion';
import { AlertDialog } from './components/AlertDialog';
import { AspectRatio } from './components/AspectRatio';
import { Avatar } from './components/Avatar';
import { Badge } from './components/Badge';
import { Button } from './components/Button';
import { Card } from './components/Card';
import { Checkbox } from './components/Checkbox';
import { Collapsible } from './components/Collapsible';
import { ContextMenu } from './components/ContextMenu';
import { Dialog } from './components/Dialog';
import { DropdownMenu } from './components/DropdownMenu';
import { Form } from './components/Form';
import { HoverCard } from './components/HoverCard';
import { Icon } from './components/Icon';
import { IconButton } from './components/IconButton';
import { Input } from './components/Input';
import { Label } from './components/Label';
import { LikertScale } from './components/LikertScale';
import { Menubar } from './components/Menubar';
import { NavigationMenu } from './components/NavigationMenu';
import { Popover } from './components/Popover';
import { Progress } from './components/Progress';
import { RadioGroup } from './components/RadioGroup';
import { RadioItem } from './components/RadioItem';
import { ScoreBar } from './components/ScoreBar';
import { ScrollArea } from './components/ScrollArea';
import { Select } from './components/Select';
import { Separator } from './components/Separator';
import { Slider } from './components/Slider';
import { Switch } from './components/Switch';
import { Tabs } from './components/Tabs';
import { Tag } from './components/Tag';
import { Toast } from './components/Toast';
import { Toggle } from './components/Toggle';
import { ToggleGroup } from './components/ToggleGroup';
import { Toolbar } from './components/Toolbar';
import { Tooltip } from './components/Tooltip';
import { AccessibleIcon } from './components/AccessibleIcon';
import { Direction } from './components/Direction';
import { Portal } from './components/Portal';
import { Slot } from './components/Slot';
import { VisuallyHidden } from './components/VisuallyHidden';
import { Wordmark } from './components/Wordmark';
import { OneTimePasswordField } from './components/OneTimePasswordField';
import { PasswordToggleField } from './components/PasswordToggleField';
import records from './records.json' with { type: 'json' };

/**
 * Registers this collection's records, then its Radix wrapper components,
 * into the {@link RegistryTarget} it's handed — see
 * `manifesto/index.ts`'s own doc comment for the reference shape this
 * mirrors. Every factory here is purely declarative (no custom
 * `instanceRegistry` entry), exactly like `manifesto`'s own `'root'`/`'text'`
 * factories, so the generic `Factory` default already covers them.
 */
export function register(target: RegistryTarget): void {
  // Each factory is defined with its props schema; registering records the schema, which is checked
  // against the factory's records as they are built and against records.json below.
  const components: Record<string, RecordComponent> = {
    Accordion,
    AlertDialog,
    AspectRatio,
    Avatar,
    Badge,
    Button,
    Card,
    Checkbox,
    Collapsible,
    ContextMenu,
    Dialog,
    DropdownMenu,
    Form,
    HoverCard,
    Icon,
    IconButton,
    Input,
    Label,
    LikertScale,
    Menubar,
    NavigationMenu,
    Popover,
    Progress,
    RadioGroup,
    RadioItem,
    ScoreBar,
    ScrollArea,
    Select,
    Separator,
    Slider,
    Switch,
    Tabs,
    Tag,
    Toast,
    Toggle,
    ToggleGroup,
    Toolbar,
    Tooltip,
    AccessibleIcon,
    Direction,
    Portal,
    Slot,
    VisuallyHidden,
    Wordmark,
    OneTimePasswordField,
    PasswordToggleField,
  };
  const propsByType: Record<string, typeof uiProps> = {
    Avatar: avatarProps,
    Badge: badgeProps,
    Button: buttonProps,
    Card: cardProps,
    Direction: directionProps,
    Icon: iconProps,
    IconButton: iconButtonProps,
    Input: inputProps,
    LikertScale: likertScaleProps,
    Progress: progressProps,
    RadioItem: radioItemProps,
    ScoreBar: scoreBarProps,
    Tabs: tabsProps,
    Tag: tagProps,
    Toast: toastProps,
    Wordmark: wordmarkProps,
  };
  for (const [type, component] of Object.entries(components)) {
    defineFactory({ type, props: propsByType[type] ?? uiProps, component }).register(target);
  }
  for (const record of validateRecordsJson('ui/records.json', records)) {
    target.recordRegistry.set(record.id as string, record);
  }
}

/** This collection's declaration, for composing into a registry (see registry.ts's createRegistry()). */
export const ui = defineCollection({ id: 'ui', register });
