import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';

/**
 * Returns true when `record.props.styling` is absent or empty — the signal
 * that default classes from `styles.css` should be applied.
 */
export function useDefaultStyling(record: RootRecord): boolean {
  const styling = record.props.styling;
  if (styling == null) return true;
  if (typeof styling === 'object' && !Array.isArray(styling) && Object.keys(styling as object).length === 0) {
    return true;
  }
  return false;
}

/**
 * Resolve a className for a part. When default styling applies, returns
 * `defaultClass`. Otherwise prefers an explicit string `styling`, then a
 * named key on a styling object, then falls back to `defaultClass`.
 */
export function classNameFor(
  record: RootRecord,
  defaultClass: string,
  key?: string
): string {
  if (useDefaultStyling(record)) return defaultClass;

  const styling = record.props.styling;
  if (typeof styling === 'string') return styling;
  if (styling && typeof styling === 'object' && key) {
    const value = (styling as Record<string, unknown>)[key];
    if (typeof value === 'string') return value;
  }
  return defaultClass;
}
