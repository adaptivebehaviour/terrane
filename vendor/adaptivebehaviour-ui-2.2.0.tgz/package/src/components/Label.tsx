'use client';

import { Label as LabelPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Label'` — wraps Radix Label with optional default styles. */
export const Label: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <LabelPrimitive.Root className={styled ? 'label' : undefined} data-id={record.id}>
      {(record.items[0] as string) ?? 'Label'}
    </LabelPrimitive.Root>
  );
};
