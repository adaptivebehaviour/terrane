'use client';

import { Checkbox as CheckboxPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Checkbox'` — wraps Radix Checkbox with optional default styles. */
export const Checkbox: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const id = `checkbox-${record.id}`;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)' }}>
      <CheckboxPrimitive.Root
        id={id}
        data-id={record.id}
        defaultChecked
        style={styled ? {
          width: 20,
          height: 20,
          borderRadius: 'var(--radius-compact)',
          border: '1px solid var(--color-border)',
          backgroundColor: 'var(--color-app-background)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
        } : undefined}
      >
        <CheckboxPrimitive.Indicator style={{ color: 'var(--color-text)', fontSize: 12 }}>✓</CheckboxPrimitive.Indicator>
      </CheckboxPrimitive.Root>
      <label htmlFor={id} className={styled ? 'label' : undefined} style={{ marginBottom: 0 }}>
        {(record.items[0] as string) ?? 'Checkbox'}
      </label>
    </div>
  );
};
