'use client';

import { AspectRatio as AspectRatioPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';

/** Factory `'AspectRatio'` — wraps Radix AspectRatio. */
export const AspectRatio: RecordComponent = ({ record }) => (
  <AspectRatioPrimitive.Root ratio={16 / 9} data-id={record.id} style={{ background: 'var(--color-surface)', borderRadius: 'var(--radius-control)' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--color-text-muted)', fontSize: 'var(--text-label)' }}>
      {(record.items[0] as string) ?? '16:9'}
    </div>
  </AspectRatioPrimitive.Root>
);
