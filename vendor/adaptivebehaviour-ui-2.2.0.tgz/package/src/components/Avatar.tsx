'use client';

import { Avatar as AvatarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { avatarProps } from '../schemas';
import { useDefaultStyling } from '../styling';

/** Factory `'Avatar'` — wraps Radix Avatar with optional default styles. */
export const Avatar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <AvatarPrimitive.Root
      data-id={record.id}
      style={styled ? {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: 40,
        height: 40,
        borderRadius: 'var(--radius-pill)',
        backgroundColor: 'var(--color-surface-active)',
        overflow: 'hidden',
        verticalAlign: 'middle',
      } : undefined}
    >
      <AvatarPrimitive.Image
        src={propsOf(avatarProps, record).src}
        alt={propsOf(avatarProps, record).alt ?? 'Avatar'}
        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
      />
      <AvatarPrimitive.Fallback
        delayMs={600}
        style={styled ? {
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 'var(--text-label)',
          fontWeight: 500,
          color: 'var(--color-text-muted)',
        } : undefined}
      >
        {(record.items[0] as string) ?? 'AB'}
      </AvatarPrimitive.Fallback>
    </AvatarPrimitive.Root>
  );
};
