'use client';

import { Switch as SwitchPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Switch'` — wraps Radix Switch with optional default styles. */
export const Switch: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const id = `switch-${record.id}`;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)' }}>
      <SwitchPrimitive.Root
        id={id}
        data-id={record.id}
        style={styled ? {
          width: 42,
          height: 24,
          backgroundColor: 'var(--color-surface-active)',
          borderRadius: 'var(--radius-pill)',
          position: 'relative',
          border: 'none',
          cursor: 'pointer',
        } : undefined}
      >
        <SwitchPrimitive.Thumb
          style={styled ? {
            display: 'block',
            width: 18,
            height: 18,
            backgroundColor: 'var(--color-app-background)',
            borderRadius: 'var(--radius-pill)',
            boxShadow: 'var(--shadow-control)',
            transform: 'translateX(3px)',
            transition: 'transform 100ms',
          } : undefined}
        />
      </SwitchPrimitive.Root>
      <label htmlFor={id} className={styled ? 'label' : undefined} style={{ marginBottom: 0 }}>
        {(record.items[0] as string) ?? 'Airplane mode'}
      </label>
    </div>
  );
};
