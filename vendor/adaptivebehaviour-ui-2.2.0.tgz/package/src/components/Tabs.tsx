'use client';

import { Tabs as TabsPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Tabs'` — wraps Radix Tabs with optional default styles. */
export const Tabs: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <TabsPrimitive.Root data-id={record.id} defaultValue="tab1">
      <TabsPrimitive.List
        style={styled ? {
          display: 'flex',
          gap: 'var(--spacing-1)',
          borderBottom: '1px solid var(--color-border)',
          marginBottom: 'var(--spacing-3)',
        } : undefined}
      >
        <TabsPrimitive.Trigger value="tab1" className={styled ? 'button button-ghost' : undefined}>
          {(record.items[0] as string) ?? 'Account'}
        </TabsPrimitive.Trigger>
        <TabsPrimitive.Trigger value="tab2" className={styled ? 'button button-ghost' : undefined}>
          {(record.items[1] as string) ?? 'Password'}
        </TabsPrimitive.Trigger>
      </TabsPrimitive.List>
      <TabsPrimitive.Content value="tab1" style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
        {(record.items[2] as string) ?? 'Account tab content'}
      </TabsPrimitive.Content>
      <TabsPrimitive.Content value="tab2" style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
        Password tab content
      </TabsPrimitive.Content>
    </TabsPrimitive.Root>
  );
};
