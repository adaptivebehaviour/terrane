'use client';

import { AccessibleIcon as AccessibleIconPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';

/** Factory `'AccessibleIcon'` — wraps Radix AccessibleIcon. */
export const AccessibleIcon: RecordComponent = ({ record }) => (
  <AccessibleIconPrimitive.Root label={(record.items[0] as string) ?? 'Icon'} data-id={record.id}>
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2Zm1 15h-2v-2h2Zm0-4h-2V7h2Z" />
    </svg>
  </AccessibleIconPrimitive.Root>
);
