'use client';

import { AlertDialog as AlertDialogPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'AlertDialog'` — wraps Radix AlertDialog with optional default styles. */
export const AlertDialog: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <AlertDialogPrimitive.Root data-id={record.id}>
      <AlertDialogPrimitive.Trigger className={styled ? 'button button-outline' : undefined}>
        {(record.items[0] as string) ?? 'Open alert'}
      </AlertDialogPrimitive.Trigger>
      <AlertDialogPrimitive.Portal>
        <AlertDialogPrimitive.Overlay className={styled ? 'dialog-overlay' : undefined} />
        <AlertDialogPrimitive.Content className={styled ? 'dialog-content' : undefined}>
          <AlertDialogPrimitive.Title className={styled ? 'dialog-title' : undefined}>
            {(record.items[1] as string) ?? 'Are you sure?'}
          </AlertDialogPrimitive.Title>
          <AlertDialogPrimitive.Description className={styled ? 'dialog-description' : undefined}>
            {(record.items[2] as string) ?? 'This action cannot be undone.'}
          </AlertDialogPrimitive.Description>
          <div style={{ display: 'flex', gap: 'var(--spacing-2)', justifyContent: 'flex-end' }}>
            <AlertDialogPrimitive.Cancel className={styled ? 'button button-ghost' : undefined}>
              Cancel
            </AlertDialogPrimitive.Cancel>
            <AlertDialogPrimitive.Action className={styled ? 'button button-solid' : undefined}>
              Continue
            </AlertDialogPrimitive.Action>
          </div>
        </AlertDialogPrimitive.Content>
      </AlertDialogPrimitive.Portal>
    </AlertDialogPrimitive.Root>
  );
};
