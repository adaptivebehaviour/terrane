'use client';

import { ToggleGroup as ToggleGroupPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'ToggleGroup'` — wraps Radix ToggleGroup with optional default styles. */
export const ToggleGroup: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ToggleGroupPrimitive.Root
      data-id={record.id}
      type="single"
      defaultValue="center"
      style={{ display: 'inline-flex', gap: 'var(--spacing-1)' }}
    >
      <ToggleGroupPrimitive.Item value="left" className={styled ? 'button button-ghost' : undefined}>
        {(record.items[0] as string) ?? 'Left'}
      </ToggleGroupPrimitive.Item>
      <ToggleGroupPrimitive.Item value="center" className={styled ? 'button button-ghost' : undefined}>
        {(record.items[1] as string) ?? 'Center'}
      </ToggleGroupPrimitive.Item>
      <ToggleGroupPrimitive.Item value="right" className={styled ? 'button button-ghost' : undefined}>
        {(record.items[2] as string) ?? 'Right'}
      </ToggleGroupPrimitive.Item>
    </ToggleGroupPrimitive.Root>
  );
};
