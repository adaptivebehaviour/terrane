'use client';

import { Toast as ToastPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Toast'` — wraps Radix Toast with optional default styles. */
export const Toast: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ToastPrimitive.Provider swipeDirection="right">
      <ToastPrimitive.Root
        data-id={record.id}
        open
        style={styled ? {
          backgroundColor: 'var(--color-app-background)',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-control)',
          boxShadow: 'var(--shadow-menu)',
          padding: 'var(--spacing-3) var(--spacing-4)',
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--spacing-3)',
        } : undefined}
      >
        <div>
          <ToastPrimitive.Title style={{ fontWeight: 600, fontSize: 'var(--text-label)' }}>
            {(record.items[0] as string) ?? 'Scheduled'}
          </ToastPrimitive.Title>
          <ToastPrimitive.Description style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
            {(record.items[1] as string) ?? 'Your message has been sent.'}
          </ToastPrimitive.Description>
        </div>
        <ToastPrimitive.Close className={styled ? 'button button-ghost' : undefined} aria-label="Close">
          ×
        </ToastPrimitive.Close>
      </ToastPrimitive.Root>
      <ToastPrimitive.Viewport
        style={{
          position: 'fixed',
          bottom: 'var(--spacing-6)',
          right: 'var(--spacing-6)',
          display: 'flex',
          flexDirection: 'column',
          gap: 'var(--spacing-2)',
          width: 360,
          maxWidth: '100vw',
          margin: 0,
          listStyle: 'none',
          zIndex: 100,
          outline: 'none',
        }}
      />
    </ToastPrimitive.Provider>
  );
};
