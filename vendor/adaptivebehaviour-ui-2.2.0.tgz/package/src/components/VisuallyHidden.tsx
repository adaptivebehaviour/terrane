'use client';

import { VisuallyHidden as VisuallyHiddenPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';

/** Factory `'VisuallyHidden'` — wraps Radix VisuallyHidden. */
export const VisuallyHidden: RecordComponent = ({ record }) => (
  <div data-id={record.id} style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
    Visible label; screen readers also hear:{' '}
    <VisuallyHiddenPrimitive.Root>
      {(record.items[0] as string) ?? 'visually hidden text'}
    </VisuallyHiddenPrimitive.Root>
  </div>
);
