'use client';

import { Progress as ProgressPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Progress'` — wraps Radix Progress with optional default styles. */
export const Progress: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const value = typeof record.props.value === 'number' ? record.props.value : 60;
  return (
    <ProgressPrimitive.Root
      data-id={record.id}
      value={value}
      style={styled ? {
        position: 'relative',
        overflow: 'hidden',
        backgroundColor: 'var(--color-surface-hover)',
        borderRadius: 'var(--radius-pill)',
        width: '100%',
        maxWidth: 320,
        height: 8,
      } : undefined}
    >
      <ProgressPrimitive.Indicator
        style={{
          backgroundColor: 'var(--color-solid)',
          width: '100%',
          height: '100%',
          transform: `translateX(-${100 - value}%)`,
          transition: 'transform 300ms',
        }}
      />
    </ProgressPrimitive.Root>
  );
};
