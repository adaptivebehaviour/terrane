'use client';

import { Dialog as DialogPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Dialog'` — wraps Radix Dialog with optional default styles. */
export const Dialog: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <DialogPrimitive.Root data-id={record.id}>
      <DialogPrimitive.Trigger className={styled ? 'button button-solid' : undefined}>
        {(record.items[0] as string) ?? 'Open dialog'}
      </DialogPrimitive.Trigger>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className={styled ? 'dialog-overlay' : undefined} />
        <DialogPrimitive.Content className={styled ? 'dialog-content' : undefined}>
          <DialogPrimitive.Title className={styled ? 'dialog-title' : undefined}>
            {(record.items[1] as string) ?? 'Dialog title'}
          </DialogPrimitive.Title>
          <DialogPrimitive.Description className={styled ? 'dialog-description' : undefined}>
            {(record.items[2] as string) ?? 'Dialog description.'}
          </DialogPrimitive.Description>
          <DialogPrimitive.Close className={styled ? 'button button-outline' : undefined}>
            Close
          </DialogPrimitive.Close>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
};
