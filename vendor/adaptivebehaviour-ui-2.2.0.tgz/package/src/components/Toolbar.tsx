'use client';

import { Toolbar as ToolbarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Toolbar'` — wraps Radix Toolbar with optional default styles. */
export const Toolbar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ToolbarPrimitive.Root
      data-id={record.id}
      style={styled ? {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--spacing-1)',
        padding: 'var(--spacing-1)',
        borderRadius: 'var(--radius-control)',
        border: '1px solid var(--color-border)',
        backgroundColor: 'var(--color-app-background)',
      } : undefined}
    >
      <ToolbarPrimitive.Button className={styled ? 'button button-ghost' : undefined}>
        {(record.items[0] as string) ?? 'Bold'}
      </ToolbarPrimitive.Button>
      <ToolbarPrimitive.Button className={styled ? 'button button-ghost' : undefined}>
        {(record.items[1] as string) ?? 'Italic'}
      </ToolbarPrimitive.Button>
      <ToolbarPrimitive.Separator
        style={styled ? { width: 1, height: 20, backgroundColor: 'var(--color-border)', margin: '0 var(--spacing-1)' } : undefined}
      />
      <ToolbarPrimitive.Link href="#" className={styled ? 'button button-ghost' : undefined}>
        {(record.items[2] as string) ?? 'Link'}
      </ToolbarPrimitive.Link>
    </ToolbarPrimitive.Root>
  );
};
