// Node-only workspace storage is imported from `@adaptivebehaviour/desktop/src/workspace`; this entry point is
// deliberately empty of Node and browser code so importing the package by name pulls in neither. The `desktop`
// collection is added in a later phase.
export {};
