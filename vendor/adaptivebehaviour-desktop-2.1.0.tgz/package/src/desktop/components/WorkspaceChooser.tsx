'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDesktop } from '../api';

/** Factory `'workspace-chooser'` — create a workspace, open one, or reopen a recent one. Shown while none is open. */
export const WorkspaceChooser: RecordComponent = ({ record }) => {
  const { api, recent, run } = useDesktop();
  const className = typeof record.props.className === 'string' ? record.props.className : 'mt-6 space-y-4';
  return (
    <section className={className} data-testid="chooser" data-id={record.id}>
      <p className="text-slate-600">Your data is saved in a folder on this computer. Choose where.</p>
      <div className="flex gap-3">
        <button className="rounded bg-slate-900 px-4 py-2 text-white" data-testid="create" onClick={() => void run(() => api.workspace.create())}>
          New workspace…
        </button>
        <button className="rounded border border-slate-300 px-4 py-2" data-testid="open" onClick={() => void run(() => api.workspace.open())}>
          Open workspace…
        </button>
      </div>
      {recent.length > 0 && (
        <div>
          <h2 className="mb-2 font-medium">Recent</h2>
          <ul className="space-y-1" data-testid="recent">
            {recent.map((entry) => (
              <li key={entry.workspaceId}>
                <button className="text-blue-700 underline" onClick={() => void run(() => api.workspace.openRecent({ workspaceId: entry.workspaceId }))}>
                  {entry.name}
                </button>
                <span className="ml-2 text-sm text-slate-500">{new Date(entry.lastOpened).toLocaleString()}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
};
