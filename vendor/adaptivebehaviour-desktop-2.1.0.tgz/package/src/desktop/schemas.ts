import { z } from 'zod';

// Props schemas for the desktop collection's factories (checked as records are built and when records.json loads).
// `z.looseObject`: a record may carry props a schema does not name.

/** `workspace-chooser`, `backend-status`: purely presentational, optionally given a class name. */
export const desktopViewProps = z.looseObject({
  className: z.string().optional(),
}).meta({ id: 'DesktopViewProps' });

/** `workspace-fetch`: which collection of the open workspace it reads. */
export const workspaceFetchProps = z.looseObject({
  collection: z.string().optional(),
}).meta({ id: 'WorkspaceFetchProps' });
