'use client';

import { createContext, createElement, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AbApi, ChannelOutput } from '../ipc/contract';
import { DesktopError } from '../ipc/errors';

export type WorkspaceState = ChannelOutput<'workspace.current'>;
export type RecentWorkspaces = ChannelOutput<'workspace.recent'>;
export type BackendStatus = ChannelOutput<'sidecar.status'>;
export type WorkspaceRecord = ChannelOutput<'records.get'>;

// The API object `workspace-fetch` (an Operation, so outside React) reads. The provider sets it; an application
// that never renders a provider can call `setDesktopApi` itself. One renderer has one main process, so a single
// module-level reference is exact here (unlike a server, where a module is shared by many requests).
let currentApi: AbApi | undefined;

export function setDesktopApi(api: AbApi | undefined): void {
  currentApi = api;
}

export function getDesktopApi(): AbApi | undefined {
  return currentApi;
}

/** A user-facing sentence for whatever an `ab.*` call threw. */
export function describeError(error: unknown): string {
  return error instanceof DesktopError ? `${error.message} (${error.code})` : error instanceof Error ? error.message : String(error);
}

export interface Desktop {
  api: AbApi;
  /** `undefined` until the first answer from the main process arrives. */
  workspace: WorkspaceState | undefined;
  recent: RecentWorkspaces;
  /** The optional Python backend (`absent` when the application has none). */
  backend: BackendStatus;
  error: string | undefined;
  clearError: () => void;
  /** Runs an action, shows any error it throws, then refreshes the workspace state. */
  run: (action: () => Promise<unknown>) => Promise<void>;
  refresh: () => Promise<void>;
}

const DesktopContext = createContext<Desktop | undefined>(undefined);

const BACKEND_POLL_MS = 1000;

/**
 * Gives the components below it the state of the desktop shell: the open workspace, the recent list, the optional
 * Python backend and the last error, plus the typed `ab` API. Pass the API the preload exposed (`unwrapBridge(window.abBridge)`).
 */
export function DesktopProvider({ api, children }: { api: AbApi; children?: ReactNode }) {
  const [workspace, setWorkspace] = useState<WorkspaceState>();
  const [recent, setRecent] = useState<RecentWorkspaces>([]);
  const [backend, setBackend] = useState<BackendStatus>({ state: 'absent', restarts: 0 });
  const [error, setError] = useState<string>();
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    setDesktopApi(api);
    return () => {
      mounted.current = false;
      setDesktopApi(undefined);
    };
  }, [api]);

  const refresh = useCallback(async () => {
    const [state, list] = await Promise.all([api.workspace.current(), api.workspace.recent()]);
    if (!mounted.current) return;
    setWorkspace(state);
    setRecent(list);
  }, [api]);

  useEffect(() => {
    refresh().catch((e) => setError(describeError(e)));
  }, [refresh]);

  useEffect(() => {
    const poll = () => api.sidecar.status().then((status) => mounted.current && setBackend(status), () => undefined);
    void poll();
    const timer = setInterval(poll, BACKEND_POLL_MS);
    return () => clearInterval(timer);
  }, [api]);

  const run = useCallback(async (action: () => Promise<unknown>) => {
    setError(undefined);
    try {
      await action();
    } catch (e) {
      if (mounted.current) setError(describeError(e));
    }
    await refresh().catch((e) => mounted.current && setError(describeError(e)));
  }, [refresh]);

  const value = useMemo<Desktop>(
    () => ({ api, workspace, recent, backend, error, clearError: () => setError(undefined), run, refresh }),
    [api, workspace, recent, backend, error, run, refresh],
  );
  return createElement(DesktopContext.Provider, { value }, children);
}

/** The desktop shell's state; must be used under a {@link DesktopProvider}. */
export function useDesktop(): Desktop {
  const desktop = useContext(DesktopContext);
  if (!desktop) throw new Error('useDesktop must be used inside a <DesktopProvider>');
  return desktop;
}

export interface RecordsState {
  records: WorkspaceRecord[];
  /** True until the first load finishes. */
  loading: boolean;
  error: string | undefined;
  reload: () => Promise<void>;
  put: (record: unknown) => Promise<void>;
  remove: (id: string) => Promise<void>;
}

/** The records of one collection in the open workspace (all pages), with helpers to add, replace and delete. */
export function useRecords(collection: string): RecordsState {
  const { api } = useDesktop();
  const [records, setRecords] = useState<WorkspaceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>();

  const reload = useCallback(async () => {
    try {
      const known = await api.records.collections();
      const all: WorkspaceRecord[] = [];
      if (known.includes(collection)) {
        let cursor: string | undefined;
        do {
          const page = await api.records.list({ collection, cursor, limit: 500 });
          all.push(...page.items);
          cursor = page.nextCursor;
        } while (cursor);
      }
      setRecords(all);
      setError(undefined);
    } catch (e) {
      setError(describeError(e));
    } finally {
      setLoading(false);
    }
  }, [api, collection]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const put = useCallback(async (record: unknown) => {
    try {
      await api.records.put({ collection, record });
      await reload();
    } catch (e) {
      setError(describeError(e));
    }
  }, [api, collection, reload]);

  const remove = useCallback(async (id: string) => {
    try {
      await api.records.delete({ collection, id });
      await reload();
    } catch (e) {
      setError(describeError(e));
    }
  }, [api, collection, reload]);

  return { records, loading, error, reload, put, remove };
}
