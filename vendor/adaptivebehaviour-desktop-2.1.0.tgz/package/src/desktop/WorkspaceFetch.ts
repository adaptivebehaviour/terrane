import { Operation, OperationResult, type ArgSpec } from '@adaptivebehaviour/manifesto/src/Runnable';
import type { RootConfig } from '@adaptivebehaviour/manifesto/src/Root';
import { DesktopError } from '../ipc/errors';
import { getDesktopApi } from './api';

/**
 * Factory `workspace-fetch` — reads records of the open workspace, the way `sanity-fetch` reads documents from
 * Sanity: record-driven screens can use content the user keeps in a folder on their own computer.
 *
 * `props.collection` names the workspace collection (constructor time, like `sanity-fetch`'s `projectId`). The run-time
 * arguments choose what to read: `id` returns that one record; without it, a page of the collection (`cursor`, `limit`).
 * It runs in the renderer and talks to the main process through the desktop API (see `api.tsx`), so it needs a
 * `DesktopProvider` (or `setDesktopApi`) to have supplied one; without a workspace open it returns an error result.
 *
 * @example
 * ```ts
 * const op = getCollection().create('workspace-fetch', { props: { collection: 'notes' } }) as WorkspaceFetch;
 * const result = await op.execute({ id: 'abc' });   // result.payload.record
 * const page = await op.execute({});                // page.payload.items, page.payload.nextCursor
 * ```
 */
export class WorkspaceFetch extends Operation {
  static argSpecs: ArgSpec[] = [
    { id: 'id', type: 'string', help: 'Id of the record to read; omit to list the collection' },
    { id: 'cursor', type: 'string', help: 'Id of the last record of the previous page' },
    { id: 'limit', type: 'int', help: 'Page size (1-1000)' },
  ];

  constructor(config: RootConfig = {}) {
    super(config);
  }

  async execute(args: Record<string, unknown>): Promise<OperationResult> {
    const collection = this.props.collection;
    if (typeof collection !== 'string' || collection === '') {
      return OperationResult.error(`'${this.factory}' requires a 'collection' prop.`);
    }
    const api = getDesktopApi();
    if (!api) return OperationResult.error(`'${this.factory}' needs the desktop API (render a DesktopProvider first).`);

    try {
      if (typeof args.id === 'string' && args.id !== '') {
        const record = await api.records.get({ collection, id: args.id });
        return OperationResult.ok(JSON.stringify(record), { id: args.id, record });
      }
      const limit = typeof args.limit === 'number' && Number.isFinite(args.limit) ? args.limit : undefined;
      const page = await api.records.list({ collection, cursor: typeof args.cursor === 'string' ? args.cursor : undefined, limit });
      return OperationResult.ok(JSON.stringify(page.items), { items: page.items, nextCursor: page.nextCursor ?? null });
    } catch (error) {
      if (error instanceof DesktopError) {
        return OperationResult.error(`Workspace read failed: ${error.message}`, 1, { code: error.code, collection });
      }
      throw error;
    }
  }
}
