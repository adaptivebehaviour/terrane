import type { RegistryTarget } from '@adaptivebehaviour/manifesto/src/create';
import { defineCollection } from '@adaptivebehaviour/manifesto/src/registry';
import { defineFactory, validateRecordsJson } from '@adaptivebehaviour/manifesto/src/schema';
import { BackendStatus } from './components/BackendStatus';
import { WorkspaceChooser } from './components/WorkspaceChooser';
import { desktopViewProps, workspaceFetchProps } from './schemas';
import { WorkspaceFetch } from './WorkspaceFetch';
import records from './records.json' with { type: 'json' };

/**
 * Registers the desktop collection into the {@link RegistryTarget} it is handed:
 *  - `workspace-chooser` and `backend-status` — components that read the desktop state from a `DesktopProvider`;
 *  - `workspace-fetch` — an Operation that reads records of the open workspace;
 *  - its `records.json` defaults.
 * Every factory is declarative, exactly like the `ui` collection's: the generic `Factory` covers the components, and
 * `workspace-fetch` has an instance entry like `sanity-fetch` does.
 */
export function register(target: RegistryTarget): void {
  defineFactory({ type: 'workspace-chooser', props: desktopViewProps, component: WorkspaceChooser }).register(target);
  defineFactory({ type: 'backend-status', props: desktopViewProps, component: BackendStatus }).register(target);
  defineFactory({ type: 'workspace-fetch', props: workspaceFetchProps, instance: (record) => new WorkspaceFetch(record) }).register(target);
  for (const record of validateRecordsJson('desktop/records.json', records)) {
    target.recordRegistry.set(record.id as string, record);
  }
}

/** This collection's declaration, for composing into a registry (see an application's `registry.ts`). */
export const desktop = defineCollection({ id: 'desktop', dependsOn: ['manifesto'], register });

export { DesktopProvider, describeError, getDesktopApi, setDesktopApi, useDesktop, useRecords } from './api';
export type { BackendStatus as BackendStatusValue, Desktop, RecentWorkspaces, RecordsState, WorkspaceRecord, WorkspaceState } from './api';
export { WorkspaceFetch } from './WorkspaceFetch';
