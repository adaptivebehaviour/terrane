import { ZodError } from 'zod';
import { WorkspaceError } from '../workspace/errors';

/** An error that crossed the IPC boundary: a stable machine-readable `code` plus a message safe to show a user. */
export class DesktopError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = 'DesktopError';
    this.code = code;
  }
}

/** Anything with a string `code` and a message that the layers below raise on purpose (workspace and network errors). */
interface CodedError extends Error {
  code: string;
}

function isCoded(error: unknown): error is CodedError {
  return error instanceof Error && typeof (error as { code?: unknown }).code === 'string' && (error.name === 'WorkspaceError' || error.name === 'NetworkError' || error.name === 'SidecarError' || error.name === 'DesktopError');
}

/**
 * Turns whatever a handler threw into the shape sent to the renderer. Errors raised on purpose keep their code and
 * message; a payload that failed validation becomes `invalid_request`; anything else becomes a bare `internal` error
 * so no stack trace, file path or secret reaches the renderer (the caller logs the original).
 */
export function toErrorShape(error: unknown): { code: string; message: string } {
  if (error instanceof ZodError) {
    const issues = error.issues.map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`).join('; ');
    return { code: 'invalid_request', message: `Invalid request: ${issues}` };
  }
  if (error instanceof WorkspaceError || isCoded(error)) return { code: (error as CodedError).code, message: error.message };
  return { code: 'internal', message: 'Internal error' };
}
