import { recordSchema } from '@adaptivebehaviour/manifesto/src/schema';
import { z } from 'zod';
import { eventLineSchema, sessionHeaderSchema, workspaceInfoSchema } from '../workspace/schemas';

/**
 * The one definition of every message the renderer can send to the main process. It drives three things, so they
 * cannot drift apart: the Zod validation of each payload in the main process (`./main.ts`), the typed `window.ab`
 * object the preload exposes (`./client.ts`), and the renderer's TypeScript types.
 *
 * Rules for adding a channel: name it `group.method`; make the input a closed object (never a path, URL or script
 * the renderer chooses unless the main process re-validates it); keep results plain data.
 * Deliberately absent: any channel that takes a workspace folder path (the main process shows the native folder
 * dialog itself) and any generic "fetch this URL" channel (external access is only through declared services).
 */
const channel = <I extends z.ZodType, O extends z.ZodType>(input: I, output: O) => ({ input, output });

const id = z.string().min(1).max(200);
const bytes = z.union([z.string(), z.instanceof(Uint8Array)]);

export const workspaceState = z.object({
  open: z.boolean(),
  readOnly: z.boolean(),
  info: workspaceInfoSchema.optional(),
  /** Display name only (the folder's own name), never the full path. */
  name: z.string().optional(),
});

export const recentWorkspace = z.object({
  workspaceId: z.string(),
  name: z.string(),
  lastOpened: z.string(),
});

export const credentialStatus = z.object({
  available: z.boolean(),
  /** Where the credential comes from; never its value. */
  source: z.enum(['environment', 'none']),
  /** The environment variable to set when it is missing. */
  variable: z.string().optional(),
});

export const sidecarStatus = z.object({
  /** `absent`: this application has no Python backend. */
  state: z.enum(['absent', 'stopped', 'starting', 'ready', 'restarting', 'failed']),
  restarts: z.number(),
  reason: z.string().optional(),
});

const netArgs = z.object({
  service: id,
  operation: id,
  path: z.record(z.string(), z.string()).optional(),
  query: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  body: z.unknown().optional(),
});

export const contract = {
  'app.info': channel(z.undefined(), z.object({ name: z.string(), version: z.string(), platform: z.string() })),

  'workspace.current': channel(z.undefined(), workspaceState),
  /** Shows the native "choose an empty folder" dialog, then creates a workspace there. Resolves with `open: false` if cancelled. */
  'workspace.create': channel(z.undefined(), workspaceState),
  /** Shows the native "choose a workspace folder" dialog, then opens it. */
  'workspace.open': channel(z.object({ readOnly: z.boolean().optional() }).optional(), workspaceState),
  'workspace.recent': channel(z.undefined(), z.array(recentWorkspace)),
  'workspace.openRecent': channel(z.object({ workspaceId: id, readOnly: z.boolean().optional() }), workspaceState),
  'workspace.close': channel(z.undefined(), z.null()),

  'records.collections': channel(z.undefined(), z.array(z.string())),
  'records.get': channel(z.object({ collection: id, id }), recordSchema),
  'records.put': channel(z.object({ collection: id, record: z.unknown() }), recordSchema),
  'records.delete': channel(z.object({ collection: id, id }), z.boolean()),
  'records.list': channel(
    z.object({ collection: id, cursor: z.string().optional(), limit: z.number().int().positive().max(1000).optional() }),
    z.object({ items: z.array(recordSchema), nextCursor: z.string().optional() }),
  ),

  'sessions.put': channel(z.unknown(), sessionHeaderSchema),
  'sessions.get': channel(z.object({ sessionId: id }), sessionHeaderSchema),
  'sessions.ids': channel(z.undefined(), z.array(z.string())),

  'events.append': channel(z.object({ sessionId: id, events: z.array(z.unknown()).max(1000) }), z.number()),
  'events.read': channel(
    z.object({ sessionId: id, from: z.number().int().optional(), to: z.number().int().optional() }),
    z.array(eventLineSchema),
  ),

  'files.put': channel(z.object({ path: z.string().min(1).max(1200), data: bytes }), z.null()),
  'files.get': channel(z.object({ path: z.string().min(1).max(1200) }), z.instanceof(Uint8Array)),
  'files.list': channel(z.object({ directory: z.string().max(1200).optional() }).optional(), z.array(z.string())),
  'files.remove': channel(z.object({ path: z.string().min(1).max(1200) }), z.boolean()),

  /** Calls an operation of a declared external service (see `../net`). The renderer never supplies a URL or a credential. */
  'net.call': channel(netArgs, z.unknown()),
  'credentials.status': channel(z.object({ service: id }), credentialStatus),

  /** The state of the optional Python backend. The renderer never learns its port or token. */
  'sidecar.status': channel(z.undefined(), sidecarStatus),
  /** Calls the Python backend through the main process, which holds the port and token. */
  'sidecar.request': channel(
    z.object({ method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']), path: z.string().min(1).max(2000), body: z.unknown().optional() }),
    z.unknown(),
  ),
} as const;

export type Contract = typeof contract;
export type ChannelName = keyof Contract & string;
export type ChannelInput<N extends ChannelName> = z.input<Contract[N]['input']>;
export type ChannelOutput<N extends ChannelName> = z.output<Contract[N]['output']>;

export const CHANNEL_NAMES = Object.keys(contract) as ChannelName[];

type Args<N extends ChannelName> = undefined extends ChannelInput<N> ? [input?: ChannelInput<N>] : [input: ChannelInput<N>];
type GroupOf<N extends string> = N extends `${infer G}.${string}` ? G : never;

/** The object the preload exposes as `window.ab`: `ab.records.get({ collection, id })` calls channel `records.get`. */
export type AbApi = {
  [G in GroupOf<ChannelName>]: {
    [N in ChannelName as N extends `${G}.${infer M}` ? M : never]: (...args: Args<N>) => Promise<ChannelOutput<N>>;
  };
};

/** Every response crosses the process boundary as a plain result, because Electron does not carry `Error` subclasses across. */
export type IpcResult<T> = { ok: true; value: T } | { ok: false; error: { code: string; message: string } };
