export { buildApi, buildBridge, unwrapBridge, type AbBridge, type Invoke } from './client';
export {
  CHANNEL_NAMES, contract, credentialStatus, recentWorkspace, sidecarStatus, workspaceState,
  type AbApi, type ChannelInput, type ChannelName, type ChannelOutput, type Contract, type IpcResult,
} from './contract';
export { DesktopError, toErrorShape } from './errors';
export { registerHandlers, type Handlers, type IpcEventLike, type IpcMainLike, type RegisterOptions } from './main';
