import { basename } from 'node:path';
import type { z } from 'zod';
import type { recentWorkspace, workspaceState } from '../ipc/contract';
import { WorkspaceError } from '../workspace/errors';
import type { FileStoreOptions } from '../workspace/fileStore';
import type { LockOptions } from '../workspace/lock';
import { WorkspaceStore } from '../workspace/store';
import type { SettingsStore } from './settings';

export type WorkspaceState = z.infer<typeof workspaceState>;
export type RecentView = z.infer<typeof recentWorkspace>;

export interface WorkspaceManagerOptions {
  /** The application's id; a workspace made for another application is refused. */
  appId: string;
  /** Written to new workspaces as `createdBy`, e.g. `"my-app 1.2.0"`. */
  createdBy: string;
  settings: SettingsStore;
  /** Shows the native folder dialog (the renderer never supplies a path). Resolves with `undefined` if the user cancels. */
  pickFolder: (purpose: 'create' | 'open') => Promise<string | undefined>;
  fileStore?: FileStoreOptions;
  lock?: LockOptions;
  /** Called after a workspace has been opened (e.g. to start the Python backend for it). A failure here never undoes the open. */
  onOpened?: (workspace: { root: string; readOnly: boolean }) => void | Promise<void>;
  /** Called after the workspace has been closed (e.g. to stop the Python backend). */
  onClosed?: () => void | Promise<void>;
  /** Receives errors thrown by `onOpened` / `onClosed`. */
  onHookError?: (error: unknown) => void;
}

/**
 * The main process's single owner of "the open workspace": creating, opening (writable or read-only), switching and
 * closing it, and the recent list. Everything the renderer does to data goes through `require()`.
 */
export class WorkspaceManager {
  private store: WorkspaceStore | undefined;
  private root: string | undefined;
  private readonly options: WorkspaceManagerOptions;

  constructor(options: WorkspaceManagerOptions) {
    this.options = options;
  }

  state(): WorkspaceState {
    if (!this.store || !this.root) return { open: false, readOnly: false };
    return { open: true, readOnly: this.store.readOnly, info: this.store.info, name: basename(this.root) };
  }

  /** The open workspace, or a `not_a_workspace` error saying none is open. */
  require(): WorkspaceStore {
    if (!this.store) throw new WorkspaceError('not_a_workspace', 'No workspace is open');
    return this.store;
  }

  async create(): Promise<WorkspaceState> {
    const folder = await this.options.pickFolder('create');
    if (!folder) return this.state();
    await this.close();
    const store = await WorkspaceStore.create(folder, {
      appId: this.options.appId, createdBy: this.options.createdBy, fileStore: this.options.fileStore, lock: this.options.lock,
    });
    await this.adopt(folder, store);
    return this.state();
  }

  async open(readOnly = false): Promise<WorkspaceState> {
    const folder = await this.options.pickFolder('open');
    if (!folder) return this.state();
    return this.openPath(folder, readOnly);
  }

  /** Opens the workspace in `folder`, creating it first if the folder holds none — no dialog, for applications with one fixed workspace. */
  async openDefault(folder: string): Promise<WorkspaceState> {
    try {
      return await this.openPath(folder, false);
    } catch (error) {
      if (!(error instanceof WorkspaceError) || error.code !== 'not_a_workspace') throw error;
    }
    await this.close();
    const store = await WorkspaceStore.create(folder, {
      appId: this.options.appId, createdBy: this.options.createdBy, fileStore: this.options.fileStore, lock: this.options.lock,
    });
    await this.adopt(folder, store);
    return this.state();
  }

  async openRecent(workspaceId: string, readOnly = false): Promise<WorkspaceState> {
    const entry = (await this.options.settings.read()).recent.find((r) => r.workspaceId === workspaceId);
    if (!entry) throw new WorkspaceError('not_found', 'That workspace is not in the recent list');
    try {
      return await this.openPath(entry.path, readOnly);
    } catch (error) {
      if (error instanceof WorkspaceError && error.code === 'not_a_workspace') await this.options.settings.forget(workspaceId);
      throw error;
    }
  }

  async recent(): Promise<RecentView[]> {
    return (await this.options.settings.read()).recent.map(({ workspaceId, name, lastOpened }) => ({ workspaceId, name, lastOpened }));
  }

  async close(): Promise<void> {
    const store = this.store;
    this.store = undefined;
    this.root = undefined;
    await store?.close();
    if (store) await this.runHook(() => this.options.onClosed?.());
  }

  private async runHook(hook: () => void | Promise<void>): Promise<void> {
    try {
      await hook();
    } catch (error) {
      this.options.onHookError?.(error);
    }
  }

  private async openPath(folder: string, readOnly: boolean): Promise<WorkspaceState> {
    await this.close();
    const store = await WorkspaceStore.open(folder, { readOnly, fileStore: this.options.fileStore, lock: this.options.lock });
    if (store.info.appId !== this.options.appId) {
      await store.close();
      throw new WorkspaceError('not_a_workspace', `That workspace belongs to another application (${store.info.appId})`);
    }
    await this.adopt(folder, store);
    return this.state();
  }

  private async adopt(folder: string, store: WorkspaceStore): Promise<void> {
    this.store = store;
    this.root = folder;
    await this.options.settings.remember({ path: folder, workspaceId: store.info.workspaceId, name: basename(folder) });
    await this.runHook(() => this.options.onOpened?.({ root: folder, readOnly: store.readOnly }));
  }
}
