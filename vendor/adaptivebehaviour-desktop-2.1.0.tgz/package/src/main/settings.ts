import { z } from 'zod';
import { FileStore } from '../workspace/fileStore';
import { WorkspaceError } from '../workspace/errors';

const recentEntry = z.object({
  /** Absolute path to the workspace folder. Known to the main process only; the renderer sees `workspaceId` and `name`. */
  path: z.string(),
  workspaceId: z.string(),
  name: z.string(),
  lastOpened: z.string(),
});

export const settingsSchema = z.looseObject({
  recent: z.array(recentEntry).default([]),
});

export type AppSettings = z.infer<typeof settingsSchema>;
export type RecentWorkspace = z.infer<typeof recentEntry>;

const MAX_RECENT = 10;

/**
 * Application settings (recent workspaces, and whatever else the shell adds) kept in a JSON file in the app's own
 * data folder (Electron `userData`). This is never user data: that lives in the workspace.
 */
export class SettingsStore {
  private readonly fs: FileStore;
  private readonly file: string;

  constructor(directory: string, file = 'settings.json') {
    this.fs = new FileStore(directory);
    this.file = file;
  }

  async read(): Promise<AppSettings> {
    try {
      const raw = JSON.parse(await this.fs.readText(this.file));
      const parsed = settingsSchema.safeParse(raw);
      return parsed.success ? parsed.data : { recent: [] };
    } catch (error) {
      // A missing or unreadable settings file must never stop the app from starting.
      if (error instanceof WorkspaceError || error instanceof SyntaxError) return { recent: [] };
      throw error;
    }
  }

  async write(settings: AppSettings): Promise<void> {
    await this.fs.writeAtomic(this.file, JSON.stringify(settings, null, 2) + '\n');
  }

  /** Moves (or adds) a workspace to the front of the recent list. */
  async remember(entry: Omit<RecentWorkspace, 'lastOpened'>, now = new Date()): Promise<void> {
    const settings = await this.read();
    const others = settings.recent.filter((r) => r.workspaceId !== entry.workspaceId && r.path !== entry.path);
    settings.recent = [{ ...entry, lastOpened: now.toISOString() }, ...others].slice(0, MAX_RECENT);
    await this.write(settings);
  }

  async forget(workspaceId: string): Promise<void> {
    const settings = await this.read();
    settings.recent = settings.recent.filter((r) => r.workspaceId !== workspaceId);
    await this.write(settings);
  }
}
