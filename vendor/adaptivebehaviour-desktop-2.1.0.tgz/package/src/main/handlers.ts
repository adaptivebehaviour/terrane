import type { Handlers } from '../ipc/main';
import type { NetworkServices } from '../net/services';
import { SidecarError } from '../sidecar/errors';
import type { SidecarManager } from '../sidecar/manager';
import type { WorkspaceManager } from './workspaceManager';

export interface HandlerDependencies {
  app: { name: string; version: string; platform: string };
  workspaces: WorkspaceManager;
  net: NetworkServices;
  /** The optional Python backend; without one, `sidecar.status` reports `absent` and `sidecar.request` fails cleanly. */
  sidecar?: Pick<SidecarManager, 'status' | 'request'>;
}

/**
 * The implementation of every channel in the IPC contract, in terms of the workspace manager and the network
 * services. Input arrives already validated against the channel's schema (see `registerHandlers`).
 */
export function createHandlers({ app, workspaces, net, sidecar }: HandlerDependencies): Handlers {
  return {
    'app.info': () => app,

    'workspace.current': () => workspaces.state(),
    'workspace.create': () => workspaces.create(),
    'workspace.open': (input) => workspaces.open(input?.readOnly ?? false),
    'workspace.recent': () => workspaces.recent(),
    'workspace.openRecent': (input) => workspaces.openRecent(input.workspaceId, input.readOnly ?? false),
    'workspace.close': async () => {
      await workspaces.close();
      return null;
    },

    'records.collections': () => workspaces.require().collections(),
    'records.get': (input) => workspaces.require().records.get(input.collection, input.id),
    'records.put': (input) => workspaces.require().records.put(input.collection, input.record),
    'records.delete': (input) => workspaces.require().records.delete(input.collection, input.id),
    'records.list': (input) => workspaces.require().records.list(input.collection, { cursor: input.cursor, limit: input.limit }),

    'sessions.put': (input) => workspaces.require().sessions.put(input),
    'sessions.get': (input) => workspaces.require().sessions.get(input.sessionId),
    'sessions.ids': () => workspaces.require().sessions.ids(),

    'events.append': (input) => workspaces.require().events.append(input.sessionId, input.events),
    'events.read': (input) => workspaces.require().events.read(input.sessionId, { from: input.from, to: input.to }),

    'files.put': async (input) => {
      await workspaces.require().files.put(input.path, input.data);
      return null;
    },
    'files.get': async (input) => new Uint8Array(await workspaces.require().files.get(input.path)),
    'files.list': (input) => workspaces.require().files.list(input?.directory ?? ''),
    'files.remove': (input) => workspaces.require().files.remove(input.path),

    'net.call': (input) => net.call(input.service, input.operation, { path: input.path, query: input.query, body: input.body }),
    'credentials.status': (input) => net.credentialStatus(input.service),

    'sidecar.status': () => (sidecar ? sidecar.status() : { state: 'absent' as const, restarts: 0 }),
    'sidecar.request': (input) => {
      if (!sidecar) throw new SidecarError('unavailable', 'This application has no Python backend');
      return sidecar.request(input.method, input.path, input.body);
    },
  };
}
