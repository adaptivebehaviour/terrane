export { createHandlers, type HandlerDependencies } from './handlers';
export { SettingsStore, settingsSchema, type AppSettings, type RecentWorkspace } from './settings';
export { WorkspaceManager, type RecentView, type WorkspaceManagerOptions, type WorkspaceState } from './workspaceManager';
