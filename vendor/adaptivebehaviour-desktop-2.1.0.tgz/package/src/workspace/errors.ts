/** The machine-readable reasons a workspace operation can fail. */
export type WorkspaceErrorCode =
  | 'invalid_id'
  | 'invalid_path'
  | 'invalid_data'
  | 'not_found'
  | 'exists'
  | 'locked'
  | 'newer_format'
  | 'not_a_workspace'
  | 'corrupt'
  | 'read_only';

/** Every failure the workspace layer raises on purpose carries a `code`, so callers (and the IPC layer) never parse messages. */
export class WorkspaceError extends Error {
  readonly code: WorkspaceErrorCode;
  readonly detail?: unknown;

  constructor(code: WorkspaceErrorCode, message: string, detail?: unknown) {
    super(message);
    this.name = 'WorkspaceError';
    this.code = code;
    this.detail = detail;
  }
}
