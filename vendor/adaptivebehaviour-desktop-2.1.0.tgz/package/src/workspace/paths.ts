import { realpath } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';
import { WorkspaceError } from './errors';
import { isReservedName } from './ids';

const MAX_SEGMENT_LENGTH = 100;
const MAX_SEGMENTS = 12;
// Characters Windows forbids in a file name, plus control characters. Backslash is rejected too: a relative path is
// always written with forward slashes, so a backslash can only be an attempt to smuggle a separator past the check.
// eslint-disable-next-line no-control-regex
const FORBIDDEN = /[<>:"|?*\\\u0000-\u001f]/;

/**
 * Splits a workspace-relative path (`a/b/c.json`) into validated segments, or throws `invalid_path`.
 * Rejects absolute paths, drive letters, `.`/`..`, empty segments, Windows reserved names, trailing dots/spaces and
 * over-long or over-deep paths.
 */
export function parseRelativePath(rel: unknown): string[] {
  if (typeof rel !== 'string' || rel.length === 0) throw new WorkspaceError('invalid_path', 'Path must be a non-empty string');
  if (rel.startsWith('/')) throw new WorkspaceError('invalid_path', `Path must be relative: ${JSON.stringify(rel)}`);
  const segments = rel.split('/');
  if (segments.length > MAX_SEGMENTS) throw new WorkspaceError('invalid_path', `Path is too deep: ${JSON.stringify(rel)}`);
  for (const segment of segments) {
    if (segment === '' || segment === '.' || segment === '..') {
      throw new WorkspaceError('invalid_path', `Path contains an empty or relative segment: ${JSON.stringify(rel)}`);
    }
    if (segment.length > MAX_SEGMENT_LENGTH) throw new WorkspaceError('invalid_path', `Path segment is too long: ${JSON.stringify(rel)}`);
    if (FORBIDDEN.test(segment)) throw new WorkspaceError('invalid_path', `Path contains a forbidden character: ${JSON.stringify(rel)}`);
    if (/[. ]$/.test(segment)) throw new WorkspaceError('invalid_path', `Path segment ends with a dot or space: ${JSON.stringify(rel)}`);
    if (isReservedName(segment.split('.')[0])) throw new WorkspaceError('invalid_path', `Path uses a reserved name: ${JSON.stringify(rel)}`);
  }
  return segments;
}

/** True when `candidate` is `root` itself or lies under it. Both must already be resolved absolute paths. */
export function isInside(root: string, candidate: string): boolean {
  const withSep = root.endsWith(sep) ? root : root + sep;
  return candidate === root || candidate.startsWith(withSep);
}

/**
 * Resolves `rel` under `root` and returns the absolute path. Beyond the lexical checks of `parseRelativePath`, the
 * nearest existing ancestor is resolved through symlinks/junctions and must still lie inside the (real) root, so a
 * link planted inside the workspace cannot lead the renderer outside it.
 */
export async function resolveInside(root: string, rel: string): Promise<string> {
  const segments = parseRelativePath(rel);
  const absolute = resolve(join(root, ...segments));
  if (!isInside(resolve(root), absolute)) throw new WorkspaceError('invalid_path', `Path escapes the workspace: ${JSON.stringify(rel)}`);

  // A root that does not exist yet (e.g. the app's data folder on first run) has no links beneath it to follow.
  let realRoot: string;
  try {
    realRoot = await realpath(root);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return absolute;
    throw error;
  }
  let probe = absolute;
  for (;;) {
    try {
      const real = await realpath(probe);
      if (!isInside(realRoot, real)) throw new WorkspaceError('invalid_path', `Path escapes the workspace through a link: ${JSON.stringify(rel)}`);
      break;
    } catch (error) {
      if (error instanceof WorkspaceError) throw error;
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      const parent = dirname(probe);
      if (parent === probe) break;
      probe = parent;
    }
  }
  return absolute;
}
