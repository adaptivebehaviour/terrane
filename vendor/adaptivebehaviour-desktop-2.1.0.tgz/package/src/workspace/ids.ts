import { WorkspaceError } from './errors';

/**
 * Ids (collection ids, record ids, session ids) are lower-case slugs or UUIDs. Lower-case only, because Windows and
 * macOS file systems are case-insensitive; at most 63 characters, to keep full paths far below Windows' legacy
 * 260-character limit.
 */
export const ID_PATTERN = /^[a-z0-9][a-z0-9-]{0,62}$/;

/** Device names Windows refuses as file names (with any extension), e.g. `con.json`. */
const RESERVED = new Set([
  'con', 'prn', 'aux', 'nul',
  ...Array.from({ length: 9 }, (_, i) => `com${i + 1}`),
  ...Array.from({ length: 9 }, (_, i) => `lpt${i + 1}`),
]);

export function isReservedName(base: string): boolean {
  return RESERVED.has(base.toLowerCase());
}

export function isValidId(id: unknown): id is string {
  return typeof id === 'string' && ID_PATTERN.test(id) && !isReservedName(id);
}

/** Returns `id` unchanged, or throws `invalid_id`. `what` names the id in the message ("record id", "collection id", …). */
export function assertId(what: string, id: unknown): string {
  if (!isValidId(id)) {
    throw new WorkspaceError('invalid_id', `Invalid ${what}: ${JSON.stringify(id)} (expected a lower-case slug or UUID, 1-63 characters)`);
  }
  return id;
}
