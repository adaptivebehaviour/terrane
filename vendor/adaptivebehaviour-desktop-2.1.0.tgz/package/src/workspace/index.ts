export { WorkspaceError, type WorkspaceErrorCode } from './errors';
export { FileStore, type FileStoreOptions } from './fileStore';
export { ID_PATTERN, assertId, isReservedName, isValidId } from './ids';
export { LOCK_FILE, WorkspaceLock, acquireLock, type LockInfo, type LockOptions } from './lock';
export { MIGRATIONS, migrateWorkspace, snapshotWorkspace, type Migration, type MigrationContext } from './migrations';
export { isInside, parseRelativePath, resolveInside } from './paths';
export {
  FORMAT_VERSION, eventLineSchema, sessionHeaderSchema, workspaceInfoSchema, workspaceSchemas,
  type EventLine, type SessionHeader, type WorkspaceInfo,
} from './schemas';
export { WorkspaceStore, type CreateOptions, type EventRange, type ListOptions, type OpenOptions, type Page } from './store';
