import { z } from 'zod';
import { ID_PATTERN } from './ids';

/**
 * The on-disk format version written to `workspace.json`. Bump it (and add a migration in `migrations.ts`) for any
 * change that an older build could not read. A build refuses a workspace whose version is higher than its own.
 */
export const FORMAT_VERSION = 1;

const idString = z.string().regex(ID_PATTERN);
const timestamp = z.iso.datetime({ offset: true });

/**
 * The boundary schemas of the workspace format. They are exported to `contracts/schemas/desktop/` as JSON Schema and
 * become Pydantic models in `ab_desktop` (see `scripts/generate_contracts.py`); never edit the generated models.
 * Objects are loose so a newer build's extra fields survive a round trip through an older one.
 */
export const workspaceInfoSchema = z.looseObject({
  formatVersion: z.int().min(1),
  workspaceId: z.uuid(),
  appId: idString,
  createdAt: timestamp,
  createdBy: z.string().min(1),
});

/** `sessions/<id>/session.json`: the header of one data-collection session (the local twin of `data.sessions`). */
export const sessionHeaderSchema = z.looseObject({
  sessionId: idString,
  userId: idString.optional(),
  startedAt: timestamp,
  endedAt: timestamp.nullable().optional(),
  props: z.record(z.string(), z.unknown()),
});

/** One line of `sessions/<id>/events.ndjson` (the local twin of `data.events`; same fields as the browser's buffered event). */
export const eventLineSchema = z.looseObject({
  id: idString,
  index: z.int().min(0),
  kind: z.string().optional(),
  props: z.record(z.string(), z.unknown()),
  browserTimestamp: timestamp,
});

export type WorkspaceInfo = z.infer<typeof workspaceInfoSchema>;
export type SessionHeader = z.infer<typeof sessionHeaderSchema>;
export type EventLine = z.infer<typeof eventLineSchema>;

/** Every schema the workspace format exports, by the name it has in `contracts/schemas/desktop/`. */
export const workspaceSchemas = {
  WorkspaceInfo: workspaceInfoSchema,
  SessionHeader: sessionHeaderSchema,
  EventLine: eventLineSchema,
} as const;
