import { randomUUID } from 'node:crypto';
import { mkdir, open, readdir, readFile, rename, rm, stat, truncate } from 'node:fs/promises';
import { dirname } from 'node:path';
import { WorkspaceError } from './errors';
import { resolveInside } from './paths';

export interface FileStoreOptions {
  /** Test seam: runs after the temporary file is written and flushed, before it is renamed over the target. */
  beforeRename?: (target: string) => void | Promise<void>;
  /** How many times to retry a rename that fails with EPERM/EBUSY/EACCES (antivirus and indexers hold handles on Windows). */
  renameRetries?: number;
}

const RETRYABLE = new Set(['EPERM', 'EBUSY', 'EACCES']);
const TEMP_SUFFIX = /\.[0-9a-f]{8}\.tmp$/;
const sleep = (ms: number) => new Promise<void>((done) => setTimeout(done, ms));

/**
 * Byte-level access to files under one root directory. This is the only place that handles path safety and
 * atomicity (and the place an encrypting decorator would go): everything above it deals in records and events.
 * All paths are workspace-relative with forward slashes and are checked by `resolveInside` on every call.
 */
export class FileStore {
  readonly root: string;
  private readonly options: FileStoreOptions;

  constructor(root: string, options: FileStoreOptions = {}) {
    this.root = root;
    this.options = options;
  }

  async path(rel: string): Promise<string> {
    return resolveInside(this.root, rel);
  }

  async exists(rel: string): Promise<boolean> {
    try {
      await stat(await this.path(rel));
      return true;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
      throw error;
    }
  }

  async read(rel: string): Promise<Buffer> {
    const target = await this.path(rel);
    try {
      return await readFile(target);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') throw new WorkspaceError('not_found', `No such file: ${rel}`);
      throw error;
    }
  }

  async readText(rel: string): Promise<string> {
    return (await this.read(rel)).toString('utf8');
  }

  /** Names (not paths) of the entries in a directory ('.' is the root); an absent directory is an empty one. */
  async list(rel: string): Promise<string[]> {
    const target = rel === '.' ? this.root : await this.path(rel);
    try {
      return (await readdir(target)).sort();
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
      throw error;
    }
  }

  async mkdir(rel: string): Promise<void> {
    await mkdir(await this.path(rel), { recursive: true });
  }

  async remove(rel: string): Promise<boolean> {
    const target = await this.path(rel);
    try {
      await stat(target);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
      throw error;
    }
    await rm(target, { recursive: true, force: true });
    return true;
  }

  /**
   * Replaces `rel` atomically: write a temporary file in the same directory, flush it to disk, rename it over the
   * target. A crash leaves either the old file or the new one, never a mixture; a leftover `*.tmp` is swept by `sweepTemp`.
   */
  async writeAtomic(rel: string, data: string | Uint8Array): Promise<void> {
    const target = await this.path(rel);
    await mkdir(dirname(target), { recursive: true });
    const temp = `${target}.${randomUUID().slice(0, 8)}.tmp`;
    try {
      const handle = await open(temp, 'wx');
      try {
        await handle.writeFile(data);
        await handle.datasync();
      } finally {
        await handle.close();
      }
      await this.options.beforeRename?.(target);
      await this.renameWithRetry(temp, target);
    } catch (error) {
      await rm(temp, { force: true }).catch(() => undefined);
      throw error;
    }
  }

  private async renameWithRetry(from: string, to: string): Promise<void> {
    const retries = this.options.renameRetries ?? 6;
    for (let attempt = 0; ; attempt += 1) {
      try {
        await rename(from, to);
        return;
      } catch (error) {
        const code = (error as NodeJS.ErrnoException).code ?? '';
        if (!RETRYABLE.has(code) || attempt >= retries) throw error;
        await sleep(10 * 2 ** attempt);
      }
    }
  }

  /** Deletes `*.tmp` files left by an interrupted `writeAtomic` in one directory (non-recursive). Returns the count. */
  async sweepTemp(rel: string): Promise<number> {
    let removed = 0;
    for (const name of await this.list(rel)) {
      if (TEMP_SUFFIX.test(name)) {
        await rm(await this.path(rel === '.' ? name : `${rel}/${name}`), { force: true });
        removed += 1;
      }
    }
    return removed;
  }

  /**
   * Appends `lines` (each one complete JSON text, no newline) to an append-only log in a single write, then flushes.
   * Call `repairLog` once per log per process before the first append, so a torn final line from an earlier crash
   * is cut off instead of being glued to the new data.
   */
  async appendLines(rel: string, lines: string[]): Promise<void> {
    if (lines.length === 0) return;
    for (const line of lines) {
      if (line.includes('\n') || line.includes('\r')) throw new WorkspaceError('invalid_data', 'A log line must not contain a line break');
    }
    const target = await this.path(rel);
    await mkdir(dirname(target), { recursive: true });
    const handle = await open(target, 'a');
    try {
      await handle.writeFile(lines.join('\n') + '\n');
      await handle.datasync();
    } finally {
      await handle.close();
    }
  }

  /**
   * If the log does not end with a newline (a crash mid-write), truncates it back to the last complete line.
   * Returns the number of bytes removed (0 when the log is intact or absent).
   */
  async repairLog(rel: string): Promise<number> {
    const target = await this.path(rel);
    let size: number;
    try {
      size = (await stat(target)).size;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return 0;
      throw error;
    }
    if (size === 0) return 0;

    const handle = await open(target, 'r');
    let keep = 0;
    try {
      const chunk = Buffer.alloc(4096);
      const last = Buffer.alloc(1);
      await handle.read(last, 0, 1, size - 1);
      if (last[0] === 0x0a) return 0;

      let end = size;
      scan: while (end > 0) {
        const start = Math.max(0, end - chunk.length);
        const { bytesRead } = await handle.read(chunk, 0, end - start, start);
        for (let i = bytesRead - 1; i >= 0; i -= 1) {
          if (chunk[i] === 0x0a) {
            keep = start + i + 1;
            break scan;
          }
        }
        end = start;
      }
    } finally {
      await handle.close();
    }
    await truncate(target, keep);
    return size - keep;
  }

  /**
   * Reads a log as parsed JSON values. A final line with no terminating newline is a torn write and is ignored;
   * an unparseable line anywhere else is corruption and throws.
   */
  async readLines(rel: string): Promise<unknown[]> {
    let text: string;
    try {
      text = await this.readText(rel);
    } catch (error) {
      if (error instanceof WorkspaceError && error.code === 'not_found') return [];
      throw error;
    }
    const lines = text.split('\n');
    lines.pop(); // the segment after the last newline: empty for an intact log, a torn partial line otherwise
    const values: unknown[] = [];
    lines.forEach((line, i) => {
      if (line.trim() === '') return;
      try {
        values.push(JSON.parse(line));
      } catch {
        throw new WorkspaceError('corrupt', `Unparseable line ${i + 1} in ${rel}`);
      }
    });
    return values;
  }
}
