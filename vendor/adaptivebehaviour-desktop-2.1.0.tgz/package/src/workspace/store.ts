import { randomUUID } from 'node:crypto';
import { mkdir, readdir, stat } from 'node:fs/promises';
import { recordSchema } from '@adaptivebehaviour/manifesto/src/schema';
import type { z } from 'zod';
import { WorkspaceError } from './errors';
import { FileStore, type FileStoreOptions } from './fileStore';
import { assertId } from './ids';
import { acquireLock, type LockOptions, type WorkspaceLock } from './lock';
import { migrateWorkspace, type Migration } from './migrations';
import {
  eventLineSchema, FORMAT_VERSION, sessionHeaderSchema, workspaceInfoSchema,
  type EventLine, type SessionHeader, type WorkspaceInfo,
} from './schemas';

type RootRecord = z.infer<typeof recordSchema>;

export interface CreateOptions {
  appId: string;
  /** Written to `workspace.json` as `createdBy` (the app name and version that made the workspace). */
  createdBy: string;
  workspaceId?: string;
  fileStore?: FileStoreOptions;
  lock?: LockOptions;
}

export interface OpenOptions {
  /** Open without taking the lock and refuse every write. The only way to open a workspace written by a newer build. */
  readOnly?: boolean;
  fileStore?: FileStoreOptions;
  lock?: LockOptions;
  /** Test seam: replace the migration table / target version. */
  migrations?: Record<number, Migration>;
  targetVersion?: number;
}

export interface ListOptions {
  /** The id of the last item of the previous page. */
  cursor?: string;
  limit?: number;
}

export interface Page<T> {
  items: T[];
  nextCursor?: string;
}

export interface EventRange {
  from?: number;
  to?: number;
}

const DEFAULT_PAGE = 100;
const MAX_PAGE = 1000;

function parseWith<S extends z.ZodType>(schema: S, value: unknown, what: string): z.infer<S> {
  const result = schema.safeParse(value);
  if (!result.success) {
    throw new WorkspaceError('invalid_data', `Invalid ${what}: ${result.error.issues.map((i) => `${i.path.join('.') || '(root)'}: ${i.message}`).join('; ')}`);
  }
  return result.data;
}

function parseJson(text: string, what: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    throw new WorkspaceError('corrupt', `${what} is not valid JSON`);
  }
}

/**
 * One open workspace folder: records, sessions, events and files, with the lock held for the lifetime of a writable
 * store. Everything is stored as plain files (see WORKSPACE-FORMAT.md).
 */
export class WorkspaceStore {
  readonly root: string;
  readonly info: WorkspaceInfo;
  readonly readOnly: boolean;
  private readonly fs: FileStore;
  private readonly lock: WorkspaceLock | undefined;
  private readonly repairedLogs = new Set<string>();

  private constructor(root: string, info: WorkspaceInfo, fs: FileStore, lock: WorkspaceLock | undefined, readOnly: boolean) {
    this.root = root;
    this.info = info;
    this.fs = fs;
    this.lock = lock;
    this.readOnly = readOnly;
  }

  /** Creates a workspace in an empty (or absent) folder and returns it open and locked. */
  static async create(root: string, options: CreateOptions): Promise<WorkspaceStore> {
    assertId('app id', options.appId);
    await mkdir(root, { recursive: true });
    if ((await readdir(root)).length > 0) {
      throw new WorkspaceError('exists', `Cannot create a workspace in a folder that is not empty: ${root}`);
    }
    const fs = new FileStore(root, options.fileStore);
    const info: WorkspaceInfo = {
      formatVersion: FORMAT_VERSION,
      workspaceId: options.workspaceId ?? randomUUID(),
      appId: options.appId,
      createdAt: new Date().toISOString(),
      createdBy: options.createdBy,
    };
    parseWith(workspaceInfoSchema, info, 'workspace info');
    const lock = await acquireLock(root, options.lock);
    await fs.writeAtomic('workspace.json', JSON.stringify(info, null, 2) + '\n');
    await Promise.all(['collections', 'sessions', 'files'].map((dir) => fs.mkdir(dir)));
    return new WorkspaceStore(root, info, fs, lock, false);
  }

  /** Opens an existing workspace. Throws `not_a_workspace`, `corrupt`, `locked` or `newer_format` as appropriate. */
  static async open(root: string, options: OpenOptions = {}): Promise<WorkspaceStore> {
    const fs = new FileStore(root, options.fileStore);
    try {
      await stat(root);
    } catch {
      throw new WorkspaceError('not_a_workspace', `No such folder: ${root}`);
    }
    if (!(await fs.exists('workspace.json'))) throw new WorkspaceError('not_a_workspace', `Not a workspace (no workspace.json): ${root}`);

    let raw: unknown;
    try {
      raw = JSON.parse(await fs.readText('workspace.json'));
    } catch {
      throw new WorkspaceError('corrupt', 'workspace.json is not valid JSON');
    }
    let info: WorkspaceInfo;
    try {
      info = parseWith(workspaceInfoSchema, raw, 'workspace.json');
    } catch (error) {
      throw new WorkspaceError('corrupt', (error as Error).message);
    }

    const target = options.targetVersion ?? FORMAT_VERSION;
    if (info.formatVersion > target && !options.readOnly) {
      throw new WorkspaceError('newer_format', `This workspace uses format ${info.formatVersion}; this build understands up to ${target}. Open it read-only or update the app.`);
    }
    if (options.readOnly) return new WorkspaceStore(root, info, fs, undefined, true);

    const lock = await acquireLock(root, options.lock);
    try {
      await fs.sweepTemp('.');
      info = await migrateWorkspace(fs, info, options.migrations, target);
    } catch (error) {
      await lock.release();
      throw error;
    }
    return new WorkspaceStore(root, info, fs, lock, false);
  }

  async close(): Promise<void> {
    await this.lock?.release();
  }

  private assertWritable(): void {
    if (this.readOnly) throw new WorkspaceError('read_only', 'The workspace is open read-only');
  }

  // --- records -------------------------------------------------------------------------------------------------

  readonly records = {
    get: async (collection: string, id: string): Promise<RootRecord> => {
      assertId('collection id', collection);
      assertId('record id', id);
      const raw = parseJson(await this.fs.readText(`collections/${collection}/${id}.json`), `Record ${collection}/${id}`);
      const record = parseWith(recordSchema, raw, `record ${collection}/${id}`);
      if (record.id !== id) throw new WorkspaceError('corrupt', `Record file ${collection}/${id}.json holds id ${JSON.stringify(record.id)}`);
      return record;
    },

    put: async (collection: string, record: unknown): Promise<RootRecord> => {
      this.assertWritable();
      assertId('collection id', collection);
      const valid = parseWith(recordSchema, record, 'record');
      assertId('record id', valid.id);
      await this.fs.writeAtomic(`collections/${collection}/${valid.id}.json`, JSON.stringify(valid, null, 2) + '\n');
      return valid;
    },

    delete: async (collection: string, id: string): Promise<boolean> => {
      this.assertWritable();
      assertId('collection id', collection);
      assertId('record id', id);
      return this.fs.remove(`collections/${collection}/${id}.json`);
    },

    ids: async (collection: string): Promise<string[]> => {
      assertId('collection id', collection);
      return (await this.fs.list(`collections/${collection}`)).filter((name) => name.endsWith('.json')).map((name) => name.slice(0, -5));
    },

    list: async (collection: string, options: ListOptions = {}): Promise<Page<RootRecord>> => {
      const limit = Math.min(Math.max(options.limit ?? DEFAULT_PAGE, 1), MAX_PAGE);
      const all = await this.records.ids(collection);
      const after = options.cursor === undefined ? all : all.filter((id) => id > options.cursor!);
      const page = after.slice(0, limit);
      const items = await Promise.all(page.map((id) => this.records.get(collection, id)));
      return after.length > limit ? { items, nextCursor: page[page.length - 1] } : { items };
    },
  };

  /** The collection ids that exist in this workspace. */
  async collections(): Promise<string[]> {
    return this.fs.list('collections');
  }

  // --- sessions and events -------------------------------------------------------------------------------------

  readonly sessions = {
    put: async (header: unknown): Promise<SessionHeader> => {
      this.assertWritable();
      const valid = parseWith(sessionHeaderSchema, header, 'session header');
      assertId('session id', valid.sessionId);
      await this.fs.writeAtomic(`sessions/${valid.sessionId}/session.json`, JSON.stringify(valid, null, 2) + '\n');
      return valid;
    },

    get: async (sessionId: string): Promise<SessionHeader> => {
      assertId('session id', sessionId);
      const raw = parseJson(await this.fs.readText(`sessions/${sessionId}/session.json`), `Session ${sessionId}`);
      return parseWith(sessionHeaderSchema, raw, `session ${sessionId}`);
    },

    ids: async (): Promise<string[]> => this.fs.list('sessions'),
  };

  readonly events = {
    /** Appends events to a session's log. Resolves only after the data is flushed to disk. */
    append: async (sessionId: string, events: unknown[]): Promise<number> => {
      this.assertWritable();
      assertId('session id', sessionId);
      const valid = events.map((event, i) => parseWith(eventLineSchema, event, `event ${i}`));
      const log = `sessions/${sessionId}/events.ndjson`;
      if (!this.repairedLogs.has(log)) {
        await this.fs.repairLog(log);
        this.repairedLogs.add(log);
      }
      await this.fs.appendLines(log, valid.map((event) => JSON.stringify(event)));
      return valid.length;
    },

    read: async (sessionId: string, range: EventRange = {}): Promise<EventLine[]> => {
      assertId('session id', sessionId);
      const lines = await this.fs.readLines(`sessions/${sessionId}/events.ndjson`);
      const events = lines.map((line, i) => parseWith(eventLineSchema, line, `event line ${i + 1} of session ${sessionId}`));
      return events.filter((event) => (range.from === undefined || event.index >= range.from) && (range.to === undefined || event.index <= range.to));
    },
  };

  // --- files ---------------------------------------------------------------------------------------------------

  readonly files = {
    put: async (rel: string, data: string | Uint8Array): Promise<void> => {
      this.assertWritable();
      await this.fs.writeAtomic(`files/${rel}`, data);
    },
    get: async (rel: string): Promise<Buffer> => this.fs.read(`files/${rel}`),
    /** Names of the entries directly under `dir` (workspace `files/` when omitted). */
    list: async (dir = ''): Promise<string[]> => this.fs.list(dir === '' ? 'files' : `files/${dir}`),
    remove: async (rel: string): Promise<boolean> => {
      this.assertWritable();
      return this.fs.remove(`files/${rel}`);
    },
  };
}
