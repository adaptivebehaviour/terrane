import { cp, mkdir, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import type { FileStore } from './fileStore';
import { FORMAT_VERSION, type WorkspaceInfo } from './schemas';

export interface MigrationContext {
  store: FileStore;
  info: WorkspaceInfo;
}

/** Upgrades a workspace from format version N to N + 1 (the migration is stored under key N). */
export type Migration = (context: MigrationContext) => Promise<void>;

/** The numbered migrations, oldest first. Empty while `FORMAT_VERSION` is 1. */
export const MIGRATIONS: Record<number, Migration> = {};

/** Top-level entries a snapshot leaves out: earlier snapshots, the lock, and user assets (which can be large and are never rewritten by a migration). */
const SNAPSHOT_SKIP = new Set(['.backups', '.lock', 'files']);

/** Copies everything a migration could change into `.backups/<stamp>-v<from>/` and returns that folder's workspace-relative path. */
export async function snapshotWorkspace(store: FileStore, fromVersion: number): Promise<string> {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const rel = `.backups/${stamp}-v${fromVersion}`;
  const dest = await store.path(rel);
  await mkdir(dest, { recursive: true });
  for (const name of await readdir(store.root)) {
    if (SNAPSHOT_SKIP.has(name) || name.endsWith('.tmp')) continue;
    await cp(join(store.root, name), join(dest, name), { recursive: true });
  }
  return rel;
}

/**
 * Brings a workspace up to `target`. Takes a snapshot first, runs each migration in order, and rewrites
 * `workspace.json` after every step so an interruption leaves a consistent (older) version, not a half-way one.
 */
export async function migrateWorkspace(
  store: FileStore,
  info: WorkspaceInfo,
  migrations: Record<number, Migration> = MIGRATIONS,
  target: number = FORMAT_VERSION,
): Promise<WorkspaceInfo> {
  if (info.formatVersion >= target) return info;
  for (let version = info.formatVersion; version < target; version += 1) {
    if (!migrations[version]) throw new Error(`No migration from workspace format ${version} to ${version + 1}`);
  }
  await snapshotWorkspace(store, info.formatVersion);
  let current = info;
  for (let version = info.formatVersion; version < target; version += 1) {
    await migrations[version]({ store, info: current });
    current = { ...current, formatVersion: version + 1 };
    await store.writeAtomic('workspace.json', JSON.stringify(current, null, 2) + '\n');
  }
  return current;
}
