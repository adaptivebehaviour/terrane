import { spawn, type ChildProcess } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { createInterface } from 'node:readline';
import { SidecarError } from './errors';

export type SidecarState = 'stopped' | 'starting' | 'ready' | 'restarting' | 'failed';

export interface SidecarLaunch {
  command: string;
  args: string[];
  cwd?: string;
  /** Extra environment for this launch (added to the allow-listed environment). */
  env?: Record<string, string>;
}

export interface SidecarOptions {
  /** How to start the sidecar for a workspace. A function, because the workspace (and in a packaged app, the path) can differ per launch. */
  launch: (context: { workspaceRoot: string }) => SidecarLaunch;
  /**
   * Names of environment variables copied from this process into the sidecar, beyond the minimal set every process
   * needs to run (PATH, SystemRoot, TEMP, …). Pass the credential variables the application's declared services say
   * the sidecar needs; nothing else of this process's environment reaches it.
   */
  allowedEnv?: string[];
  readyTimeoutMs?: number;
  requestTimeoutMs?: number;
  /** Automatic restarts after an unexpected exit, before the state becomes `failed`. */
  maxRestarts?: number;
  /** First restart delay; it doubles each time. */
  backoffMs?: number;
  /** How long a clean stop may take before the process tree is killed. */
  shutdownGraceMs?: number;
  /** Receives redacted one-line diagnostics. */
  log?: (line: string) => void;
}

export interface SidecarStatus {
  state: SidecarState;
  restarts: number;
  /** Set when the state is `failed`. */
  reason?: string;
}

const MINIMAL_ENV = [
  'PATH', 'Path', 'PATHEXT', 'SystemRoot', 'SYSTEMROOT', 'windir', 'COMSPEC', 'TEMP', 'TMP', 'TMPDIR',
  'HOME', 'USERPROFILE', 'APPDATA', 'LOCALAPPDATA', 'HOMEDRIVE', 'HOMEPATH', 'ProgramData', 'ProgramFiles',
  'LANG', 'LC_ALL',
];
const READY = /^AB_SIDECAR_READY (\{.*\})$/;
const METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']);
const PATH_PATTERN = /^\/[A-Za-z0-9._~!$&'()*+,;=:@%/-]*(\?[A-Za-z0-9._~!$&'()*+,;=:@%/?-]*)?$/;
const FORBIDDEN_PATHS = new Set(['/shutdown']);

/** Throws `invalid_request` unless `method` and `path` are something the renderer may ask the sidecar for. */
export function assertSidecarRequest(method: string, path: string): void {
  if (!METHODS.has(method)) throw new SidecarError('invalid_request', `Unsupported method: ${method}`);
  const [pathname] = path.split('?');
  if (path.length > 2000 || !PATH_PATTERN.test(path) || pathname.includes('//') || pathname.split('/').some((s) => s === '..' || s === '.')) {
    throw new SidecarError('invalid_request', 'Invalid sidecar path');
  }
  if (FORBIDDEN_PATHS.has(pathname)) throw new SidecarError('invalid_request', `The path ${pathname} cannot be called from the renderer`);
}

function killTree(pid: number | undefined): Promise<void> {
  if (!pid) return Promise.resolve();
  if (process.platform === 'win32') {
    return new Promise((resolve) => {
      const killer = spawn('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      killer.on('exit', () => resolve());
      killer.on('error', () => resolve());
    });
  }
  try {
    process.kill(pid, 'SIGKILL');
  } catch {
    // already gone
  }
  return Promise.resolve();
}

/**
 * Starts, supervises and stops the Python sidecar for one workspace at a time.
 *
 * It spawns the process with a per-launch random token (in its environment, never its arguments), waits for the
 * `AB_SIDECAR_READY` line, verifies `/health`, restarts it with backoff if it dies, and on `stop()` asks it to shut
 * down, closes its stdin (which also makes it exit if this process is killed), and finally kills the whole process
 * tree. The renderer never sees the port or the token: it asks main, and main calls `request()`.
 */
export class SidecarManager {
  private readonly options: SidecarOptions;
  private child: ChildProcess | undefined;
  private port: number | undefined;
  private realPid: number | undefined;
  private token = '';
  private workspaceRoot = '';
  private generation = 0;
  private restarts = 0;
  private current: SidecarState = 'stopped';
  private reason: string | undefined;
  private stopping = false;
  private restartTimer: NodeJS.Timeout | undefined;
  private readonly recentStderr: string[] = [];
  private readonly listeners = new Set<(status: SidecarStatus) => void>();

  constructor(options: SidecarOptions) {
    this.options = options;
  }

  status(): SidecarStatus {
    return { state: this.current, restarts: this.restarts, ...(this.reason ? { reason: this.reason } : {}) };
  }

  onChange(listener: (status: SidecarStatus) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private setState(state: SidecarState, reason?: string): void {
    this.current = state;
    this.reason = reason;
    for (const listener of this.listeners) listener(this.status());
  }

  private log(line: string): void {
    this.options.log?.(this.token ? line.split(this.token).join('[redacted]') : line);
  }

  /** Starts the sidecar for `workspaceRoot` (stopping any earlier one) and resolves when it is ready, or rejects. */
  async start(workspaceRoot: string): Promise<void> {
    await this.stop();
    this.workspaceRoot = workspaceRoot;
    this.restarts = 0;
    this.stopping = false;
    await this.launchOnce('starting');
  }

  private childEnvironment(launch: SidecarLaunch): NodeJS.ProcessEnv {
    const env: NodeJS.ProcessEnv = {};
    for (const name of [...MINIMAL_ENV, ...(this.options.allowedEnv ?? [])]) {
      if (process.env[name] !== undefined) env[name] = process.env[name];
    }
    // PYTHONNOUSERSITE: never import from the user's own site-packages (%APPDATA%\Python, ~/.local). A bundled or venv
    // interpreter must run only the packages it was built with; a stray older uvicorn there breaks shutdown.
    return { ...env, ...launch.env, AB_SIDECAR_TOKEN: this.token, AB_WORKSPACE: this.workspaceRoot, PYTHONUNBUFFERED: '1', PYTHONNOUSERSITE: '1' };
  }

  private launchOnce(state: 'starting' | 'restarting'): Promise<void> {
    const generation = ++this.generation;
    this.setState(state);
    this.token = randomBytes(32).toString('hex');
    this.port = undefined;
    this.realPid = undefined;
    this.recentStderr.length = 0;
    const launch = this.options.launch({ workspaceRoot: this.workspaceRoot });

    return new Promise<void>((resolve, reject) => {
      let settled = false;
      const settle = (error?: Error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (error) reject(error);
        else resolve();
      };

      const child = spawn(launch.command, launch.args, {
        cwd: launch.cwd,
        env: this.childEnvironment(launch),
        stdio: ['pipe', 'pipe', 'pipe'],
        windowsHide: true,
      });
      this.child = child;

      const fail = (message: string) => {
        void killTree(child.pid);
        void killTree(this.realPid);
        settle(new SidecarError('failed_to_start', message));
      };
      const timer = setTimeout(() => fail(`The Python backend did not become ready within ${this.options.readyTimeoutMs ?? 15_000} ms`), this.options.readyTimeoutMs ?? 15_000);

      createInterface({ input: child.stdout! }).on('line', (line) => {
        const match = READY.exec(line);
        if (!match || generation !== this.generation) {
          this.log(`[sidecar] ${line}`);
          return;
        }
        try {
          const info = JSON.parse(match[1]) as { port: number; pid: number };
          this.port = info.port;
          this.realPid = info.pid;
        } catch {
          fail('The Python backend announced itself with an invalid message');
          return;
        }
        this.fetchHealth().then(() => {
          if (generation !== this.generation) return;
          this.setState('ready');
          settle();
        }, (error: Error) => fail(`The Python backend started but failed its health check: ${error.message}`));
      });
      createInterface({ input: child.stderr! }).on('line', (line) => {
        this.recentStderr.push(line);
        if (this.recentStderr.length > 20) this.recentStderr.shift();
        this.log(`[sidecar:err] ${line}`);
      });
      child.on('error', (error) => settle(new SidecarError('failed_to_start', `Could not start the Python backend: ${error.message}`)));
      child.on('exit', (code, signal) => {
        if (generation !== this.generation) return;
        const detail = `exited (${signal ?? `code ${code}`})`;
        if (!settled) {
          const lines = this.recentStderr.join('\n');
          settle(new SidecarError('failed_to_start', `The Python backend ${detail} before it was ready${lines ? `:\n${lines}` : ''}`));
        }
        this.onExit(detail);
      });
    });
  }

  private onExit(detail: string): void {
    this.child = undefined;
    this.port = undefined;
    if (this.stopping) {
      this.setState('stopped');
      return;
    }
    const max = this.options.maxRestarts ?? 3;
    if (this.restarts >= max) {
      this.setState('failed', `The Python backend ${detail} and was restarted ${this.restarts} times`);
      return;
    }
    const delay = (this.options.backoffMs ?? 250) * 2 ** this.restarts;
    this.restarts += 1;
    this.setState('restarting');
    this.log(`[sidecar] ${detail}; restart ${this.restarts} in ${delay} ms`);
    this.restartTimer = setTimeout(() => {
      this.restartTimer = undefined;
      if (this.stopping) return;
      this.launchOnce('restarting').catch((error: Error) => {
        if (this.stopping) return;
        // a launch that fails outright counts against the same restart budget
        this.log(`[sidecar] restart failed: ${error.message}`);
        if (this.current !== 'restarting' && this.current !== 'starting') return;
        this.onExit('could not be restarted');
      });
    }, delay);
  }

  /** Checks `/health`, retrying briefly: the process has announced itself, but its server may still be starting. */
  private async fetchHealth(): Promise<void> {
    let lastError: unknown;
    for (let attempt = 0; attempt < 10; attempt += 1) {
      try {
        const response = await this.http('GET', '/health', undefined, 5_000);
        if (!response.ok) throw new Error(`/health answered ${response.status}`);
        return;
      } catch (error) {
        lastError = error;
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }
    throw lastError instanceof Error ? lastError : new Error('health check failed');
  }

  private http(method: string, path: string, body: unknown, timeoutMs: number): Promise<Response> {
    if (this.port === undefined) return Promise.reject(new SidecarError('unavailable', 'The Python backend is not running'));
    const headers: Record<string, string> = { authorization: `Bearer ${this.token}`, accept: 'application/json' };
    const init: RequestInit = { method, headers, signal: AbortSignal.timeout(timeoutMs), redirect: 'manual' };
    if (body !== undefined) {
      headers['content-type'] = 'application/json';
      init.body = JSON.stringify(body);
    }
    return fetch(`http://127.0.0.1:${this.port}${path}`, init);
  }

  /** Calls the sidecar. Rejects with a `SidecarError` (`unavailable`, `timeout`, `service_error`, `invalid_request`). */
  async request(method: string, path: string, body?: unknown): Promise<unknown> {
    assertSidecarRequest(method, path);
    if (this.current !== 'ready') throw new SidecarError('unavailable', `The Python backend is ${this.current}`);
    let response: Response;
    try {
      response = await this.http(method, path, body, this.options.requestTimeoutMs ?? 30_000);
    } catch (error) {
      if (error instanceof SidecarError) throw error;
      const name = (error as Error).name;
      if (name === 'TimeoutError' || name === 'AbortError') throw new SidecarError('timeout', 'The Python backend did not respond in time');
      throw new SidecarError('unavailable', 'The Python backend could not be reached');
    }
    const text = await response.text();
    let value: unknown = text;
    try {
      value = text === '' ? null : JSON.parse(text);
    } catch {
      // not JSON: hand back the text
    }
    if (!response.ok) {
      const detail = typeof (value as { detail?: unknown } | null)?.detail === 'string' ? `: ${(value as { detail: string }).detail.slice(0, 200)}` : '';
      throw new SidecarError('service_error', `The Python backend responded ${response.status}${detail}`);
    }
    return value;
  }

  /** Stops the sidecar: asks it to shut down, closes its stdin, and kills the process tree if it does not exit in time. */
  async stop(): Promise<void> {
    this.stopping = true;
    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
      this.restartTimer = undefined;
    }
    const child = this.child;
    if (!child) {
      if (this.current !== 'stopped') this.setState('stopped');
      return;
    }
    const exited = new Promise<void>((resolve) => child.once('exit', () => resolve()));
    if (this.current === 'ready') await this.http('POST', '/shutdown', undefined, 1_000).catch(() => undefined);
    child.stdin?.end();
    const grace = this.options.shutdownGraceMs ?? 3_000;
    const timedOut = await Promise.race([exited.then(() => false), new Promise<boolean>((resolve) => setTimeout(() => resolve(true), grace))]);
    if (timedOut) {
      await killTree(child.pid);
      await killTree(this.realPid);
      await Promise.race([exited, new Promise<void>((resolve) => setTimeout(resolve, 2_000))]);
    }
    this.generation += 1;
    this.child = undefined;
    this.port = undefined;
    if (this.current !== 'stopped') this.setState('stopped');
  }
}
