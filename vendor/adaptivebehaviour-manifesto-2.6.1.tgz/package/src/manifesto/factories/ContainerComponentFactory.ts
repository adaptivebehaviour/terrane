import { createElement, Fragment, type ReactElement } from 'react';
import type { RootRecord } from '../../Root';
import { buildComponent } from '../../create';
import { ContainerFactory } from '../../ContainerFactory';
import { ContainerComponent } from '../components/ContainerComponent';

/**
 * Factory `'component'` — resolves each element of a passed `items` array
 * into its own component, wrapped in the base `component` factory's own
 * generic `<div>` (see `components/ContainerComponent.tsx`). Registered in
 * `instanceRegistry` (see `index.ts`), replacing the generic {@link Factory}
 * default `'component'` previously used.
 *
 * Named `ContainerComponentFactory`/`ContainerComponent` (not just
 * `ComponentFactory`/`Component`) to disambiguate from
 * {@link ItemComponentFactory}/`ItemComponent` — the two are otherwise
 * identical generic, purpose-free wrappers, differing only in whether *every*
 * element of `items` is rendered as a child (this one) or only the first
 * (`ItemComponentFactory`). The registered factory string stays `'component'`
 * — unchanged by this rename — since other collections (e.g. the `nextjs`
 * app's own `crm` collection) already depend on that exact key.
 *
 * A thin subclass of {@link ContainerFactory} — `'component'` has no
 * declared defaults of its own and no record-assembly needs beyond
 * resolving every `items` element, so `ContainerFactory`'s own `produce()`
 * (via its inherited `resolveItemRecords()`) covers everything this
 * factory's own record production needs. See `ContainerFactory.ts`'s own
 * doc comment for the full behavior: why it's unconditionally `async`
 * (`createAsync('component', ...)`, never a plain `create()`), how the
 * two-phase `kind`-ancestor/own-defaults merge is preserved, and how each
 * `items` element is resolved (including the `[arg, options]` tuple form).
 *
 * `renderItemComponents()`/`renderComponent()` below are this class's own
 * rendering-side methods, not part of `ContainerFactory` — rendering
 * `'component'`'s specific `<div>` markup is this factory's own concern.
 * Both are generic enough that `scenes-records`'s own
 * `src/factories/StageFactory.ts`/`SceneFactory.ts` extend this class
 * specifically to reuse `renderItemComponents()` unmodified; each still
 * overrides `renderComponent()`, but only to point at its own paired
 * component (`Stage`/`Scene` instead of `ContainerComponent`) — the method
 * body is otherwise identical, since `Stage`/`Scene` have the same
 * `RecordPropsComponent` shape as `ContainerComponent` (see
 * `StageFactory.ts`'s own doc comment).
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('component', {
 *   items: ['text:Hello', { factory: 'image', props: { url: 'foo.jpg' } }],
 * });
 * // <div data-factory="component"><p>Hello</p><img src="foo.jpg" /></div>
 * ```
 */
export class ContainerComponentFactory extends ContainerFactory {
  /**
   * Renders a container's already-resolved item records as React elements —
   * originally `manifesto/components/ContainerComponent.tsx`'s own render
   * body, moved here so it lives alongside the class it's specific to. Each
   * item is wrapped in a keyed `Fragment` (rather than mutating the element
   * `buildComponent()` returns) purely so React's list reconciliation has a
   * stable key, matching the original inline `.map()`.
   *
   * A separate, overridable method so a component built on this
   * class (or a subclass) can call it directly — e.g.
   * `new ContainerComponentFactory(record).renderItemComponents(record.items as RootRecord[])`
   * — to render its own resolved items, and a subclass can override *how*
   * each item is rendered (e.g. a different wrapper element, extra per-item
   * props) without duplicating this loop.
   *
   * @param items - Already-resolved item records — the shape
   *   `resolveItemRecords()` (inherited from `ContainerFactory`, or an
   *   equivalent step) produces, not raw item specs.
   */
  renderItemComponents(items: RootRecord[]): ReactElement[] {
    return items.map((item, index) => createElement(Fragment, { key: index }, buildComponent(item)));
  }

  /**
   * Renders `ContainerComponent` (`components/ContainerComponent.tsx`) from
   * this factory's own resolved record plus the given, already-resolved
   * `items` — the `ContainerComponentFactory` side of this class's pairing
   * with `ContainerComponent`: the names match on purpose, and
   * `renderComponent()` here is what a caller holding a
   * `ContainerComponentFactory` reaches for instead of importing
   * `ContainerComponent` itself.
   *
   * `ContainerComponent` is a `RecordPropsComponent` (see `create.ts`'s own
   * type): a component whose props *are* the record's own fields, not a
   * `{ record }` props object — the same shape `Stage`/`Scene` use too.
   * (`buildComponent()` itself renders a `RecordComponent` with
   * `{ record }`, which is why `index.ts` registers `ContainerComponent`
   * through `fromRecordProps()`.) So `createElement(ContainerComponent, props)`
   * below passes the assembled record directly as `props` — the same as JSX
   * like `<ContainerComponent {...record} />`;
   * `<ContainerComponent record={...} />` would NOT work, since that passes
   * `{ record: ... }` as `props`, and `ContainerComponent`'s own body would
   * then read `props.id`/`props.props` as `undefined`.
   *
   * Deliberately does **not** call `renderItemComponents()` itself — it only
   * assembles a complete record (`this.record()` plus the given `items`) and
   * hands it to `ContainerComponent` via `createElement()`.
   * `ContainerComponent`'s own body (see its doc comment) is the one and
   * only place `renderItemComponents()` actually runs, and it only runs when
   * the returned element is actually rendered — `createElement()` just
   * builds a descriptor, it doesn't invoke `ContainerComponent` yet. That
   * laziness is what keeps this class's two ways of reaching a rendered
   * `'component'` — `factory.renderComponent(items)` here, or calling
   * `ContainerComponent(record)` directly — from calling
   * `renderItemComponents()` twice: whichever path a caller takes, the items
   * only ever get rendered once `ContainerComponent` itself actually runs.
   * It also rules out a loop, since `ContainerComponent` never calls back
   * into `renderComponent()` — it only calls `renderItemComponents()`, which
   * terminates in a `buildComponent()` call per item, with no further
   * delegation back to either method.
   *
   * @param items - Already-resolved item records, same as
   *   {@link renderItemComponents}'s own parameter.
   */
  renderComponent(items: RootRecord[]): ReactElement {
    return createElement(ContainerComponent, { ...this.record(), items });
  }
}
